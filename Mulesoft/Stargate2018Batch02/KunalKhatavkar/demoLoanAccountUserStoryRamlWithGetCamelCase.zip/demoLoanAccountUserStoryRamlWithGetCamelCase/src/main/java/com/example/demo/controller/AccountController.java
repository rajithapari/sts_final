
package com.example.demo.controller;

import java.util.List;
import com.example.demo.controller.model.Loanaccount;
import com.example.demo.dao.LoanAccountBaseRepositoryImpl;
import com.example.demo.rabbitmqmessageproducer.MessageProducer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


/**
 * No description
 * (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
@RequestMapping(value = "/api/accounts", produces = "application/json")
@Validated
public class AccountController {


	 @Autowired
	   private LoanAccountBaseRepositoryImpl loanAccountDao;
	 
	 @Autowired
	 private  MessageProducer messageProducer;   
	 
	  
    @RequestMapping(value = "", method = RequestMethod.GET)
    public List<Loanaccount> getLoanaccountsBy(
        @RequestParam(defaultValue = "MONTHLY", required = false)
        String paymentFrequency,
        @RequestHeader(name = "Authorization")
        String authorization,
        @RequestHeader(name = "Accept")
        String contentType) {
          System.err.println("in controller with parameter " +  paymentFrequency);
    	 List<Loanaccount> listloanaccount=	loanAccountDao.fetchLoanaccountDetails(paymentFrequency);
 	    System.out.println(listloanaccount);
 	   
 	   messageProducer.sendMessage(listloanaccount);
 	    
 	        return listloanaccount;
    }

}
