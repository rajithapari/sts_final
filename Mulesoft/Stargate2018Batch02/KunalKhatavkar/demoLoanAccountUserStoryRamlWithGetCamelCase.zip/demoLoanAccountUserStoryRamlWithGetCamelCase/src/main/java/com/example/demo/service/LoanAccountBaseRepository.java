package com.example.demo.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import com.example.demo.controller.model.Loanaccount;

@SuppressWarnings("hiding")
@NoRepositoryBean
public interface LoanAccountBaseRepository<Loanaccount>  extends JpaRepository<Loanaccount, String>{

	
	 public List<Loanaccount> fetchLoanaccountDetails(String paymentFrequency);
}
