
package com.example.demo.controller;

import java.util.List;
import com.example.demo.controller.model.Loanaccount;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.CustomizedResponseEntityExceptionHandler;
import com.example.demo.exception.HeaderNotAcceptableException;
import com.example.demo.exception.LoanAccountNotFoundException;
import com.example.demo.rabbitmqmessageproducer.MessageProducer;
import com.example.demo.service.LoanAccountBaseRepositoryImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.amqp.AmqpException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * No description (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
@RequestMapping(value = "/api/accounts", produces = "application/json")
@Validated
public class AccountController {

	private static Logger logger = LogManager.getLogger(AccountController.class);
	@Autowired
	private LoanAccountBaseRepositoryImpl loanAccountBaseRepositoryImpl;

	
	@Autowired
	private MessageProducer messageProducer;


	@RequestMapping(value = "", method = RequestMethod.GET)
	public ResponseEntity<?> getLoanaccountsBy(
			@RequestParam(name="paymentFrequency") String paymentFrequency,
			@RequestHeader(name = "Authorization", required=false) String authorization,
			@RequestHeader(name = "Accept") String contentType) {
           logger.info("in main controller AccountController class");
		
		try {
			if (!paymentFrequency.equals("MONTHLY")) {
			logger.info("paymentfrequeny is not equal to 'MONTHLY'");
				throw new BadRequestException("redirecting to BadRequestException");
			}

			/*
			 * // contentType = "content"; if(!contentType.equals("Accept")){
			 * throw new HeaderNotAcceptableException(
			 * "redirecting to HeaderNotAcceptableException"); }
			 */

			List<Loanaccount> listloanaccount = loanAccountBaseRepositoryImpl.getAllLoanAccount(paymentFrequency);
			System.out.println("listloanaccount" + listloanaccount);
			
			for (int i = 0; i < listloanaccount.size(); i++) {
				
			}
			
			logger.info("listloanaccount : " + listloanaccount);
			if (listloanaccount.size() == 0) {
				logger.info(" size of listloanaccount : " + listloanaccount.size());
				throw new LoanAccountNotFoundException("redirecting to LoanAccountNotFoundException");
			}
            
			try{
			messageProducer.sendMessage(listloanaccount);
		logger.info("message sent to rabbitmq successfuly");
			}catch(AmqpException amp){
			logger.info("message NOT sent to rabbitmq ");
			}

			return new ResponseEntity<List<Loanaccount>>(listloanaccount, HttpStatus.OK);
		} catch (BadRequestException bd) {

			return new CustomizedResponseEntityExceptionHandler().forBadRequest(bd);
		} catch (LoanAccountNotFoundException ex) {

			return new CustomizedResponseEntityExceptionHandler().handleLoanAccountNotFoundException(ex);

		} catch (HeaderNotAcceptableException hd) {

			return new CustomizedResponseEntityExceptionHandler().handleHeaderNotAcceptableException(hd);

		} catch (Exception ec) {

			return new CustomizedResponseEntityExceptionHandler().handleAllExceptions(ec);

		}
	}

}
