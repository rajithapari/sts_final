package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RamlToSpringBootApplicationcomplexApplication {

	public static void main(String[] args) {
		SpringApplication.run(RamlToSpringBootApplicationcomplexApplication.class, args);
	}
}
