
package com.example.demo.controller.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class User implements Serializable
{

    final static long serialVersionUID = -1856846538575664195L;
    private Double id;
    private Double mobile;

    /**
     * Creates a new User.
     * 
     */
    public User() {
        super();
    }

    /**
     * Creates a new User.
     * 
     */
    public User(Double id, Double mobile) {
        super();
        this.id = id;
        this.mobile = mobile;
    }

    /**
     * Returns the id.
     * 
     * @return
     *     id
     */
    public Double getId() {
        return id;
    }

    /**
     * Set the id.
     * 
     * @param id
     *     the new id
     */
    public void setId(Double id) {
        this.id = id;
    }

    /**
     * Returns the mobile.
     * 
     * @return
     *     mobile
     */
    public Double getMobile() {
        return mobile;
    }

    /**
     * Set the mobile.
     * 
     * @param mobile
     *     the new mobile
     */
    public void setMobile(Double mobile) {
        this.mobile = mobile;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(id).append(mobile).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        User otherObject = ((User) other);
        return new EqualsBuilder().append(id, otherObject.id).append(mobile, otherObject.mobile).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("id", id).append("mobile", mobile).toString();
    }

}
