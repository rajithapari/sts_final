
package com.example.demo.controller.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Object implements Serializable
{

    final static long serialVersionUID = 245539873304226040L;
    private PaymentFrequency paymentFrequency = (PaymentFrequency.MONTHLY);

    /**
     * Creates a new Object.
     * 
     */
    public Object() {
        super();
    }

    /**
     * Creates a new Object.
     * 
     */
    public Object(PaymentFrequency paymentFrequency) {
        super();
        this.paymentFrequency = paymentFrequency;
    }

    /**
     * Returns the paymentFrequency.
     * 
     * @return
     *     paymentFrequency
     */
    public PaymentFrequency getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Set the paymentFrequency.
     * 
     * @param paymentFrequency
     *     the new paymentFrequency
     */
    public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(paymentFrequency).toHashCode();
    }

    public boolean equals(java.lang.Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Object otherObject = ((Object) other);
        return new EqualsBuilder().append(paymentFrequency, otherObject.paymentFrequency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("paymentFrequency", paymentFrequency).toString();
    }

}
