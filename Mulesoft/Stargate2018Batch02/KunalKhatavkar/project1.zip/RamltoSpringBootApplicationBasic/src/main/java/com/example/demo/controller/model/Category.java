
package com.example.demo.controller.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Category implements Serializable
{

    final static long serialVersionUID = -2361453273673475466L;
    private com.example.demo.controller.model.Books Books;
    private com.example.demo.controller.model.Customer Customer;
    
 

    /**
     * Creates a new Category.
     * 
     */
    public Category() {
        super();
    }

    /**
     * Creates a new Category.
     * 
     */
    public Category(com.example.demo.controller.model.Books Books, com.example.demo.controller.model.Customer Customer) {
        super();
        this.Books = Books;
        this.Customer = Customer;
    }

    /**
     * Returns the Books.
     * 
     * @return
     *     Books
     */
    public com.example.demo.controller.model.Books getBooks() {
        return Books;
    }

    /**
     * Set the Books.
     * 
     * @param Books
     *     the new Books
     */
    public void setBooks(com.example.demo.controller.model.Books Books) {
        this.Books = Books;
    }

    /**
     * Returns the Customer.
     * 
     * @return
     *     Customer
     */
    public com.example.demo.controller.model.Customer getCustomer() {
        return Customer;
    }

    /**
     * Set the Customer.
     * 
     * @param Customer
     *     the new Customer
     */
    public void setCustomer(com.example.demo.controller.model.Customer Customer) {
        this.Customer = Customer;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(Books).append(Customer).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Category otherObject = ((Category) other);
        return new EqualsBuilder().append(Books, otherObject.Books).append(Customer, otherObject.Customer).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("Books", Books).append("Customer", Customer).toString();
    }

}
