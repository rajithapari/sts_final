
package com.example.demo.controller.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Books implements Serializable
{

    final static long serialVersionUID = -2358148307240107210L;
    private String id;
    private String bookTitle;
    private String description;
    private Long datetime;
    private String genre;
    private String author;
    private String link;

    /**
     * Creates a new Books.
     * 
     */
    public Books() {
        super();
    }

    /**
     * Creates a new Books.
     * 
     */
    public Books(String id, String bookTitle, String description, Long datetime, String genre, String author, String link) {
        super();
        this.id = id;
        this.bookTitle = bookTitle;
        this.description = description;
        this.datetime = datetime;
        this.genre = genre;
        this.author = author;
        this.link = link;
    }

    /**
     * Returns the id.
     * 
     * @return
     *     id
     */
    public String getId() {
        return id;
    }

    /**
     * Set the id.
     * 
     * @param id
     *     the new id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Returns the bookTitle.
     * 
     * @return
     *     bookTitle
     */
    public String getBookTitle() {
        return bookTitle;
    }

    /**
     * Set the bookTitle.
     * 
     * @param bookTitle
     *     the new bookTitle
     */
    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    /**
     * Returns the description.
     * 
     * @return
     *     description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the description.
     * 
     * @param description
     *     the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the datetime.
     * 
     * @return
     *     datetime
     */
    public Long getDatetime() {
        return datetime;
    }

    /**
     * Set the datetime.
     * 
     * @param datetime
     *     the new datetime
     */
    public void setDatetime(Long datetime) {
        this.datetime = datetime;
    }

    /**
     * Returns the genre.
     * 
     * @return
     *     genre
     */
    public String getGenre() {
        return genre;
    }

    /**
     * Set the genre.
     * 
     * @param genre
     *     the new genre
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * Returns the author.
     * 
     * @return
     *     author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Set the author.
     * 
     * @param author
     *     the new author
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * Returns the link.
     * 
     * @return
     *     link
     */
    public String getLink() {
        return link;
    }

    /**
     * Set the link.
     * 
     * @param link
     *     the new link
     */
    public void setLink(String link) {
        this.link = link;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(id).append(bookTitle).append(description).append(datetime).append(genre).append(author).append(link).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Books otherObject = ((Books) other);
        return new EqualsBuilder().append(id, otherObject.id).append(bookTitle, otherObject.bookTitle).append(description, otherObject.description).append(datetime, otherObject.datetime).append(genre, otherObject.genre).append(author, otherObject.author).append(link, otherObject.link).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("id", id).append("bookTitle", bookTitle).append("description", description).append("datetime", datetime).append("genre", genre).append("author", author).append("link", link).toString();
    }

}
