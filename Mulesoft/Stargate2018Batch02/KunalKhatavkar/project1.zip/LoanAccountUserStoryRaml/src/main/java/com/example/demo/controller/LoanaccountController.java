
package com.example.demo.controller;

import java.util.List;
import javax.validation.Valid;
import com.example.demo.controller.model.Applicationjson;
import com.example.demo.controller.model.Loanaccount;
import com.example.demo.service.LoanAccountRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


/**
 * No description
 * (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
@RequestMapping(value = "/api/loanaccount", produces = "application/json")
@Validated
public class LoanaccountController {

	@Autowired
	private LoanAccountRepository loanAccountRepository;

   
    @RequestMapping(value = "", method = RequestMethod.POST)
    public List<Loanaccount> createApplicationjson(
        @Valid
        @RequestBody
        Applicationjson applicationjson) {
    	List<Loanaccount> idaccount =  loanAccountRepository.listAllLoanacount(applicationjson.value());
    	return idaccount;
    }

}
