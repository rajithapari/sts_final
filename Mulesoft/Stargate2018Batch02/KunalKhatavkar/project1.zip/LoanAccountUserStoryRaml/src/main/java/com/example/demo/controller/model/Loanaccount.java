
package com.example.demo.controller.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "account", schema="springboot_test")
@PrimaryKeyJoinColumn(name="LoanAccountId")
public class Loanaccount
    extends Account
    implements Serializable
{

    final static long serialVersionUID = 2592675764695197402L;
   
    @OneToOne
    @JoinColumn
    private String LoanAccountId;
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column
    private Date BalanceAsOf;
    @Column
    private Double PrincipalBalance;
    @Column
    private Double OriginalPrincipal;
    @Column
    private Long LoanTerm;
    @Column
    private Long TotalNumberOfPayments;
    @Column
    private Double NextPaymentAmount;
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column
    private Date NextPaymentDate;
    @Column
    private Double LastPaymentAmount;
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column
    private Date LastPaymentDate;
    @Column
    private String PaymentFrequency;

    /**
     * Creates a new Loanaccount.
     * 
     */
    public Loanaccount() {
        super();
    }

    /**
     * Creates a new Loanaccount.
     * 
     */
    public Loanaccount(String AccountId, String AccountType, Double DisplayName, Double Description, Double Status, Double AccountDescriptorId, String CustomerId, String AccountMasterId, String ParentAccountId, String Nickname, Double LineOfBusiness, String AccountNumber, Double InterestRate, String Currency, Double AccDescriptorId, Double TransferIn, Double TransferOut, Double InterestRateType, String LoanAccountId, Date BalanceAsOf, Double PrincipalBalance, Double OriginalPrincipal, Long LoanTerm, Long TotalNumberOfPayments, Double NextPaymentAmount, Date NextPaymentDate, Double LastPaymentAmount, Date LastPaymentDate, String PaymentFrequency) {
        super(AccountId, AccountType, DisplayName, Description, Status, AccountDescriptorId, CustomerId, AccountMasterId, ParentAccountId, Nickname, LineOfBusiness, AccountNumber, InterestRate, Currency, AccDescriptorId, TransferIn, TransferOut, InterestRateType);
        this.LoanAccountId = LoanAccountId;
        this.BalanceAsOf = BalanceAsOf;
        this.PrincipalBalance = PrincipalBalance;
        this.OriginalPrincipal = OriginalPrincipal;
        this.LoanTerm = LoanTerm;
        this.TotalNumberOfPayments = TotalNumberOfPayments;
        this.NextPaymentAmount = NextPaymentAmount;
        this.NextPaymentDate = NextPaymentDate;
        this.LastPaymentAmount = LastPaymentAmount;
        this.LastPaymentDate = LastPaymentDate;
        this.PaymentFrequency = PaymentFrequency;
    }

    /**
     * Returns the LoanAccountId.
     * 
     * @return
     *     LoanAccountId
     */
    public String getLoanAccountId() {
        return LoanAccountId;
    }

    /**
     * Set the LoanAccountId.
     * 
     * @param LoanAccountId
     *     the new LoanAccountId
     */
    public void setLoanAccountId(String LoanAccountId) {
        this.LoanAccountId = LoanAccountId;
    }

    /**
     * Returns the BalanceAsOf.
     * 
     * @return
     *     BalanceAsOf
     */
    public Date getBalanceAsOf() {
        return BalanceAsOf;
    }

    /**
     * Set the BalanceAsOf.
     * 
     * @param BalanceAsOf
     *     the new BalanceAsOf
     */
    public void setBalanceAsOf(Date BalanceAsOf) {
        this.BalanceAsOf = BalanceAsOf;
    }

    /**
     * Returns the PrincipalBalance.
     * 
     * @return
     *     PrincipalBalance
     */
    public Double getPrincipalBalance() {
        return PrincipalBalance;
    }

    /**
     * Set the PrincipalBalance.
     * 
     * @param PrincipalBalance
     *     the new PrincipalBalance
     */
    public void setPrincipalBalance(Double PrincipalBalance) {
        this.PrincipalBalance = PrincipalBalance;
    }

    /**
     * Returns the OriginalPrincipal.
     * 
     * @return
     *     OriginalPrincipal
     */
    public Double getOriginalPrincipal() {
        return OriginalPrincipal;
    }

    /**
     * Set the OriginalPrincipal.
     * 
     * @param OriginalPrincipal
     *     the new OriginalPrincipal
     */
    public void setOriginalPrincipal(Double OriginalPrincipal) {
        this.OriginalPrincipal = OriginalPrincipal;
    }

    /**
     * Returns the LoanTerm.
     * 
     * @return
     *     LoanTerm
     */
    public Long getLoanTerm() {
        return LoanTerm;
    }

    /**
     * Set the LoanTerm.
     * 
     * @param LoanTerm
     *     the new LoanTerm
     */
    public void setLoanTerm(Long LoanTerm) {
        this.LoanTerm = LoanTerm;
    }

    /**
     * Returns the TotalNumberOfPayments.
     * 
     * @return
     *     TotalNumberOfPayments
     */
    public Long getTotalNumberOfPayments() {
        return TotalNumberOfPayments;
    }

    /**
     * Set the TotalNumberOfPayments.
     * 
     * @param TotalNumberOfPayments
     *     the new TotalNumberOfPayments
     */
    public void setTotalNumberOfPayments(Long TotalNumberOfPayments) {
        this.TotalNumberOfPayments = TotalNumberOfPayments;
    }

    /**
     * Returns the NextPaymentAmount.
     * 
     * @return
     *     NextPaymentAmount
     */
    public Double getNextPaymentAmount() {
        return NextPaymentAmount;
    }

    /**
     * Set the NextPaymentAmount.
     * 
     * @param NextPaymentAmount
     *     the new NextPaymentAmount
     */
    public void setNextPaymentAmount(Double NextPaymentAmount) {
        this.NextPaymentAmount = NextPaymentAmount;
    }

    /**
     * Returns the NextPaymentDate.
     * 
     * @return
     *     NextPaymentDate
     */
    public Date getNextPaymentDate() {
        return NextPaymentDate;
    }

    /**
     * Set the NextPaymentDate.
     * 
     * @param NextPaymentDate
     *     the new NextPaymentDate
     */
    public void setNextPaymentDate(Date NextPaymentDate) {
        this.NextPaymentDate = NextPaymentDate;
    }

    /**
     * Returns the LastPaymentAmount.
     * 
     * @return
     *     LastPaymentAmount
     */
    public Double getLastPaymentAmount() {
        return LastPaymentAmount;
    }

    /**
     * Set the LastPaymentAmount.
     * 
     * @param LastPaymentAmount
     *     the new LastPaymentAmount
     */
    public void setLastPaymentAmount(Double LastPaymentAmount) {
        this.LastPaymentAmount = LastPaymentAmount;
    }

    /**
     * Returns the LastPaymentDate.
     * 
     * @return
     *     LastPaymentDate
     */
    public Date getLastPaymentDate() {
        return LastPaymentDate;
    }

    /**
     * Set the LastPaymentDate.
     * 
     * @param LastPaymentDate
     *     the new LastPaymentDate
     */
    public void setLastPaymentDate(Date LastPaymentDate) {
        this.LastPaymentDate = LastPaymentDate;
    }

    /**
     * Returns the PaymentFrequency.
     * 
     * @return
     *     PaymentFrequency
     */
    public String getPaymentFrequency() {
        return PaymentFrequency;
    }

    /**
     * Set the PaymentFrequency.
     * 
     * @param PaymentFrequency
     *     the new PaymentFrequency
     */
    public void setPaymentFrequency(String PaymentFrequency) {
        this.PaymentFrequency = PaymentFrequency;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(LoanAccountId).append(BalanceAsOf).append(PrincipalBalance).append(OriginalPrincipal).append(LoanTerm).append(TotalNumberOfPayments).append(NextPaymentAmount).append(NextPaymentDate).append(LastPaymentAmount).append(LastPaymentDate).append(PaymentFrequency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Loanaccount otherObject = ((Loanaccount) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(LoanAccountId, otherObject.LoanAccountId).append(BalanceAsOf, otherObject.BalanceAsOf).append(PrincipalBalance, otherObject.PrincipalBalance).append(OriginalPrincipal, otherObject.OriginalPrincipal).append(LoanTerm, otherObject.LoanTerm).append(TotalNumberOfPayments, otherObject.TotalNumberOfPayments).append(NextPaymentAmount, otherObject.NextPaymentAmount).append(NextPaymentDate, otherObject.NextPaymentDate).append(LastPaymentAmount, otherObject.LastPaymentAmount).append(LastPaymentDate, otherObject.LastPaymentDate).append(PaymentFrequency, otherObject.PaymentFrequency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("LoanAccountId", LoanAccountId).append("BalanceAsOf", BalanceAsOf).append("PrincipalBalance", PrincipalBalance).append("OriginalPrincipal", OriginalPrincipal).append("LoanTerm", LoanTerm).append("TotalNumberOfPayments", TotalNumberOfPayments).append("NextPaymentAmount", NextPaymentAmount).append("NextPaymentDate", NextPaymentDate).append("LastPaymentAmount", LastPaymentAmount).append("LastPaymentDate", LastPaymentDate).append("PaymentFrequency", PaymentFrequency).toString();
    }

}
