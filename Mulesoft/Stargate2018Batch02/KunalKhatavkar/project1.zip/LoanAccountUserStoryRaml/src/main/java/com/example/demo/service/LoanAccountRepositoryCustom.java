package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.controller.model.Loanaccount;

@Repository
@Service
@Component
public interface LoanAccountRepositoryCustom {

	
	public List<Loanaccount> listAllLoanacount(String paymentFrequency);
}
