package com.example.demo.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.controller.model.Loanaccount;

@NoRepositoryBean
public interface LoanAccountRepository extends JpaRepository<Loanaccount, String> {

	
	public List<Loanaccount> listAllLoanacount(String paymentFrequency);
	 
}

