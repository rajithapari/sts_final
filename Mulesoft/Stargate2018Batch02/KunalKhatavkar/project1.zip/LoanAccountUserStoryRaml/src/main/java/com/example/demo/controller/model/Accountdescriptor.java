
package com.example.demo.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "accountdescriptor", schema="springboot_test")
@Inheritance(strategy = InheritanceType.JOINED)
public class Accountdescriptor implements Serializable
{

    final static long serialVersionUID = 2592675764695197402L;
    @Column
    private String AccountId;
    @Column
    private String AccountType;
    @Column
    private Double DisplayName;
    @Column
    private Double Description;
    @Column
    private Double Status;
    @Id
    @Column
    private Double AccountDescriptorId;
    @Column
    private String CustomerId;

    /**
     * Creates a new Accountdescriptor.
     * 
     */
    public Accountdescriptor() {
        super();
    }

    /**
     * Creates a new Accountdescriptor.
     * 
     */
    public Accountdescriptor(String AccountId, String AccountType, Double DisplayName, Double Description, Double Status, Double AccountDescriptorId, String CustomerId) {
        super();
        this.AccountId = AccountId;
        this.AccountType = AccountType;
        this.DisplayName = DisplayName;
        this.Description = Description;
        this.Status = Status;
        this.AccountDescriptorId = AccountDescriptorId;
        this.CustomerId = CustomerId;
    }

    /**
     * Returns the AccountId.
     * 
     * @return
     *     AccountId
     */
    public String getAccountId() {
        return AccountId;
    }

    /**
     * Set the AccountId.
     * 
     * @param AccountId
     *     the new AccountId
     */
    public void setAccountId(String AccountId) {
        this.AccountId = AccountId;
    }

    /**
     * Returns the AccountType.
     * 
     * @return
     *     AccountType
     */
    public String getAccountType() {
        return AccountType;
    }

    /**
     * Set the AccountType.
     * 
     * @param AccountType
     *     the new AccountType
     */
    public void setAccountType(String AccountType) {
        this.AccountType = AccountType;
    }

    /**
     * Returns the DisplayName.
     * 
     * @return
     *     DisplayName
     */
    public Double getDisplayName() {
        return DisplayName;
    }

    /**
     * Set the DisplayName.
     * 
     * @param DisplayName
     *     the new DisplayName
     */
    public void setDisplayName(Double DisplayName) {
        this.DisplayName = DisplayName;
    }

    /**
     * Returns the Description.
     * 
     * @return
     *     Description
     */
    public Double getDescription() {
        return Description;
    }

    /**
     * Set the Description.
     * 
     * @param Description
     *     the new Description
     */
    public void setDescription(Double Description) {
        this.Description = Description;
    }

    /**
     * Returns the Status.
     * 
     * @return
     *     Status
     */
    public Double getStatus() {
        return Status;
    }

    /**
     * Set the Status.
     * 
     * @param Status
     *     the new Status
     */
    public void setStatus(Double Status) {
        this.Status = Status;
    }

    /**
     * Returns the AccountDescriptorId.
     * 
     * @return
     *     AccountDescriptorId
     */
    public Double getAccountDescriptorId() {
        return AccountDescriptorId;
    }

    /**
     * Set the AccountDescriptorId.
     * 
     * @param AccountDescriptorId
     *     the new AccountDescriptorId
     */
    public void setAccountDescriptorId(Double AccountDescriptorId) {
        this.AccountDescriptorId = AccountDescriptorId;
    }

    /**
     * Returns the CustomerId.
     * 
     * @return
     *     CustomerId
     */
    public String getCustomerId() {
        return CustomerId;
    }

    /**
     * Set the CustomerId.
     * 
     * @param CustomerId
     *     the new CustomerId
     */
    public void setCustomerId(String CustomerId) {
        this.CustomerId = CustomerId;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(AccountId).append(AccountType).append(DisplayName).append(Description).append(Status).append(AccountDescriptorId).append(CustomerId).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Accountdescriptor otherObject = ((Accountdescriptor) other);
        return new EqualsBuilder().append(AccountId, otherObject.AccountId).append(AccountType, otherObject.AccountType).append(DisplayName, otherObject.DisplayName).append(Description, otherObject.Description).append(Status, otherObject.Status).append(AccountDescriptorId, otherObject.AccountDescriptorId).append(CustomerId, otherObject.CustomerId).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("AccountId", AccountId).append("AccountType", AccountType).append("DisplayName", DisplayName).append("Description", Description).append("Status", Status).append("AccountDescriptorId", AccountDescriptorId).append("CustomerId", CustomerId).toString();
    }

}
