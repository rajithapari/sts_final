 package com.example.demo.service;


import javax.transaction.Transactional;

import com.example.demo.controller.model.Loanaccount;
@Transactional
public interface AccountdescriptorRepository extends LoanAccountBaseRepository<Loanaccount> {

}
