package com.example.demo.dao;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.example.demo.controller.model.Loanaccount;
import com.example.demo.service.LoanAccountBaseRepository;
@Repository
@Transactional
public class LoanAccountBaseRepositoryImpl implements LoanAccountBaseRepository<Loanaccount> {
	
	@PersistenceContext
    EntityManager entityManager;

	@Override
	public void deleteAllInBatch() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteInBatch(Iterable<Loanaccount> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Loanaccount> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Loanaccount> findAll(Sort arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Loanaccount> List<S> findAll(Example<S> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Loanaccount> List<S> findAll(Example<S> arg0, Sort arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Loanaccount> findAllById(Iterable<String> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void flush() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Loanaccount getOne(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Loanaccount> List<S> saveAll(Iterable<S> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Loanaccount> S saveAndFlush(S arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Page<Loanaccount> findAll(Pageable arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(Loanaccount arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends Loanaccount> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean existsById(String arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Optional<Loanaccount> findById(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Loanaccount> S save(S arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Loanaccount> long count(Example<S> arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public <S extends Loanaccount> boolean exists(Example<S> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public <S extends Loanaccount> Page<S> findAll(Example<S> arg0, Pageable arg1) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Loanaccount> Optional<S> findOne(Example<S> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Loanaccount> fetchLoanaccountDetails(String paymentfre) {
	
			
			 Query query = entityManager.createNativeQuery("SELECT la.BalanceAsOf, la.PrincipalBalance, la.OriginalPrincipal, la.LoanTerm, la.TotalNumberOfPayments, la.NextPaymentAmount, la.NextPaymentDate, la.LastPaymentAmount, la.LastPaymentDate, acc.AccountMasterId, acc.Nickname, acc.LineOfBusiness, acc.AccountNumber, acc.InterestRate, acc.Currency, asd.AccountType, asd.CustomerId, asd.DisplayName, asd.Status from loanaccount la , account acc, accountdescriptor asd where la.PaymentFrequency = ? and la.AccountId = acc.AccountMasterId and acc.AccDescriptorId = asd.AccountDescriptorId", Loanaccount.class);
		        query.setParameter(1, paymentfre);
		        return query.getResultList();
		
	}

	
}
