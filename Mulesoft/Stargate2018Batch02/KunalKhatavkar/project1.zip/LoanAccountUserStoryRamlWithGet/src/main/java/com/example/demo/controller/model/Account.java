
package com.example.demo.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
@Entity
@Table(name = "account")
public class Account
    extends Accountdescriptor
    implements Serializable
{

    final static long serialVersionUID = -5661326348347330714L;
    @Column
    private String AccountMasterId;
    @Column
    private String ParentAccountId;
    @Column
    private String Nickname;
    @Column
    private String LineOfBusiness;
    @Column
    private String AccountNumber;
    @Column
    private Double InterestRate;
    @Column
    private String Currency;
    @Column
    private Double AccDescriptorId;
    @Column
    private Double TransferIn;
    @Column
    private Double TransferOut;
    @Column
    private Double InterestRateType;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
    public Account(String AccountId, IdentifierforAccounttype AccountType, String DisplayName, Double Description, IdentifierforAccoundstatus Status, Double AccountDescriptorId, String CustomerId, String AccountMasterId, String ParentAccountId, String Nickname, String LineOfBusiness, String AccountNumber, Double InterestRate, String Currency, Double AccDescriptorId, Double TransferIn, Double TransferOut, Double InterestRateType) {
        super(AccountId, AccountType, DisplayName, Description, Status, AccountDescriptorId, CustomerId);
        this.AccountMasterId = AccountMasterId;
        this.ParentAccountId = ParentAccountId;
        this.Nickname = Nickname;
        this.LineOfBusiness = LineOfBusiness;
        this.AccountNumber = AccountNumber;
        this.InterestRate = InterestRate;
        this.Currency = Currency;
        this.AccDescriptorId = AccDescriptorId;
        this.TransferIn = TransferIn;
        this.TransferOut = TransferOut;
        this.InterestRateType = InterestRateType;
    }

    /**
     * Returns the AccountMasterId.
     * 
     * @return
     *     AccountMasterId
     */
    public String getAccountMasterId() {
        return AccountMasterId;
    }

    /**
     * Set the AccountMasterId.
     * 
     * @param AccountMasterId
     *     the new AccountMasterId
     */
    public void setAccountMasterId(String AccountMasterId) {
        this.AccountMasterId = AccountMasterId;
    }

    /**
     * Returns the ParentAccountId.
     * 
     * @return
     *     ParentAccountId
     */
    public String getParentAccountId() {
        return ParentAccountId;
    }

    /**
     * Set the ParentAccountId.
     * 
     * @param ParentAccountId
     *     the new ParentAccountId
     */
    public void setParentAccountId(String ParentAccountId) {
        this.ParentAccountId = ParentAccountId;
    }

    /**
     * Returns the Nickname.
     * 
     * @return
     *     Nickname
     */
    public String getNickname() {
        return Nickname;
    }

    /**
     * Set the Nickname.
     * 
     * @param Nickname
     *     the new Nickname
     */
    public void setNickname(String Nickname) {
        this.Nickname = Nickname;
    }

    /**
     * Returns the LineOfBusiness.
     * 
     * @return
     *     LineOfBusiness
     */
    public String getLineOfBusiness() {
        return LineOfBusiness;
    }

    /**
     * Set the LineOfBusiness.
     * 
     * @param LineOfBusiness
     *     the new LineOfBusiness
     */
    public void setLineOfBusiness(String LineOfBusiness) {
        this.LineOfBusiness = LineOfBusiness;
    }

    /**
     * Returns the AccountNumber.
     * 
     * @return
     *     AccountNumber
     */
    public String getAccountNumber() {
        return AccountNumber;
    }

    /**
     * Set the AccountNumber.
     * 
     * @param AccountNumber
     *     the new AccountNumber
     */
    public void setAccountNumber(String AccountNumber) {
        this.AccountNumber = AccountNumber;
    }

    /**
     * Returns the InterestRate.
     * 
     * @return
     *     InterestRate
     */
    public Double getInterestRate() {
        return InterestRate;
    }

    /**
     * Set the InterestRate.
     * 
     * @param InterestRate
     *     the new InterestRate
     */
    public void setInterestRate(Double InterestRate) {
        this.InterestRate = InterestRate;
    }

    /**
     * Returns the Currency.
     * 
     * @return
     *     Currency
     */
    public String getCurrency() {
        return Currency;
    }

    /**
     * Set the Currency.
     * 
     * @param Currency
     *     the new Currency
     */
    public void setCurrency(String Currency) {
        this.Currency = Currency;
    }

    /**
     * Returns the AccDescriptorId.
     * 
     * @return
     *     AccDescriptorId
     */
    public Double getAccDescriptorId() {
        return AccDescriptorId;
    }

    /**
     * Set the AccDescriptorId.
     * 
     * @param AccDescriptorId
     *     the new AccDescriptorId
     */
    public void setAccDescriptorId(Double AccDescriptorId) {
        this.AccDescriptorId = AccDescriptorId;
    }

    /**
     * Returns the TransferIn.
     * 
     * @return
     *     TransferIn
     */
    public Double getTransferIn() {
        return TransferIn;
    }

    /**
     * Set the TransferIn.
     * 
     * @param TransferIn
     *     the new TransferIn
     */
    public void setTransferIn(Double TransferIn) {
        this.TransferIn = TransferIn;
    }

    /**
     * Returns the TransferOut.
     * 
     * @return
     *     TransferOut
     */
    public Double getTransferOut() {
        return TransferOut;
    }

    /**
     * Set the TransferOut.
     * 
     * @param TransferOut
     *     the new TransferOut
     */
    public void setTransferOut(Double TransferOut) {
        this.TransferOut = TransferOut;
    }

    /**
     * Returns the InterestRateType.
     * 
     * @return
     *     InterestRateType
     */
    public Double getInterestRateType() {
        return InterestRateType;
    }

    /**
     * Set the InterestRateType.
     * 
     * @param InterestRateType
     *     the new InterestRateType
     */
    public void setInterestRateType(Double InterestRateType) {
        this.InterestRateType = InterestRateType;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(AccountMasterId).append(ParentAccountId).append(Nickname).append(LineOfBusiness).append(AccountNumber).append(InterestRate).append(Currency).append(AccDescriptorId).append(TransferIn).append(TransferOut).append(InterestRateType).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(AccountMasterId, otherObject.AccountMasterId).append(ParentAccountId, otherObject.ParentAccountId).append(Nickname, otherObject.Nickname).append(LineOfBusiness, otherObject.LineOfBusiness).append(AccountNumber, otherObject.AccountNumber).append(InterestRate, otherObject.InterestRate).append(Currency, otherObject.Currency).append(AccDescriptorId, otherObject.AccDescriptorId).append(TransferIn, otherObject.TransferIn).append(TransferOut, otherObject.TransferOut).append(InterestRateType, otherObject.InterestRateType).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("AccountMasterId", AccountMasterId).append("ParentAccountId", ParentAccountId).append("Nickname", Nickname).append("LineOfBusiness", LineOfBusiness).append("AccountNumber", AccountNumber).append("InterestRate", InterestRate).append("Currency", Currency).append("AccDescriptorId", AccDescriptorId).append("TransferIn", TransferIn).append("TransferOut", TransferOut).append("InterestRateType", InterestRateType).toString();
    }

}
