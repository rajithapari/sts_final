package com.example.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;


import org.springframework.web.util.UriComponentsBuilder;



import com.example.demo.statement.Statement;
import com.example.demo.statement.StatementJdbcRepository;




@RestController
@RequestMapping("/api")

public class RestControllerExample {
	
	@Autowired
	StatementJdbcRepository statementJdbcRepository; 

	

	
	

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/statement/{idaccount}", method = RequestMethod.GET)
	public ResponseEntity<?> getUser(@PathVariable("idaccount") String idaccount) {
		
		Statement statement = statementJdbcRepository.findById(idaccount);
		if (statement == null) {
			
			return new ResponseEntity("No record Found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Statement>(statement, HttpStatus.OK);
	}

	

}
