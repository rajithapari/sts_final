package com.example.demo.statement;

public class Statement {

	private String idaccount;
	private String statementid;
	private String statementdate;
	public Statement(String idaccount, String statementid, String statementdate) {
		super();
		this.idaccount = idaccount;
		this.statementid = statementid;
		this.statementdate = statementdate;
	}
	public Statement() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getIdaccount() {
		return idaccount;
	}
	public void setIdaccount(String idaccount) {
		this.idaccount = idaccount;
	}
	public String getStatementid() {
		return statementid;
	}
	public void setStatementid(String statementid) {
		this.statementid = statementid;
	}
	public String getStatementdate() {
		return statementdate;
	}
	public void setStatementdate(String statementdate) {
		this.statementdate = statementdate;
	}
	
	public String toString() {
		return "Statement [idaccount=" + idaccount + ", statementid=" + statementid + ", statementdate=" + statementdate + "]";
	}
	
}
