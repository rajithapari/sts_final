package com.example.demo.statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class StatementJdbcRepository {

	@Autowired
    JdbcTemplate jdbcTemplate;
	
	public Statement findById(String idaccount) {
	    /*return jdbcTemplate.queryForObject("select * from test_kunal.statement where idaccount=?", new Object[] {
	    		idaccount
	        },*/
		
		return jdbcTemplate.queryForObject("select st.* from statement as st , accountdescriptor as adsc where st.idaccount = adsc.accountid and adsc.idaccountdescriptor = (select ac.accountdescriptor from account as ac, accountdescriptor as ad  where ac.idaccount = ? and ac.accountdescriptor = ad.idaccountdescriptor) ;", new Object[] {
	    		idaccount
	        },
		
	        new StatementRowMapper());
	}
}
