package com.example.demo.statement;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class StatementRowMapper implements RowMapper<Statement>{

	@Override
	public Statement mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Statement statement = new Statement();
		statement.setIdaccount(rs.getString("idaccount"));
		statement.setStatementid(rs.getString("statementid"));
		statement.setStatementdate(rs.getString("statementdate"));
		return statement;
		
		
	}

}
