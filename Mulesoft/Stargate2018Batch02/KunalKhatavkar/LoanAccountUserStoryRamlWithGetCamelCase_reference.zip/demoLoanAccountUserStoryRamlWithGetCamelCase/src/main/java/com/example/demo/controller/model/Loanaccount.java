
package com.example.demo.controller.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
@Entity
@Table(name = "loanaccount")
public class Loanaccount
    extends Account
    implements Serializable
{

    final static long serialVersionUID = -1840211957440959443L;
    @Column
    private String loanAccountId;
    @Column
   // @JoinColumn(name="AccountrefId")
    private String accountrefId;
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column
    private Date balanceAsOf;
    @Column
    private Double principalBalance;
    @Column
    private Double originalPrincipal;
    @Column
    private Long loanTerm;
    @Column
    private Long totalNumberOfPayments;
    @Column
    private Double nextPaymentAmount;
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column
    private Date nextPaymentDate;
    @Column
    private Double lastPaymentAmount;
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Column
    private Date lastPaymentDate;
    @Column
    private String paymentFrequency;

    /**
     * Creates a new Loanaccount.
     * 
     */
    public Loanaccount() {
        super();
    }

    /**
     * Creates a new Loanaccount.
     * 
     */
    public Loanaccount(String accountId, IdentifierforAccounttype accountType, String displayName, String description, IdentifierforAccoundstatus status, Double accountDescriptorId, String customerId, String accountMasterId, String parentAccountId, String nickname, String lineOfBusiness, String accountNumber, Double interestRate, String currency, Double accDescriptorId, Double transferIn, Double transferOut, String interestRateType, String loanAccountId, String accountrefId, Date balanceAsOf, Double principalBalance, Double originalPrincipal, Long loanTerm, Long totalNumberOfPayments, Double nextPaymentAmount, Date nextPaymentDate, Double lastPaymentAmount, Date lastPaymentDate, String paymentFrequency) {
        super(accountId, accountType, displayName, description, status, accountDescriptorId, customerId, accountMasterId, parentAccountId, nickname, lineOfBusiness, accountNumber, interestRate, currency, accDescriptorId, transferIn, transferOut, interestRateType);
        this.loanAccountId = loanAccountId;
        this.accountrefId = accountrefId;
        this.balanceAsOf = balanceAsOf;
        this.principalBalance = principalBalance;
        this.originalPrincipal = originalPrincipal;
        this.loanTerm = loanTerm;
        this.totalNumberOfPayments = totalNumberOfPayments;
        this.nextPaymentAmount = nextPaymentAmount;
        this.nextPaymentDate = nextPaymentDate;
        this.lastPaymentAmount = lastPaymentAmount;
        this.lastPaymentDate = lastPaymentDate;
        this.paymentFrequency = paymentFrequency;
    }
    
    //la.BalanceAsOf,"
	//	+ " la.PrincipalBalance, la.OriginalPrincipal, la.LoanTerm, la.TotalNumberOfPayments, "
		//+ "la.NextPaymentAmount, la.NextPaymentDate, la.LastPaymentAmount, la.LastPaymentDate, "
	//	+ "acc.AccountMasterId, acc.Nickname, acc.LineOfBusiness, acc.AccountNumber, acc.InterestRate,"
	//	+ " acc.Currency, asd.AccountType, asd.CustomerId, asd.DisplayName, asd.Status"
	//	+ "
    
    public Loanaccount(Date balanceAsOf, Double principalBalance, Double originalPrincipal, Long loanTerm, Long totalNumberOfPayments, Double nextPaymentAmount, Date nextPaymentDate	,
    		Double lastPaymentAmount,Date lastPaymentDate, String nickname, String lineOfBusiness, String accountNumber, Double interestRate, String accountrefId, String accountMasterId,Double accDescriptorId ,Double accountDescriptorId) {
        super(nickname, lineOfBusiness, accountNumber, interestRate, accountMasterId, accDescriptorId, accountDescriptorId);
        this.accountrefId = accountrefId;
        this.balanceAsOf = balanceAsOf;
        this.principalBalance = principalBalance;
        this.originalPrincipal = originalPrincipal;
        this.loanTerm = loanTerm;
        this.totalNumberOfPayments = totalNumberOfPayments;
        this.nextPaymentAmount = nextPaymentAmount;
        this.nextPaymentDate = nextPaymentDate;
        this.lastPaymentAmount = lastPaymentAmount;
        this.lastPaymentDate = lastPaymentDate;
      
       
    }
 
    /**
     * Returns the loanAccountId.
     * 
     * @return
     *     loanAccountId
     */
    public String getLoanAccountId() {
        return loanAccountId;
    }

    /**
     * Set the loanAccountId.
     * 
     * @param loanAccountId
     *     the new loanAccountId
     */
    public void setLoanAccountId(String loanAccountId) {
        this.loanAccountId = loanAccountId;
    }

    /**
     * Returns the accountrefId.
     * 
     * @return
     *     accountrefId
     */
    public String getAccountrefId() {
        return accountrefId;
    }

    /**
     * Set the accountrefId.
     * 
     * @param accountrefId
     *     the new accountrefId
     */
    public void setAccountrefId(String accountrefId) {
        this.accountrefId = accountrefId;
    }

    /**
     * Returns the balanceAsOf.
     * 
     * @return
     *     balanceAsOf
     */
    public Date getBalanceAsOf() {
        return balanceAsOf;
    }

    /**
     * Set the balanceAsOf.
     * 
     * @param balanceAsOf
     *     the new balanceAsOf
     */
    public void setBalanceAsOf(Date balanceAsOf) {
        this.balanceAsOf = balanceAsOf;
    }

    /**
     * Returns the principalBalance.
     * 
     * @return
     *     principalBalance
     */
    public Double getPrincipalBalance() {
        return principalBalance;
    }

    /**
     * Set the principalBalance.
     * 
     * @param principalBalance
     *     the new principalBalance
     */
    public void setPrincipalBalance(Double principalBalance) {
        this.principalBalance = principalBalance;
    }

    /**
     * Returns the originalPrincipal.
     * 
     * @return
     *     originalPrincipal
     */
    public Double getOriginalPrincipal() {
        return originalPrincipal;
    }

    /**
     * Set the originalPrincipal.
     * 
     * @param originalPrincipal
     *     the new originalPrincipal
     */
    public void setOriginalPrincipal(Double originalPrincipal) {
        this.originalPrincipal = originalPrincipal;
    }

    /**
     * Returns the loanTerm.
     * 
     * @return
     *     loanTerm
     */
    public Long getLoanTerm() {
        return loanTerm;
    }

    /**
     * Set the loanTerm.
     * 
     * @param loanTerm
     *     the new loanTerm
     */
    public void setLoanTerm(Long loanTerm) {
        this.loanTerm = loanTerm;
    }

    /**
     * Returns the totalNumberOfPayments.
     * 
     * @return
     *     totalNumberOfPayments
     */
    public Long getTotalNumberOfPayments() {
        return totalNumberOfPayments;
    }

    /**
     * Set the totalNumberOfPayments.
     * 
     * @param totalNumberOfPayments
     *     the new totalNumberOfPayments
     */
    public void setTotalNumberOfPayments(Long totalNumberOfPayments) {
        this.totalNumberOfPayments = totalNumberOfPayments;
    }

    /**
     * Returns the nextPaymentAmount.
     * 
     * @return
     *     nextPaymentAmount
     */
    public Double getNextPaymentAmount() {
        return nextPaymentAmount;
    }

    /**
     * Set the nextPaymentAmount.
     * 
     * @param nextPaymentAmount
     *     the new nextPaymentAmount
     */
    public void setNextPaymentAmount(Double nextPaymentAmount) {
        this.nextPaymentAmount = nextPaymentAmount;
    }

    /**
     * Returns the nextPaymentDate.
     * 
     * @return
     *     nextPaymentDate
     */
    public Date getNextPaymentDate() {
        return nextPaymentDate;
    }

    /**
     * Set the nextPaymentDate.
     * 
     * @param nextPaymentDate
     *     the new nextPaymentDate
     */
    public void setNextPaymentDate(Date nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    /**
     * Returns the lastPaymentAmount.
     * 
     * @return
     *     lastPaymentAmount
     */
    public Double getLastPaymentAmount() {
        return lastPaymentAmount;
    }

    /**
     * Set the lastPaymentAmount.
     * 
     * @param lastPaymentAmount
     *     the new lastPaymentAmount
     */
    public void setLastPaymentAmount(Double lastPaymentAmount) {
        this.lastPaymentAmount = lastPaymentAmount;
    }

    /**
     * Returns the lastPaymentDate.
     * 
     * @return
     *     lastPaymentDate
     */
    public Date getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * Set the lastPaymentDate.
     * 
     * @param lastPaymentDate
     *     the new lastPaymentDate
     */
    public void setLastPaymentDate(Date lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }

    /**
     * Returns the paymentFrequency.
     * 
     * @return
     *     paymentFrequency
     */
    public String getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Set the paymentFrequency.
     * 
     * @param paymentFrequency
     *     the new paymentFrequency
     */
    public void setPaymentFrequency(String paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(loanAccountId).append(accountrefId).append(balanceAsOf).append(principalBalance).append(originalPrincipal).append(loanTerm).append(totalNumberOfPayments).append(nextPaymentAmount).append(nextPaymentDate).append(lastPaymentAmount).append(lastPaymentDate).append(paymentFrequency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Loanaccount otherObject = ((Loanaccount) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(loanAccountId, otherObject.loanAccountId).append(accountrefId, otherObject.accountrefId).append(balanceAsOf, otherObject.balanceAsOf).append(principalBalance, otherObject.principalBalance).append(originalPrincipal, otherObject.originalPrincipal).append(loanTerm, otherObject.loanTerm).append(totalNumberOfPayments, otherObject.totalNumberOfPayments).append(nextPaymentAmount, otherObject.nextPaymentAmount).append(nextPaymentDate, otherObject.nextPaymentDate).append(lastPaymentAmount, otherObject.lastPaymentAmount).append(lastPaymentDate, otherObject.lastPaymentDate).append(paymentFrequency, otherObject.paymentFrequency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("loanAccountId", loanAccountId).append("accountrefId", accountrefId).append("balanceAsOf", balanceAsOf).append("principalBalance", principalBalance).append("originalPrincipal", originalPrincipal).append("loanTerm", loanTerm).append("totalNumberOfPayments", totalNumberOfPayments).append("nextPaymentAmount", nextPaymentAmount).append("nextPaymentDate", nextPaymentDate).append("lastPaymentAmount", lastPaymentAmount).append("lastPaymentDate", lastPaymentDate).append("paymentFrequency", paymentFrequency).toString();
    }

}
