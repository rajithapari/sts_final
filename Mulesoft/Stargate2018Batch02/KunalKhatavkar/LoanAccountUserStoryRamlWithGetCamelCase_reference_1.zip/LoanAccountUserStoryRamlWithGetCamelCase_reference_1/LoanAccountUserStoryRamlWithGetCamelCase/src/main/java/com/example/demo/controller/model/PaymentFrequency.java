
package com.example.demo.controller.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonProperty;

public enum PaymentFrequency {

    @JsonProperty("DAILY")
    DAILY("DAILY"),
    @JsonProperty("WEEKLY")
    WEEKLY("WEEKLY"),
    @JsonProperty("BIWEELKLY")
    BIWEELKLY("BIWEELKLY"),
    @JsonProperty("MONTHLY")
    MONTHLY("MONTHLY"),
    @JsonProperty("ANNULY")
    ANNULY("ANNULY");
    private final String value;
    private final static Map<String, PaymentFrequency> VALUE_CACHE = new HashMap<String, PaymentFrequency>();

    static {
        for (PaymentFrequency c: values()) {
            VALUE_CACHE.put(c.value, c);
        }
    }

    private PaymentFrequency(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static PaymentFrequency fromValue(String value) {
        return VALUE_CACHE.get(value);
    }

    @Override
    public String toString() {
        return this.value;
    }

}
