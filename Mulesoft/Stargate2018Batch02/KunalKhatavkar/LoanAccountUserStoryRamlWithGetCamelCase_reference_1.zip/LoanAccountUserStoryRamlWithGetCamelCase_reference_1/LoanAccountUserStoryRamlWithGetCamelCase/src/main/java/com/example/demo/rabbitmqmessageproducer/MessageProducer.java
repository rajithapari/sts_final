package com.example.demo.rabbitmqmessageproducer;

import java.util.List;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.example.demo.controller.model.Loanaccount;



@Component
public class MessageProducer {    
  private final RabbitTemplate rabbitTemplate;   
  
  @Autowired
  public MessageProducer(RabbitTemplate template) {
      this.rabbitTemplate = template;
  }
   
  
  @Bean
  public Queue queue() {
      return new Queue("spring-boot-kunal", false);
  }
  public void sendMessage(List<Loanaccount> loanaccountmessage) {        
    rabbitTemplate.convertAndSend("spring-boot-kunal", loanaccountmessage.toString());    
  }
}