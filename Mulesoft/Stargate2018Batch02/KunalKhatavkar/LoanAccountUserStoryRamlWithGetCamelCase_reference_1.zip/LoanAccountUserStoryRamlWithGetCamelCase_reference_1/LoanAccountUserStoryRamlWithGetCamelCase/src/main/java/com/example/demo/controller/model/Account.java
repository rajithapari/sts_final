
package com.example.demo.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.MappedSuperclass;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
@Entity
@Table(name = "account")
//@PrimaryKeyJoinColumn(name="AccountDescriptorId")
public class Account
    extends Accountdescriptor
    implements Serializable
{

    final static long serialVersionUID = -1840211957440959443L;
    @Column
    //@JoinColumn(name="AccountMasterId")
    private String accountMasterId;
    @Column
    private String parentAccountId;
    @Column
    private String nickname;
    @Column
    private String lineOfBusiness;
    @Column
    private String accountNumber;
    @Column
    private Double interestRate;
    @Column
    private String currency;
    @Column
    @JoinColumn(name="AccDescriptorId")
    private Double accDescriptorId;
    @Column
    private Double transferIn;
    @Column
    private Double transferOut;
    @Column
    private String interestRateType;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
    public Account(String accountId, IdentifierforAccounttype accountType, String displayName, String description, IdentifierforAccoundstatus status, Double accountDescriptorId, String customerId, String accountMasterId, String parentAccountId, String nickname, String lineOfBusiness, String accountNumber, Double interestRate, String currency, Double accDescriptorId, Double transferIn, Double transferOut, String interestRateType) {
        super(accountId, accountType, displayName, description, status, accountDescriptorId, customerId );
        this.accountMasterId = accountMasterId;
        this.parentAccountId = parentAccountId;
        this.nickname = nickname;
        this.lineOfBusiness = lineOfBusiness;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.currency = currency;
        this.accDescriptorId = accDescriptorId;
        this.transferIn = transferIn;
        this.transferOut = transferOut;
        this.interestRateType = interestRateType;
    }

    public Account(String nickname, String lineOfBusiness, String accountNumber, Double interestRate, String accountMasterId, Double accDescriptorId, Double accountDescriptorId) 
    {   super(accountDescriptorId);
        this.accountMasterId=accountMasterId;
        this.nickname = nickname;
        this.lineOfBusiness = lineOfBusiness;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.accDescriptorId = accDescriptorId;
	}

	/**
     * Returns the accountMasterId.
     * 
     * @return
     *     accountMasterId
     */
    public String getAccountMasterId() {
        return accountMasterId;
    }

    /**
     * Set the accountMasterId.
     * 
     * @param accountMasterId
     *     the new accountMasterId
     */
    public void setAccountMasterId(String accountMasterId) {
        this.accountMasterId = accountMasterId;
    }

    /**
     * Returns the parentAccountId.
     * 
     * @return
     *     parentAccountId
     */
    public String getParentAccountId() {
        return parentAccountId;
    }

    /**
     * Set the parentAccountId.
     * 
     * @param parentAccountId
     *     the new parentAccountId
     */
    public void setParentAccountId(String parentAccountId) {
        this.parentAccountId = parentAccountId;
    }

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * Set the nickname.
     * 
     * @param nickname
     *     the new nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    /**
     * Returns the lineOfBusiness.
     * 
     * @return
     *     lineOfBusiness
     */
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    /**
     * Set the lineOfBusiness.
     * 
     * @param lineOfBusiness
     *     the new lineOfBusiness
     */
    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     */
    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    /**
     * Returns the currency.
     * 
     * @return
     *     currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Set the currency.
     * 
     * @param currency
     *     the new currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * Returns the accDescriptorId.
     * 
     * @return
     *     accDescriptorId
     */
    public Double getAccDescriptorId() {
        return accDescriptorId;
    }

    /**
     * Set the accDescriptorId.
     * 
     * @param accDescriptorId
     *     the new accDescriptorId
     */
    public void setAccDescriptorId(Double accDescriptorId) {
        this.accDescriptorId = accDescriptorId;
    }

    /**
     * Returns the transferIn.
     * 
     * @return
     *     transferIn
     */
    public Double getTransferIn() {
        return transferIn;
    }

    /**
     * Set the transferIn.
     * 
     * @param transferIn
     *     the new transferIn
     */
    public void setTransferIn(Double transferIn) {
        this.transferIn = transferIn;
    }

    /**
     * Returns the transferOut.
     * 
     * @return
     *     transferOut
     */
    public Double getTransferOut() {
        return transferOut;
    }

    /**
     * Set the transferOut.
     * 
     * @param transferOut
     *     the new transferOut
     */
    public void setTransferOut(Double transferOut) {
        this.transferOut = transferOut;
    }

    /**
     * Returns the interestRateType.
     * 
     * @return
     *     interestRateType
     */
    public String getInterestRateType() {
        return interestRateType;
    }

    /**
     * Set the interestRateType.
     * 
     * @param interestRateType
     *     the new interestRateType
     */
    public void setInterestRateType(String interestRateType) {
        this.interestRateType = interestRateType;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(accountMasterId).append(parentAccountId).append(nickname).append(lineOfBusiness).append(accountNumber).append(interestRate).append(currency).append(accDescriptorId).append(transferIn).append(transferOut).append(interestRateType).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(accountMasterId, otherObject.accountMasterId).append(parentAccountId, otherObject.parentAccountId).append(nickname, otherObject.nickname).append(lineOfBusiness, otherObject.lineOfBusiness).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).append(currency, otherObject.currency).append(accDescriptorId, otherObject.accDescriptorId).append(transferIn, otherObject.transferIn).append(transferOut, otherObject.transferOut).append(interestRateType, otherObject.interestRateType).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("accountMasterId", accountMasterId).append("parentAccountId", parentAccountId).append("nickname", nickname).append("lineOfBusiness", lineOfBusiness).append("accountNumber", accountNumber).append("interestRate", interestRate).append("currency", currency).append("accDescriptorId", accDescriptorId).append("transferIn", transferIn).append("transferOut", transferOut).append("interestRateType", interestRateType).toString();
    }

}
