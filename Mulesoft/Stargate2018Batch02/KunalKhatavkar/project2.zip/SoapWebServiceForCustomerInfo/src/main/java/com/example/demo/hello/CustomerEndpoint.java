package com.example.demo.hello;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import customerswebservice.customers.Customers;
import customerswebservice.customers.GetCustomerRequest;
import customerswebservice.customers.GetCustomerResponse;
import customerswebservice.customers.GetCustomerbyidRequest;
import customerswebservice.customers.GetCustomerbyidResponse;
import customerswebservice.customers.GetCustomerbyidandupdateRequest;
import customerswebservice.customers.GetCustomerbyidandupdateResponse;



@Endpoint
public class CustomerEndpoint {
	private static final String NAMESPACE_URI = "http://customerswebservice/customers";

	private CustomerRepository customerRepository;

	@Autowired
	public CustomerEndpoint(CustomerRepository customerRepository) {
		this.customerRepository = customerRepository;
	}

	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCustomerRequest")
	@ResponsePayload
	public GetCustomerResponse getCustomers(@RequestPayload GetCustomerRequest request) {
		GetCustomerResponse response = new GetCustomerResponse();
		@SuppressWarnings("unchecked")
		List<Customers> cust = customerRepository.getCustomersData();
		response.getCustomers().addAll(cust);
		return response;
	}
	
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCustomerbyidRequest")
	@ResponsePayload
	public GetCustomerbyidResponse getCustomers(@RequestPayload GetCustomerbyidRequest request) {
		GetCustomerbyidResponse response = new GetCustomerbyidResponse();
		response.setCustomers(customerRepository.findCustomers(request.getId()));
		
		return response;
	}
	
	/*@PayloadRoot(namespace = NAMESPACE_URI, localPart = "getCustomerbyidandupdateRequest")
	@ResponsePayload
	public GetCustomerbyidandupdateResponse getCustomers(@RequestPayload GetCustomerbyidandupdateRequest request) {
		GetCustomerbyidResponse response = new GetCustomerbyidResponse();
		response.setCustomers(customerRepository.findCustomers(request.getId()));
		
		return response;
	}*/
}


	
	