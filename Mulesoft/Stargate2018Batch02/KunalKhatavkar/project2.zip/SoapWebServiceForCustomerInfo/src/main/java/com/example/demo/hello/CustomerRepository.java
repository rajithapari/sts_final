package com.example.demo.hello;


import javax.annotation.PostConstruct;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import customerswebservice.customers.Customers;


import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

@Component
public class CustomerRepository {
	private static final Map<Integer, Customers> customers = new HashMap<>();

	@PostConstruct
	public void initData() {
		Customers c1 = new Customers();
		c1.setName("ABC");
		c1.setId(111);
		c1.setAddress("Pune");
		
	

		customers.put(c1.getId(), c1);

		Customers c2 = new Customers();
		c2.setName("LMN");
		c2.setId(222);
		c2.setAddress("Mumbai");
		

		customers.put(c2.getId(), c2);

		Customers c3 = new Customers();
		c3.setName("XYZ");
		c3.setId(333);
		c3.setAddress("Nagpur");

		customers.put(c3.getId(), c3);
	
	}

	public List getCustomersData() {
		
		List<Customers> list = new ArrayList<Customers>();
		
		Iterator it = customers.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pair = (Map.Entry)it.next();
	        Customers c = (Customers)pair.getValue();
	        System.out.println(pair.getKey() + " = " + pair.getValue());
	        list.add(c);
	        
	    }
		return list;
	}
	
	public Customers findCustomers(int id) {
		Assert.notNull(id, "The Customer id must not be null");
		return customers.get(id);
	}
	
	/*public Customers UpdateCustomers(int id, String address) {
		Assert.notNull(id, "The Customer id must not be null");
	    Customers cust =  customers.get(id);
	}*/
}
