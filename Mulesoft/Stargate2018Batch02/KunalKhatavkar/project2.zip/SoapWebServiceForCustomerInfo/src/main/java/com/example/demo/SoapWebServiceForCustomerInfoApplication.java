package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapWebServiceForCustomerInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoapWebServiceForCustomerInfoApplication.class, args);
	}
}
