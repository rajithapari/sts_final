package com.kunal.springweb;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {

	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public ModelAndView helloWorld(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("inconrtoller");
		String fname= req.getParameter("firstname");
		String lname= req.getParameter("lastname");
		ModelAndView model = new ModelAndView("hello");
		model.addObject("message", "Welcome to Stargate " + fname + " " + lname);
		return model;
	}

	/*
	 * @RequestMapping(value="/hello", method = RequestMethod.GET) public String
	 * user(Model model) { System.out.println("User Page Requested");
	 * model.addAttribute("message","Welcome to Stargate"); return "hellopage"; }
	 */
}