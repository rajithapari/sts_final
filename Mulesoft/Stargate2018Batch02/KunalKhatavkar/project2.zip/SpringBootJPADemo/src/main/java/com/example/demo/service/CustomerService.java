package com.example.demo.service;

import com.example.demo.customer.CustomerRepository;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.customer.Customer;

@Repository
public class CustomerService {

	@Autowired
	public CustomerRepository cusrep;
	
	
	public List<Customer> getAllCustomer(){
		List<Customer> list = (List)cusrep.findAll();
		return list;
		
	}
}
