DROP TABLE IF EXISTS customers;

CREATE TABLE customers
(
    id int(3) NOT NULL,
    firstname varchar(200) NOT NULL,
    lastname varchar(500) DEFAULT NULL,
    PRIMARY KEY (id)
);
