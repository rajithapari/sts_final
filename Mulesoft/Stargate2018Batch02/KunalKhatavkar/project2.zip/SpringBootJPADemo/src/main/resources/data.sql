insert into customers(id,firstname,lastname) values(111,'Amol','Patil');
insert into customers(id,firstname,lastname) values(222,'Amit','Joshi');
insert into customers(id,firstname,lastname) values(333,'Kailas','Deho');
insert into customers(id,firstname,lastname) values(444,'Suraj','Gelo');
