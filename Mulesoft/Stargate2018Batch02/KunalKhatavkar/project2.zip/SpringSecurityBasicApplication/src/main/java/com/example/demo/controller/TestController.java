package com.example.demo.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
@RestController
@EnableAutoConfiguration
@RequestMapping("/security")
public class TestController {

	// @GetMapping("/messages")
	 @RequestMapping(value = "/messages", method = RequestMethod.GET)
		public String greetingmessages(){
			return "Hello message";
		}
	
	// @GetMapping("/world")
	 @RequestMapping(value = "/world", method = RequestMethod.GET)
		public String greetingworld(){
			return "Hello world";
		}
	 
	/* @RequestMapping(value = "/hello", method = RequestMethod.GET)
		public ModelAndView helloWorld() {
			System.out.println("inconrtoller");
			
			ModelAndView model = new ModelAndView("hello");
			model.addObject("message", "Welcome to Stargate " );
			return model;
		}*/
}
