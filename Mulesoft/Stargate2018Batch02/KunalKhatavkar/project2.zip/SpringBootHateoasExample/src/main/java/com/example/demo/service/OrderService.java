package com.example.demo.service;

import java.util.List;

public interface OrderService {

	List<Order> getAllOrdersForCustomer(String customerId);

    Order getOrderByIdForCustomer(String customerId, String orderId);

	
}
