package com.example.demo.employee;

public class Employee {

	
	private int empid;
	private String empfirstname;
	private String emplastname;
	
	public Employee(){
		
	}
	public Employee(int empid, String empfirstname, String emplastname) {
		super();
		this.empid = empid;
		this.empfirstname = empfirstname;
		this.emplastname = emplastname;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpfirstname() {
		return empfirstname;
	}
	public void setEmpfirstname(String empfirstname) {
		this.empfirstname = empfirstname;
	}
	public String getEmplastname() {
		return emplastname;
	}
	public void setEmplastname(String emplastname) {
		this.emplastname = emplastname;
	}
	
	public String toString() {
		return "Employee [empid=" + empid + ", empfirstname=" + empfirstname + ", emplastname=" + emplastname + "]";
	}
}
