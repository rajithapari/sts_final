package com.example.demo.employee;

import java.sql.ResultSet;
import java.sql.SQLException;


import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;



@Component
public class EmployeeRowMapper implements RowMapper<Employee>{

	@Override
	public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Employee employee = new Employee();
		employee.setEmpid(rs.getInt("EmpId"));
		employee.setEmpfirstname(rs.getString("EmpFirstName"));
		employee.setEmplastname(rs.getString("EmpLastName"));
		return employee;
		
		
		
		
	}

}


