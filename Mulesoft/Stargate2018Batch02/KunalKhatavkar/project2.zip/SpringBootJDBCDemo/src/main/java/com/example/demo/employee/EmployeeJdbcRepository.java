package com.example.demo.employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;




@Repository
public class EmployeeJdbcRepository {
	
	@Autowired
    JdbcTemplate jdbcTemplate;

	public Employee findById(int empid) {
	   
		return jdbcTemplate.queryForObject("select emp.* from test_kunal.employee as emp where emp.Empid=?", new Object[] {
				empid}, new EmployeeRowMapper());
	}
	
	public Snippet findByIDsnippet(String id){
		return jdbcTemplate.queryForObject("select sni.* from SNIPPET  as sni where sni.ID=?", new Object[] {
				id}, new SnippetRowMapper());
	}
	
	

}
