package com.example.demo.employee;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class SnippetRowMapper implements RowMapper<Snippet>{

	@Override
	public Snippet mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		Snippet snippet = new Snippet();
		snippet.setId(rs.getString("ID"));
		snippet.setTitle(rs.getString("TITLE"));
		snippet.setCode(rs.getString("CODE"));
		snippet.setModified(rs.getString("CREATED"));
		snippet.setCreated(rs.getString("MODIFIED"));
		
		
		
		return snippet;
		
	}
		
	}



