package com.example.demo.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.employee.Employee;
import com.example.demo.employee.Snippet;

@RestController
@RequestMapping("/api")
public class RestControllerExample {
	
	@Autowired
	com.example.demo.employee.EmployeeJdbcRepository employeeJdbcRepository;
	

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/employee/{empid}", method = RequestMethod.GET)
	public ResponseEntity<?> getUser(@PathVariable("empid") int empid) {
		
		Employee employee = employeeJdbcRepository.findById(empid);
		if (employee == null) {
			
			return new ResponseEntity("No record Found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Employee>(employee, HttpStatus.OK);
	}

	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/snippet/{id}", method = RequestMethod.GET)
	public ResponseEntity<?> getSnippet(@PathVariable("id") String id) {
		
		Snippet snippet = employeeJdbcRepository.findByIDsnippet(id);
		if (snippet == null) {
			
			return new ResponseEntity("No record Found", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Snippet>(snippet, HttpStatus.OK);
	}
	

}