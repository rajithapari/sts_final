package com.example.demo.employee;

public class Snippet {
	
	private String id;
	private String title;
	private String code;
	private String created;
	private String modified;
	public Snippet(String id, String title, String code, String created, String modified) {
		super();
		this.id = id;
		this.title = title;
		this.code = code;
		this.created = created;
		this.modified = modified;
	}
	public Snippet() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	
	public String toString() {
		return "Snippet [id=" + id + ", title=" + title + ", code=" + code + "]";
	}

	
	
	
}
