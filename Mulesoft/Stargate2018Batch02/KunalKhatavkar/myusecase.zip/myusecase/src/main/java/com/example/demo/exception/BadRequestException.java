package com.example.demo.exception;

import org.mule.api.MuleEvent;
import org.mule.api.exception.MessagingExceptionHandler;

public class BadRequestException implements MessagingExceptionHandler {

	@Override
	public MuleEvent handleException(Exception exception, MuleEvent event) {
		
	 
		
		return null;
	}

}
