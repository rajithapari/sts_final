/**
 * 
 */
package com.rest.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;

import bank_web_service.GetBankDetailsResponse;

@RestController
public class BankByIdController {

	@Autowired
	BankCatalogClient bankCatalogClient;

	@GetMapping(value = "/api/bank/{customerId}", produces = "application/json")
	public ResponseEntity<?> getProductById(@PathVariable("customerId") String customerId) {
		GetBankDetailsResponse response = bankCatalogClient.getBankById(customerId);
		Gson gson = new Gson();
		return new ResponseEntity<String>(gson.toJson(response).toString(), HttpStatus.OK);
	}
}
