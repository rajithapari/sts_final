package com.example.demo.exception;

import org.mule.api.MuleEvent;
import org.mule.extension.validation.api.ValidationResult;
import org.mule.extension.validation.api.Validator;
import org.mule.extension.validation.internal.ImmutableValidationResult;
import org.mule.module.http.internal.ParameterMap;

public class BadRequestValidator implements Validator{

	@Override
	public ValidationResult validate(MuleEvent event) {
		

	ParameterMap map = event.getMessage().getInboundProperty("http.query.params"); 
	String object = map.get("accountId");
	System.out.println("accountId : " + object );
	if(object != null){
		return ImmutableValidationResult.ok();
	}
	else{
		return ImmutableValidationResult.error("Account ID not present");
	}
}

}
