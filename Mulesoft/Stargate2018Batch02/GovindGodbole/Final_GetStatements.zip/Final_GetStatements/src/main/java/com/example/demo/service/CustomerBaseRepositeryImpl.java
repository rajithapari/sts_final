package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.dao.CustomerBaseRepositery;

public class CustomerBaseRepositeryImpl {

	@Autowired
	public CustomerBaseRepositery customerBaseRepositery;
	public List<String> getCusterId(String accountId)
	 {
		List<String> listOfCustIds = customerBaseRepositery.fetchCustIdDetails(accountId);		
		return listOfCustIds;
		 
	 }
}
