package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.controller.model.Statement;
import com.example.demo.dao.StatementsBaseRepository;

@Service
public class StatementsBaseRepositoryImpl {
	
	@Autowired
	public StatementsBaseRepository statementsBaseRepository;
	
	 public List<Statement> getAllStatements(String accountId,String startTime, String endTime)
	 {		 
		 List<Statement> listStatements= statementsBaseRepository.fetchStatementDetails(accountId,startTime,endTime);
		 return listStatements;
	 } 

}
