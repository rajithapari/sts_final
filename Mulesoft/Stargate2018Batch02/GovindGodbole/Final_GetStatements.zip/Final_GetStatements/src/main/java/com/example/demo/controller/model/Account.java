
package com.example.demo.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "account")
public class Account
    extends AccountDescriptor
    implements Serializable
{

    final static long serialVersionUID = 6218996539495437574L;
    @Column
    private String parentAccountId;
    @Column
    private Double accountMasterId;
    @Column
    private String lineOfBusiness;
    @Column
    private Double accDescriptorId;
    @Column
    private String nickname;
    @Column
    private String accountNumber;
    @Column
    private Double interestRate;
    @Column
    private Double transferIn;
    @Column
    private Double transferOut;
    @Column
    @Enumerated(EnumType.STRING)
    private Currency currency;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
    public Account(String accountId, AccountType accountType, String displayName, String description, Status status, String accountDescriptorId, String customerId, String parentAccountId, Double accountMasterId, String lineOfBusiness, Double accDescriptorId, String nickname, String accountNumber, Double interestRate, Double transferIn, Double transferOut, Currency currency) {
        super(accountId, accountType, displayName, description, status, accountDescriptorId, customerId);
        this.parentAccountId = parentAccountId;
        this.accountMasterId = accountMasterId;
        this.lineOfBusiness = lineOfBusiness;
        this.accDescriptorId = accDescriptorId;
        this.nickname = nickname;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.transferIn = transferIn;
        this.transferOut = transferOut;
        this.currency = currency;
    }

    /**
     * Returns the parentAccountId.
     * 
     * @return
     *     parentAccountId
     */
    public String getParentAccountId() {
        return parentAccountId;
    }

    /**
     * Set the parentAccountId.
     * 
     * @param parentAccountId
     *     the new parentAccountId
     */
    public void setParentAccountId(String parentAccountId) {
        this.parentAccountId = parentAccountId;
    }

    /**
     * Returns the accountMasterId.
     * 
     * @return
     *     accountMasterId
     */
    public Double getAccountMasterId() {
        return accountMasterId;
    }

    /**
     * Set the accountMasterId.
     * 
     * @param accountMasterId
     *     the new accountMasterId
     */
    public void setAccountMasterId(Double accountMasterId) {
        this.accountMasterId = accountMasterId;
    }

    /**
     * Returns the lineOfBusiness.
     * 
     * @return
     *     lineOfBusiness
     */
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    /**
     * Set the lineOfBusiness.
     * 
     * @param lineOfBusiness
     *     the new lineOfBusiness
     */
    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    /**
     * Returns the accDescriptorId.
     * 
     * @return
     *     accDescriptorId
     */
    public Double getAccDescriptorId() {
        return accDescriptorId;
    }

    /**
     * Set the accDescriptorId.
     * 
     * @param accDescriptorId
     *     the new accDescriptorId
     */
    public void setAccDescriptorId(Double accDescriptorId) {
        this.accDescriptorId = accDescriptorId;
    }

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * Set the nickname.
     * 
     * @param nickname
     *     the new nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     */
    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    /**
     * Returns the transferIn.
     * 
     * @return
     *     transferIn
     */
    public Double getTransferIn() {
        return transferIn;
    }

    /**
     * Set the transferIn.
     * 
     * @param transferIn
     *     the new transferIn
     */
    public void setTransferIn(Double transferIn) {
        this.transferIn = transferIn;
    }

    /**
     * Returns the transferOut.
     * 
     * @return
     *     transferOut
     */
    public Double getTransferOut() {
        return transferOut;
    }

    /**
     * Set the transferOut.
     * 
     * @param transferOut
     *     the new transferOut
     */
    public void setTransferOut(Double transferOut) {
        this.transferOut = transferOut;
    }

    /**
     * Returns the currency.
     * 
     * @return
     *     currency
     */
    public Currency getCurrency() {
        return currency;
    }

    /**
     * Set the currency.
     * 
     * @param currency
     *     the new currency
     */
    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(parentAccountId).append(accountMasterId).append(lineOfBusiness).append(accDescriptorId).append(nickname).append(accountNumber).append(interestRate).append(transferIn).append(transferOut).append(currency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(parentAccountId, otherObject.parentAccountId).append(accountMasterId, otherObject.accountMasterId).append(lineOfBusiness, otherObject.lineOfBusiness).append(accDescriptorId, otherObject.accDescriptorId).append(nickname, otherObject.nickname).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).append(transferIn, otherObject.transferIn).append(transferOut, otherObject.transferOut).append(currency, otherObject.currency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("parentAccountId", parentAccountId).append("accountMasterId", accountMasterId).append("lineOfBusiness", lineOfBusiness).append("accDescriptorId", accDescriptorId).append("nickname", nickname).append("accountNumber", accountNumber).append("interestRate", interestRate).append("transferIn", transferIn).append("transferOut", transferOut).append("currency", currency).toString();
    }

}
