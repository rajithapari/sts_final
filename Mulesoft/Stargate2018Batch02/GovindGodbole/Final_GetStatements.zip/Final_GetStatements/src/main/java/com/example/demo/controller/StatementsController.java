
package com.example.demo.controller;

import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.controller.model.AccountDescriptor;
import com.example.demo.controller.model.Statement;
import com.example.demo.dao.CustomerBaseRepositery;
import com.example.demo.exception.BadRequestException;
import com.example.demo.exception.MethodNotAllowedException;
import com.example.demo.exception.StatementsNotFoundException;
import com.example.demo.exception.StatementsResponseEntityExceptionHandler;
import com.example.demo.rabbitmq.MessageProducer;
import com.example.demo.service.StatementsBaseRepositoryImpl;
import com.example.demo.soapservice.BankCatalogClient;





/**
 * This is controller class, gets called when user hits URI "/account/accountID"
 * 
 */
@RestController
@RequestMapping(value = "/account/accountID", produces = "application/json")
@Validated
public class StatementsController {

		@Autowired
		private StatementsBaseRepositoryImpl statementsBaseRepositoryImpl;
		
		@Autowired
		private MessageProducer messageProducer;
		
		@Autowired
		CustomerBaseRepositery customerBaseRepositery;
		
		@Autowired
		BankCatalogClient bankCatalogClient;
		
		JSONObject obj = new JSONObject();
	
	    @RequestMapping(value = "", method = RequestMethod.GET)
		public ResponseEntity<?> getStatementBy(
				@RequestParam(required = true) String accountId,
				@RequestParam(defaultValue = "2000-01-01",required = false) String startTime,
				@RequestParam(defaultValue = "2018-10-22",required = false) String endTime,
				@RequestHeader(name = "Authorization", required = false) String authorization,
				@RequestHeader(name = "Accept", required = false) String contentType) 
		        {
					
	    				try{
	    					
							List<Statement> listStatements = statementsBaseRepositoryImpl.getAllStatements(accountId,startTime, endTime);
							AccountDescriptor accountDescriptor = new AccountDescriptor();
											
							// sending request to Rabbit MQ 
							messageProducer.sendMessage(listStatements);
							
							//calling SOAP by passing cust ID and getting response from wsdl
							List<String>customerId = customerBaseRepositery.fetchCustIdDetails(accountDescriptor.getCustomerId());
													    
							bankCatalogClient.getBankById(customerId.get(0));							
							
							return new ResponseEntity<List<Statement>>(listStatements, HttpStatus.OK);
		                }
	    			   //catches 400 type exception
					   catch (BadRequestException bde) 
						{
							return new StatementsResponseEntityExceptionHandler().forBadRequest(bde);
						}
	    			   //catches 404 type exception
					   catch (StatementsNotFoundException snfe) 
						{
							return new StatementsResponseEntityExceptionHandler().handleStatementNotFoundException(snfe);
		
						}
	    			   //catches 405 type exception
					   catch (MethodNotAllowedException mnae) 
						{
							return new StatementsResponseEntityExceptionHandler().handleMethodNotAcceptableException(mnae);
		
						}
	    				//catches 500 type exception
	    				catch (Exception excp) 
						{
							return new StatementsResponseEntityExceptionHandler().handleAllExceptions(excp);
						}

				}

}
