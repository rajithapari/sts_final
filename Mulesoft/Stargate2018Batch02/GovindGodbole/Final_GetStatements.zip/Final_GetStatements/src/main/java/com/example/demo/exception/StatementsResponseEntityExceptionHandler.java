package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/*
 * This class handle differ types of exception.
 */
@ControllerAdvice
@RestController
public class StatementsResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	

	@ExceptionHandler(value = BadRequestException.class)
	public final ResponseEntity<ExceptionResponse> forBadRequest(BadRequestException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Bad request", "400");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(value = UnauthorisedRequestException.class)
	public final ResponseEntity<ExceptionResponse> Anauthorised(BadRequestException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Anauthorised request", "401");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(value = StatementsNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleStatementNotFoundException(StatementsNotFoundException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Statement not found", "404");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = MethodNotAllowedException.class)
	public final ResponseEntity<ExceptionResponse> handleMethodNotAcceptableException(MethodNotAllowedException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Method Not Allowd", "405");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_ACCEPTABLE);
	}


	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ExceptionResponse> handleAllExceptions(Exception ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Internal Server Error, Pls check server status", "500");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
