package com.example.demo;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

/*
 * Class is used to log information for application
 */

@Aspect
@Component
public class StatementAopLogger {
	
	private static final Logger LOGGER = LogManager.getLogger(StatementAopLogger.class);	   
	
	@Pointcut("execution(* com.example.demo..*.*(..))") 
		public void point(){
			
		}   
		   
		@Before("point()")
		public void logBefore(JoinPoint joinPoint) {
			LOGGER.info("Started:"+joinPoint);
		}

		@After("point()")
		public void logAfter(JoinPoint joinPoint) {
			LOGGER.info("Completed:"+joinPoint);
		}

}
