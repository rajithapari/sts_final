package com.example.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.controller.model.Statement;


public interface StatementsBaseRepository extends JpaRepository<Statement, String>{
	
	@Query(value = "SELECT *  from  account acc, accountdescriptor asd, statement st where st.AccountId = asd.AccountId " 
            + "and acc.AccDescriptorId = asd.AccountDescriptorId and  st.AccountId= :AccountId "  
             + "and st.StatementDate BETWEEN :startTime AND :endTime", nativeQuery = true)
             //+ "and st.StatementDate BETWEEN startTime AND endTime ", nativeQuery = true)
    public List<Statement> fetchStatementDetails(@Param("AccountId") String accountId,
		                                       @Param("startTime") String startTime,
		                                       @Param("endTime") String endTime);
	
	
	
}
