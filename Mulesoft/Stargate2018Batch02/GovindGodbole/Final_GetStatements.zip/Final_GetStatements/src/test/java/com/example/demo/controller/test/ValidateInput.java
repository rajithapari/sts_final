package com.example.demo.controller.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ValidateInput 
{
	// method check for input empty, null or with char in accountID and valid input
	public boolean isValidAccountId(String accountId)
	{
		boolean result = false;
		if(accountId.length() == 0 || accountId == null || accountId.matches("[a-zA-Z\"]+"))
		{
			result = true;
		}
		else
		{
			if(accountId.length() > 128 )
			{
				result = true;
			}
		}
			return result;
	}
	
	//check for empty account id
	@Test
    public void isEmptyTest(){
		ValidateInput asft = new ValidateInput();
        assertTrue(asft.isValidAccountId(""));
    }
		
	//check for valid account id.
	@Test
    public void isValidAccountIdTest(){
		String input = "1357902468";
        assertTrue(input == "1357902468");
    }
	

	//check for account id with char init.
	@Test
    public void isaccountIdNonIntegerTest(){
		ValidateInput asft = new ValidateInput();
		assertFalse(asft.isValidAccountId("1357902468ASD"));
    }
	
	//check for valid account id more than length 128 
	@Test
    public void isAcoountIdTooBigTest(){
		String input = "1357902468135790246813579024681357902468135790246813579024681357902468135790246813579024681357902468135790246813579024681357902468135790246813579024681357902468135";
        assertTrue(input.length() > 128);
    }

}
