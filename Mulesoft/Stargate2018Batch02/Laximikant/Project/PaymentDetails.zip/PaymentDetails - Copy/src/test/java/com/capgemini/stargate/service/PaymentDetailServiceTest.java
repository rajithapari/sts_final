package com.capgemini.stargate.service;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PaymentDetailServiceTest {

	PaymentDetailServiceImpl paymentDetailService;
	
	@Before
	public void setup(){
		paymentDetailService = new PaymentDetailServiceImpl();
	}
	
	@Test
	public void isValidAccountTest4ValidAccount() {
		String accountId = "HSBC001456";
		boolean status = paymentDetailService.isValidAccount(accountId);
		Assert.assertFalse(status);
	}
	
	@Test
	public void isValidAccountTest4InValidAccount() {
		String accountId = "ICICI001456";
		boolean status = paymentDetailService.isValidAccount(accountId);
		
		Assert.assertTrue(status);
	}


}
