package com.capgemini.stargate.validation;

import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

@Service
public class Validator {

	public boolean validateAccountId(String accountId){
		
		final Pattern pattern = Pattern.compile("\\d++");
		if (pattern.matcher(accountId).matches() && accountId != null) 
	   	{ 
			return true;
	   	}
		else
		{
			return false;
		}
	}
	
}
