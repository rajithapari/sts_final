
package com.capgemini.stargate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="paymentdetails")
public class PaymentDetails implements Serializable
{

    final static long serialVersionUID = -436049095975343010L;
    /**
     * The amount borrowed (such as the face value of a debt security), or                       the part of the amount borrowed which remains unpaid
     * 
     */
    @Id
    @Column(name="PaymentId")
    @JsonIgnoreProperties
    private String PaymentId;
    
    @Column(name="LoanTransactionId")
    @JsonIgnoreProperties
    private String LoanTransactionId;
    
    
	@Column(name="PrincipalAmount")
    private Double principalAmount;
    /**
     * he proportion of an amount loaned which a lender charges as interest                      to the borrower
     * 
     */
    @Column(name="InterestAmount")
    private Double interestAmount;
    /**
     * The maximum amount an insurance company will pay if an insured asset                      is deemed a total loss.
     * 
     */
    @Column(name="InsuranceAmount")
    private Double insuranceAmount;
    /**
     * Escrow generally refers to money held by a third-party on behalf of                       transacting parties
     * 
     */
    @Column(name="EscrowAmount")
    private Double escrowAmount;
    /**
     * PMI is an insurance policy that protects the holder against loss                          resulting from default on a mortgage loan.
     * 
     */
    @Column(name="PmiAmount")
    private Double pmiAmount;
    /**
     * A fee is the amount of money that a person or organization is paid                        for a particular job or service that they provide.
     * 
     */
    @Column(name="FeesAmount")
    private Double feesAmount;

    /**
     * Creates a new PaymentDetails.
     * 
     */
    public PaymentDetails() {
        super();
    }

    /**
     * Creates a new PaymentDetails.
     * 
     */
    
    
    public PaymentDetails(String paymentId, String loanTransactionId, Double principalAmount, Double interestAmount,
			Double insuranceAmount, Double escrowAmount, Double pmiAmount, Double fessAmount) {
		super();
		this.PaymentId = paymentId;
		this.LoanTransactionId = loanTransactionId;
		this.principalAmount = principalAmount;
		this.interestAmount = interestAmount;
		this.insuranceAmount = insuranceAmount;
		this.escrowAmount = escrowAmount;
		this.pmiAmount = pmiAmount;
		this.feesAmount = fessAmount;
	}

  /*public String getPaymentId() {
		return PaymentId;
	}

	public void setPaymentId(String paymentId) {
		PaymentId = paymentId;
	}*/

	  /*public String getLoanTransactionId() {
		return LoanTransactionId;
	}

	public void setLoanTransactionId(String loanTransactionId) {
		LoanTransactionId = loanTransactionId;
	}*/

    
    
	/**
     * Returns the principalAmount.
     * 
     * @return
     *     principalAmount
     */
    public Double getPrincipalAmount() {
        return principalAmount;
    }

    /**
     * Set the principalAmount.
     * 
     * @param principalAmount
     *     the new principalAmount
     */
    public void setPrincipalAmount(Double principalAmount) {
        this.principalAmount = principalAmount;
    }

    /**
     * Returns the interestAmount.
     * 
     * @return
     *     interestAmount
     */
    public Double getInterestAmount() {
        return interestAmount;
    }

    /**
     * Set the interestAmount.
     * 
     * @param interestAmount
     *     the new interestAmount
     */
    public void setInterestAmount(Double interestAmount) {
        this.interestAmount = interestAmount;
    }

    /**
     * Returns the insuranceAmount.
     * 
     * @return
     *     insuranceAmount
     */
    public Double getInsuranceAmount() {
        return insuranceAmount;
    }

    /**
     * Set the insuranceAmount.
     * 
     * @param insuranceAmount
     *     the new insuranceAmount
     */
    public void setInsuranceAmount(Double insuranceAmount) {
        this.insuranceAmount = insuranceAmount;
    }

    /**
     * Returns the escrowAmount.
     * 
     * @return
     *     escrowAmount
     */
    public Double getEscrowAmount() {
        return escrowAmount;
    }

    /**
     * Set the escrowAmount.
     * 
     * @param escrowAmount
     *     the new escrowAmount
     */
    public void setEscrowAmount(Double escrowAmount) {
        this.escrowAmount = escrowAmount;
    }

    /**
     * Returns the pmiAmount.
     * 
     * @return
     *     pmiAmount
     */
    public Double getPmiAmount() {
        return pmiAmount;
    }

    /**
     * Set the pmiAmount.
     * 
     * @param pmiAmount
     *     the new pmiAmount
     */
    public void setPmiAmount(Double pmiAmount) {
        this.pmiAmount = pmiAmount;
    }

    /**
     * Returns the fessAmount.
     * 
     * @return
     *     fessAmount
     */
    public Double getFessAmount() {
        return feesAmount;
    }

    /**
     * Set the fessAmount.
     * 
     * @param fessAmount
     *     the new fessAmount
     */
    public void setFessAmount(Double fessAmount) {
        this.feesAmount = fessAmount;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(principalAmount).append(interestAmount).append(insuranceAmount).append(escrowAmount).append(pmiAmount).append(feesAmount).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        PaymentDetails otherObject = ((PaymentDetails) other);
        return new EqualsBuilder().append(principalAmount, otherObject.principalAmount).append(interestAmount, otherObject.interestAmount).append(insuranceAmount, otherObject.insuranceAmount).append(escrowAmount, otherObject.escrowAmount).append(pmiAmount, otherObject.pmiAmount).append(feesAmount, otherObject.feesAmount).isEquals();
    }

	@Override
	public String toString() {
		return "PaymentDetails [PaymentId=" + PaymentId + ", LoanTransactionId=" + LoanTransactionId
				+ ", principalAmount=" + principalAmount + ", interestAmount=" + interestAmount + ", insuranceAmount="
				+ insuranceAmount + ", escrowAmount=" + escrowAmount + ", pmiAmount=" + pmiAmount + ", fessAmount="
				+ feesAmount + "]";
	}

   
}
