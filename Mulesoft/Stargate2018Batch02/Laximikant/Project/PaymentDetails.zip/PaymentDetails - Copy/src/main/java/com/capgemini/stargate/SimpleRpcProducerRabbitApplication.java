package com.capgemini.stargate;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.capgemini.stargate.model.LoanPaymentDetails;

import java.text.SimpleDateFormat;
import java.util.Date;

@EnableScheduling
@SpringBootApplication
public class SimpleRpcProducerRabbitApplication {

    private final RabbitTemplate template;


    @Autowired
    public SimpleRpcProducerRabbitApplication(RabbitTemplate template) {
        this.template = template;
    }

    public void sendMessage(LoanPaymentDetails loanPaymentDetails) {

        this.template.convertAndSend("spring-boot-test", loanPaymentDetails.toString());
    }

    @Bean
    public Queue queue() {
        return new Queue("spring-boot-test", false);
    }
}
