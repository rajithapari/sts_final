package com.capgemini.stargate.service;

import javax.security.auth.login.AccountNotFoundException;

import com.capgemini.stargate.model.LoanPaymentDetails;

public interface PaymentDetailService {

	public LoanPaymentDetails getPaymentDetails(String accountId) throws AccountNotFoundException;
	
}
