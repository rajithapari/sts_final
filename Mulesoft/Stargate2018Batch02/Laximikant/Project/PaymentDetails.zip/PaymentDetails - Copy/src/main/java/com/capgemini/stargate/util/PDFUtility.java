package com.capgemini.stargate.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

import com.capgemini.stargate.model.LoanPaymentDetails;
import com.capgemini.stargate.model.PaymentDetails;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;

public class PDFUtility {

	public static ByteArrayInputStream paymentDetailsReport(LoanPaymentDetails loanPaymentDetails){
		
		Document document = new Document();
		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		
		try{
			
			if(null != loanPaymentDetails){
				PdfPTable table = new PdfPTable(6);
				table.setWidthPercentage(60);
				Font headFond = FontFactory.getFont(FontFactory.COURIER_BOLDOBLIQUE);

				PdfPCell hcell;
				hcell = new PdfPCell(new Phrase("AccountId", headFond));
				hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(hcell);
				
				PdfPCell cell;
				
				cell = new PdfPCell(new Phrase(loanPaymentDetails.getLoanAccount().getAccountId().toString()));
				cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
				cell.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(cell);
				
				hcell = new PdfPCell(new Phrase("OriginalPrincipal", headFond));
				hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(hcell);
				
				
				hcell = new PdfPCell(new Phrase("LoanTerm", headFond));
				hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(hcell);
				
				hcell = new PdfPCell(new Phrase("TotalNumberOfPayments", headFond));
				hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(hcell);
				
				hcell = new PdfPCell(new Phrase("PaymentFrequency", headFond));
				hcell.setHorizontalAlignment(Element.ALIGN_CENTER);
				table.addCell(hcell);
				
				/*for(PaymentDetails paymentDetails : loanPaymentDetails.getLoanAccountPaymentDetails()){
					PdfPCell cell;
					
					cell = new PdfPCell(new Phrase(loanPaymentDetails.getLoanAccount().getAccountId().toString()));
					cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
					cell.setHorizontalAlignment(Element.ALIGN_CENTER);
					table.addCell(cell);
				}*/
				
			}
			
		}catch(Exception ex){
			
		}
		
		return null;
	}
	
	private static void addContent(Document document,LoanPaymentDetails loanPaymentDetails) throws DocumentException {
        
        // first parameter is the number of the chapter
        Chapter catPart = new Chapter(0);
        Paragraph subPara = new Paragraph("Customer Information");
        Section subCatPart = catPart.addSection(subPara);
       
        subCatPart.add(new Paragraph(""));
     
       
        // now add all this to the document
        document.add(subCatPart);

    }
	
}
