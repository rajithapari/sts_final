
package com.capgemini.stargate.model;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


public class LoanPaymentDetails implements Serializable
{

    final static long serialVersionUID = -345162480403010304L;
    
    
    private LoanAccount loanAccount;
    private List<PaymentDetails> paymentDetails ;

    /**
     * Creates a new LoanPaymentDetails.
     * 
     */
    public LoanPaymentDetails() {
        super();
    }

    /**
     * Creates a new LoanPaymentDetails.
     * 
     */
    public LoanPaymentDetails(LoanAccount loanAccount, List<PaymentDetails> loanAccountPaymentDetails) {
        super();
        this.loanAccount = loanAccount;
        this.paymentDetails = loanAccountPaymentDetails;
    }

    /**
     * Returns the loanAccount.
     * 
     * @return
     *     loanAccount
     */
    public Account getLoanAccount() {
        return loanAccount;
    }

    /**
     * Set the loanAccount.
     * 
     * @param loanAccount
     *     the new loanAccount
     */
    public void setLoanAccount(LoanAccount loanAccount) {
        this.loanAccount = loanAccount;
    }

    /**
     * Returns the loanAccount | paymentDetails[].
     * 
     * @return
     *     loanAccountPaymentDetails
     */
    public List<PaymentDetails> getLoanAccountPaymentDetails() {
        return paymentDetails;
    }

    /**
     * Set the loanAccount | paymentDetails[].
     * 
     * @param loanAccountPaymentDetails
     *     the new loanAccountPaymentDetails
     */
    public void setLoanAccountPaymentDetails(List<PaymentDetails> loanAccountPaymentDetails) {
        this.paymentDetails = loanAccountPaymentDetails;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(loanAccount).append(paymentDetails).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        LoanPaymentDetails otherObject = ((LoanPaymentDetails) other);
        return new EqualsBuilder().append(loanAccount, otherObject.loanAccount).append(paymentDetails, otherObject.paymentDetails).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("loanAccount", loanAccount).append("loanAccountPaymentDetails", paymentDetails).toString();
    }

}
