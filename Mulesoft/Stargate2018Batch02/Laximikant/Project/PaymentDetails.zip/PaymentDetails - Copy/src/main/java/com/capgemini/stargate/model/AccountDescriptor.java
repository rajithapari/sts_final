
package com.capgemini.stargate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="accountdescriptor")
@JsonIgnoreProperties("accountType")
public class AccountDescriptor implements Serializable
{

    final static long serialVersionUID = -398041964811738881L;
   
    @Column
    private int accountDescriptorId;
    
   

	@Id
	@Column(name="AccountId")
    private String accountId;
    /**
     * Account Type can be any value from enum
     * 
     */
	@Column
	@Enumerated(EnumType.STRING)
    private AccountType accountType;
    /**
     * Name to be displayed on account
     * 
     */
    private String displayName;
    /**
     * account description
     * 
     */
    private String description;
    
    @Column(name="Status")
    @Enumerated(EnumType.STRING)
    private AccountStatus accountStatus;

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    @JsonIgnore
    private String customerId;
    
    public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public AccountDescriptor() {
        super();
    }

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
   

    public AccountDescriptor(int accountDescriptorId, String accountId, AccountType accountType, String displayName,
			String description, AccountStatus accountStatus) {
		super();
		this.accountDescriptorId = accountDescriptorId;
		this.accountId = accountId;
		this.accountType = accountType;
		this.displayName = displayName;
		this.description = description;
		this.accountStatus = accountStatus;
	}

	/**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    
    public String getAccountId() {
        return accountId;
    }
    
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    /*public AccountType getAccountType() {
        return accountType;
    }

    *//**
     * Set the accountType.
     * 
     * @param accountType
     *     the new accountType
     *//*
    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }
*/
    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
    
    /*public int getAccountDescriptorId() {
		return accountDescriptorId;
	}

	public void setAccountDescriptorId(int accountDescriptorId) {
		this.accountDescriptorId = accountDescriptorId;
	}*/
    
   /* public String getDisplayName() {
        return displayName;
    }

    *//**
     * Set the displayName.
     * 
     * @param displayName
     *     the new displayName
     *//*
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }*/

    /**
     * Returns the description.
     * 
     * @return
     *     description
     */
    /*public String getDescription() {
        return description;
    }

    *//**
     * Set the description.
     * 
     * @param description
     *     the new description
     *//*
    public void setDescription(String description) {
        this.description = description;
    }*/

    /**
     * Returns the accountStatus.
     * 
     * @return
     *     accountStatus
     */
    /*public AccountStatus getAccountStatus() {
        return accountStatus;
    }

    *//**
     * Set the accountStatus.
     * 
     * @param accountStatus
     *     the new accountStatus
     *//*
    public void setAccountStatus(AccountStatus accountStatus) {
        this.accountStatus = accountStatus;
    }*/

    public int hashCode() {
        return new HashCodeBuilder().append(accountId).append(accountType).append(displayName).append(description).append(accountStatus).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        AccountDescriptor otherObject = ((AccountDescriptor) other);
        return new EqualsBuilder().append(accountId, otherObject.accountId).append(accountType, otherObject.accountType).append(displayName, otherObject.displayName).append(description, otherObject.description).append(accountStatus, otherObject.accountStatus).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accountId", accountId).append("accountType", accountType).append("displayName", displayName).append("description", description).append("accountStatus", accountStatus).toString();
    }

}
