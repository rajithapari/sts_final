
package com.capgemini.stargate.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="loanaccount")
@JsonIgnoreProperties("originalPrincipal")
public class LoanAccount
    extends Account
    implements Serializable
{

    final static long serialVersionUID = -7148535860589430658L;
    /**
     * balance on todays date
     * 
     */
   
    @Column(name="LoanAccountId")
    private int loanAccountId;
    
    /*public int getLoanAccountId() {
		return loanAccountId;
	}

	public void setLoanAccountId(int loanAccountId) {
		this.loanAccountId = loanAccountId;
	}*/


    
	@Column(name="BalanceAsOf")
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private Date balanceAsOf;
    /**
     * Amount of loan remaining unpaid, not including interest and other                         charges
     * 
     */
    @Column(name="PrincipalBalance")
    private Double principalBalance;
    /**
     * the total amount of money borrowed
     * 
     */
    @Column(name="OriginalPrincipal")
    private Double originalPrincipal;
    /**
     * Period over which a loan agreement is in force, and before or at the                      end of which the loan should either be repaid or renegotiated for                         another term
     * 
     */
    @Column(name="LoanTerm")
    private Long loanTerm;
    /**
     * total no of payments required to complete the loan amount
     * 
     */
    @Column(name="TotalNumberOfPayments")
    private Long totalNumberOfPayments;
    /**
     * payment time per EMI
     * 
     */
    @Column(name="PaymentFrequency")
    @Enumerated(EnumType.STRING)
    private PaymentFrequency paymentFrequency;

    /**
     * Creates a new LoanAccount.
     * 
     */
    public LoanAccount() {
        super();
    }

    /**
     * Creates a new LoanAccount.
     * 
     */
   

    /**
     * Returns the balanceAsOf.
     * 
     * @return
     *     balanceAsOf
     */
    

    public LoanAccount(int loanAccountId, int accountId, Date balanceAsOf, Double principalBalance,
			Double origionalPrinciple, Long loanTerm, Long totalNumberOfPayments, PaymentFrequency paymentFrequency) {
		super();
		this.loanAccountId = loanAccountId;
		//this.accountId = accountId;
		this.balanceAsOf = balanceAsOf;
		this.principalBalance = principalBalance;
		this.originalPrincipal = origionalPrinciple;
		this.loanTerm = loanTerm;
		this.totalNumberOfPayments = totalNumberOfPayments;
		this.paymentFrequency = paymentFrequency;
	}

   
    
	/**
     * Set the balanceAsOf.
     * 
     * @param balanceAsOf
     *     the new balanceAsOf
     */
    /*
     * public Date getBalanceAsOf() {
        return balanceAsOf;
    }
     * public void setBalanceAsOf(Date balanceAsOf) {
        this.balanceAsOf = balanceAsOf;
    }

    *//**
     * Returns the principalBalance.
     * 
     * @return
     *     principalBalance
     *//*
    public Double getPrincipalBalance() {
        return principalBalance;
    }*/

    /**
     * Set the principalBalance.
     * 
     * @param principalBalance
     *     the new principalBalance
     */
    public void setPrincipalBalance(Double principalBalance) {
        this.principalBalance = principalBalance;
    }

    /**
     * Returns the origionalPrinciple.
     * 
     * @return
     *     origionalPrinciple
     */
   /* public Double getOrigionalPrinciple() {
        return originalPrincipal;
    }

    *//**
     * Set the origionalPrinciple.
     * 
     * @param origionalPrinciple
     *     the new origionalPrinciple
     *//*
    public void setOrigionalPrinciple(Double origionalPrinciple) {
        this.originalPrincipal = origionalPrinciple;
    }*/

    /**
     * Returns the loanTerm.
     * 
     * @return
     *     loanTerm
     */
    public Long getLoanTerm() {
        return loanTerm;
    }

    /**
     * Set the loanTerm.
     * 
     * @param loanTerm
     *     the new loanTerm
     */
    public void setLoanTerm(Long loanTerm) {
        this.loanTerm = loanTerm;
    }

    /**
     * Returns the totalNumberOfPayments.
     * 
     * @return
     *     totalNumberOfPayments
     */
    public Long getTotalNumberOfPayments() {
        return totalNumberOfPayments;
    }

    /**
     * Set the totalNumberOfPayments.
     * 
     * @param totalNumberOfPayments
     *     the new totalNumberOfPayments
     */
    public void setTotalNumberOfPayments(Long totalNumberOfPayments) {
        this.totalNumberOfPayments = totalNumberOfPayments;
    }

    /**
     * Returns the paymentFrequency.
     * 
     * @return
     *     paymentFrequency
     */
    public PaymentFrequency getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Set the paymentFrequency.
     * 
     * @param paymentFrequency
     *     the new paymentFrequency
     */
    public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

   

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		//result = prime * result + accountId;
		result = prime * result + ((balanceAsOf == null) ? 0 : balanceAsOf.hashCode());
		result = prime * result + loanAccountId;
		result = prime * result + ((loanTerm == null) ? 0 : loanTerm.hashCode());
		result = prime * result + ((originalPrincipal == null) ? 0 : originalPrincipal.hashCode());
		result = prime * result + ((paymentFrequency == null) ? 0 : paymentFrequency.hashCode());
		result = prime * result + ((principalBalance == null) ? 0 : principalBalance.hashCode());
		result = prime * result + ((totalNumberOfPayments == null) ? 0 : totalNumberOfPayments.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoanAccount other = (LoanAccount) obj;
		/*if (accountId != other.accountId)
			return false;*/
		if (balanceAsOf == null) {
			if (other.balanceAsOf != null)
				return false;
		} else if (!balanceAsOf.equals(other.balanceAsOf))
			return false;
		if (loanAccountId != other.loanAccountId)
			return false;
		if (loanTerm == null) {
			if (other.loanTerm != null)
				return false;
		} else if (!loanTerm.equals(other.loanTerm))
			return false;
		if (originalPrincipal == null) {
			if (other.originalPrincipal != null)
				return false;
		} else if (!originalPrincipal.equals(other.originalPrincipal))
			return false;
		if (paymentFrequency != other.paymentFrequency)
			return false;
		if (principalBalance == null) {
			if (other.principalBalance != null)
				return false;
		} else if (!principalBalance.equals(other.principalBalance))
			return false;
		if (totalNumberOfPayments == null) {
			if (other.totalNumberOfPayments != null)
				return false;
		} else if (!totalNumberOfPayments.equals(other.totalNumberOfPayments))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LoanAccount [loanAccountId=" + loanAccountId + ", accountId="  + ", balanceAsOf="
				+ balanceAsOf + ", principalBalance=" + principalBalance + ", origionalPrinciple=" + originalPrincipal
				+ ", loanTerm=" + loanTerm + ", totalNumberOfPayments=" + totalNumberOfPayments + ", paymentFrequency="
				+ paymentFrequency + "]";
	}

    

}
