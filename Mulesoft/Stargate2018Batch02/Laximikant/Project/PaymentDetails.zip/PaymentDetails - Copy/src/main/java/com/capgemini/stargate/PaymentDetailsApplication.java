package com.capgemini.stargate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class PaymentDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentDetailsApplication.class, args);
	}
}
