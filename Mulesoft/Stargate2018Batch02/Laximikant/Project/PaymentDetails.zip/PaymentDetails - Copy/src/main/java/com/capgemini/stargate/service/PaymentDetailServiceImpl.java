package com.capgemini.stargate.service;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.stargate.SimpleRpcProducerRabbitApplication;
import com.capgemini.stargate.dao.LoanAccountDetailsRepository;
import com.capgemini.stargate.dao.PaymentDetailsRepository;
import com.capgemini.stargate.exception.InternalServerException;
import com.capgemini.stargate.model.LoanAccount;
import com.capgemini.stargate.model.LoanPaymentDetails;
import com.capgemini.stargate.model.PaymentDetails;
import com.capgemini.stargate.soaptorest.BankCatalogClient;

@Service
public class PaymentDetailServiceImpl implements PaymentDetailService {

	@Autowired
	PaymentDetailsRepository paymentDetailsRepository;

	@Autowired
	LoanAccountDetailsRepository loanAccountDetailsRepository;

	@Autowired
	SimpleRpcProducerRabbitApplication simpleRpcProducerRabbitApplication;

	@Autowired
	BankCatalogClient bankCatalogClient;
	
	@SuppressWarnings("unchecked")
	@Override
	public LoanPaymentDetails getPaymentDetails(String accountId) throws AccountNotFoundException {
		try {

			List<LoanAccount> loanAccountDetails = loanAccountDetailsRepository.getLoanAccountDetails(accountId);
			if ( 0 != loanAccountDetails.size() ) {

				List<PaymentDetails> paymentdetails = paymentDetailsRepository.getPaymentDetails(accountId);

				LoanPaymentDetails loanPaymentDetails = new LoanPaymentDetails();
				loanPaymentDetails.setLoanAccountPaymentDetails(paymentdetails);
				if (null != loanAccountDetails) {
					loanPaymentDetails.setLoanAccount(loanAccountDetails.get(0));
				}

				simpleRpcProducerRabbitApplication.sendMessage(loanPaymentDetails);
				bankCatalogClient.getBankById(loanAccountDetails.get(0).getCustomerId());
				return loanPaymentDetails;
			} else {
					throw new AccountNotFoundException("Account not found");
			}
		}catch(AccountNotFoundException ex){
			throw new AccountNotFoundException("Account not found");
		}catch (Exception ex) {
			throw new InternalServerException("Internal Server Error");
		}

	}
	
	public boolean isValidAccount(String accountId){
		
		if(accountId.startsWith("ICICI")){
			return true;
		}
		return false;
	}

	

}
