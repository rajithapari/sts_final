
package com.capgemini.stargate;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.stargate.dao.LoanAccountDetailsRepository;
import com.capgemini.stargate.exception.BadRequestException;
import com.capgemini.stargate.exception.CustomExceptionHandlerController;
import com.capgemini.stargate.model.LoanAccount;
import com.capgemini.stargate.model.LoanPaymentDetails;
import com.capgemini.stargate.service.PaymentDetailService;
import com.capgemini.stargate.soaptorest.BankCatalogClient;
import com.capgemini.stargate.validation.Validator;

/**
 * No description (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
@RequestMapping(value = "/api/v1/dda", produces = "application/json")
/* @EnableOAuth2Sso */
public class PaymentdetailController {

	@Autowired
	PaymentDetailService paymentDetailService;

	@Autowired
	Validator validator;
	
	@Autowired
	LoanAccountDetailsRepository loanAccountDetailsRepository;
	
	@GetMapping(value = "/loans/payments/{accountId}")
	public ResponseEntity<?> getLoanPaymentDetails(@PathVariable("accountId") String accountId) throws AccountNotFoundException {
		try {
			
			if (validator.validateAccountId(accountId)) {
				
				return new ResponseEntity<LoanPaymentDetails>(paymentDetailService.getPaymentDetails(accountId),
						HttpStatus.OK);
			} else {
				throw new BadRequestException("throwing bad request");

			}
		} catch (BadRequestException ex) {
			return new CustomExceptionHandlerController().handleBadRequest(ex);
		} catch (AccountNotFoundException ex) {
			return new CustomExceptionHandlerController().handleAccountNotFound(ex);
		} catch (Exception ex) {
			return new CustomExceptionHandlerController().handleAllExceptions(ex);
		}
		
	}

	/*
	 * @Override protected void configure(HttpSecurity http) throws Exception {
	 * http .antMatcher("/**") .authorizeRequests() .antMatchers("/", "/api**",
	 * "/error**") .permitAll() .anyRequest() .authenticated(); }
	 */
}
