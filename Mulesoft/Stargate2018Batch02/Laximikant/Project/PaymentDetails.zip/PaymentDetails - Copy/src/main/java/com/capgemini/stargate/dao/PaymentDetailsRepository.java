package com.capgemini.stargate.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.stargate.model.PaymentDetails;

@Repository
public interface PaymentDetailsRepository extends CrudRepository<PaymentDetails, String>{

	@Query(value=" select t.AccountId, lt.LoanTransactionId, pd.paymentId, pd.PrincipalAmount, pd.InterestAmount, pd.InsuranceAmount, pd.EscrowAmount, pd.PmiAmount, pd.FeesAmount "
	      +" from transaction t inner join loantransaction lt "
	      +" on t.TransactionId = lt.TransactionId "
	      +" inner join paymentdetails pd "
	      +" on pd.LoanTransactionId = lt.LoanTransactionId "
	      +" where t.AccountId=:accountId ",nativeQuery=true)
	public List<PaymentDetails> getPaymentDetails(@Param("accountId") String accountId);
	
	
	
}
