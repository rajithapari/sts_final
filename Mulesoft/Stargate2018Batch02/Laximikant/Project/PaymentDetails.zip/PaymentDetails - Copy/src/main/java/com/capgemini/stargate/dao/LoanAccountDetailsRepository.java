package com.capgemini.stargate.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capgemini.stargate.model.LoanAccount;

@Repository
public interface LoanAccountDetailsRepository extends CrudRepository<LoanAccount, String>{

	@Query(value=" select ad.AccountId, la.OriginalPrincipal, la.LoanTerm, la.TotalNumberOfPayments, la.PaymentFrequency, ad.accountDescriptorId  "
			+" , ad.Status, accountType, ad.description, ad.displayName, acc.accountNumber, la.balanceAsOf, acc.interestRate, acc.nickname"
			+" , acc.parentAccountId, la.principalBalance, la.LoanAccountId, ad.CustomerId "
			+" from accountdescriptor ad inner join account acc "
			+" on ad.AccountDescriptorId = acc.AccDescriptorId "
			+" inner join loanaccount la "
			+" on acc.AccountMasterId = la.AccountId "
			+" where ad.AccountId=:accountId ",nativeQuery=true)
	public List<LoanAccount> getLoanAccountDetails(@Param("accountId") String accountId); 
	
	
}
