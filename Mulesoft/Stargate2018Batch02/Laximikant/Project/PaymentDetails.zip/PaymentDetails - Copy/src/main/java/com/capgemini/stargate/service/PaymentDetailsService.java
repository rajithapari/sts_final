package com.capgemini.stargate.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.stargate.SimpleRpcProducerRabbitApplication;
import com.capgemini.stargate.model.AccountDescriptor;
import com.capgemini.stargate.model.LoanAccount;
import com.capgemini.stargate.model.LoanPaymentDetails;
import com.capgemini.stargate.model.PaymentDetails;

@Service
public class PaymentDetailsService  {
	
	@PersistenceContext
	EntityManager entityManager;
	
	@Autowired
	SimpleRpcProducerRabbitApplication rpcProducerRabbitApplication;
	
	public LoanPaymentDetails getPaymentDetails(String accountId) {
		
	System.out.println("in PaymentDetailsService service");
	
	try{
		
	StringBuffer stringBuffer = new StringBuffer();
	//stringBuffer.append(" select pd.PrincipalAmount, pd.InterestAmount, pd.InsuranceAmount, pd.EscrowAmount, pd.PmiAmount, pd.FeesAmount ");
	stringBuffer.append(" select * ");
	stringBuffer.append(" from transaction t inner join loantransaction lt ");
	stringBuffer.append(" on t.TransactionId = lt.TransactionId ");
	stringBuffer.append(" inner join paymentdetails pd ");
	stringBuffer.append(" on pd.LoanTransactionId = lt.LoanTransactionId ");
	stringBuffer.append(" where t.AccountId=? ");
	System.out.println("Query ----> "+stringBuffer.toString());
	
	Query query1 = entityManager.createNativeQuery(stringBuffer.toString(),PaymentDetails.class);
	query1.setParameter(1, accountId);
	List<PaymentDetails> paymentdetails = query1.getResultList();
	System.out.println(paymentdetails.get(0));
	
	
	StringBuffer stringBuffer2 = new StringBuffer();
	stringBuffer2.append(" select * ");
	stringBuffer2.append(" from accountdescriptor ad inner join account acc ");
	stringBuffer2.append(" on ad.AccountDescriptorId = acc.AccDescriptorId ");
	stringBuffer2.append(" inner join loanaccount la ");
	stringBuffer2.append(" on acc.AccountMasterId = la.AccountId ");
	stringBuffer2.append(" where ad.AccountId=? ");
	
	Query query2 = entityManager.createNativeQuery(stringBuffer2.toString(), LoanAccount.class);
	query2.setParameter(1, accountId);
	
	List<LoanAccount> loanAccountDetails = query2.getResultList();
	
	System.out.println(loanAccountDetails.get(0));
	
	
	LoanPaymentDetails loanPaymentDetails = new LoanPaymentDetails();
	loanPaymentDetails.setLoanAccountPaymentDetails(paymentdetails);
	loanPaymentDetails.setLoanAccount(loanAccountDetails.get(0));
	
	rpcProducerRabbitApplication.sendMessage(loanPaymentDetails);
	
	
	return loanPaymentDetails;
	
	}catch(Exception ex){
		ex.printStackTrace();
	}
	return null;
		
	
	}
	
	
}
