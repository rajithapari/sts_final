
package com.capgemini.stargate.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="account")
public class Account
    extends AccountDescriptor
    implements Serializable
{

    final static long serialVersionUID = -393084515161686497L;
    /**
     * an unique parent account id
     * 
     */
    
    private String parentAccountId;
    /**
     * nick name of account
     * 
     */
    private String nickname;
    
    private String accountNumber;
    /**
     * interest rate applicable to this account
     * 
     */
    private Double interestRate;
    /**
     * balance on todays date
     * 
     */
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private Date balanceAsOf;
    /**
     * Amount of loan remaining unpaid, not including interest and other                         charges
     * 
     */
    private Double principalBalance;
    /**
     * the total amount of money borrowed
     * 
     */
    @Column(name="OriginalPrincipal")
    private Double originalPrincipal;
    /**
     * Period over which a loan agreement is in force, and before or at the                      end of which the loan should either be repaid or renegotiated for                         another term
     * 
     */
    private Long loanTerm;
    /**
     * total no of payments required to complete the loan amount
     * 
     */
    private Long totalNumberOfPayments;
    /**
     * payment time per EMI
     * 
     */
    @Enumerated(EnumType.STRING)
    private PaymentFrequency paymentFrequency;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
    public Account(int accountDescriptorId, String accountId, AccountType accountType, String displayName, String description, AccountStatus accountStatus, String parentAccountId, String nickname, String accountNumber, Double interestRate, Date balanceAsOf, Double principalBalance, Double origionalPrinciple, Long loanTerm, Long totalNumberOfPayments, PaymentFrequency paymentFrequency) {
        super(accountDescriptorId, accountId, accountType, displayName, description, accountStatus);
        this.parentAccountId = parentAccountId;
        this.nickname = nickname;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.balanceAsOf = balanceAsOf;
        this.principalBalance = principalBalance;
        this.originalPrincipal = origionalPrinciple;
        this.loanTerm = loanTerm;
        this.totalNumberOfPayments = totalNumberOfPayments;
        this.paymentFrequency = paymentFrequency;
    }

    /**
     * Returns the parentAccountId.
     * 
     * @return
     *     parentAccountId
     */
    /*public String getParentAccountId() {
        return parentAccountId;
    }

    *//**
     * Set the parentAccountId.
     * 
     * @param parentAccountId
     *     the new parentAccountId
     *//*
    public void setParentAccountId(String parentAccountId) {
        this.parentAccountId = parentAccountId;
    }*/

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
   /* public String getNickname() {
        return nickname;
    }

    *//**
     * Set the nickname.
     * 
     * @param nickname
     *     the new nickname
     *//*
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }*/

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    /*public String getAccountNumber() {
        return accountNumber;
    }

    *//**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     *//*
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }*/

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    /*public Double getInterestRate() {
        return interestRate;
    }

    *//**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     *//*
    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }*/

    /**
     * Returns the balanceAsOf.
     * 
     * @return
     *     balanceAsOf
     */
    /*public Date getBalanceAsOf() {
        return balanceAsOf;
    }

    *//**
     * Set the balanceAsOf.
     * 
     * @param balanceAsOf
     *     the new balanceAsOf
     *//*
    public void setBalanceAsOf(Date balanceAsOf) {
        this.balanceAsOf = balanceAsOf;
    }*/

    /**
     * Returns the principalBalance.
     * 
     * @return
     *     principalBalance
     */
    /*public Double getPrincipalBalance() {
        return principalBalance;
    }

    *//**
     * Set the principalBalance.
     * 
     * @param principalBalance
     *     the new principalBalance
     *//*
    public void setPrincipalBalance(Double principalBalance) {
        this.principalBalance = principalBalance;
    }
*/
    /**
     * Returns the origionalPrinciple.
     * 
     * @return
     *     origionalPrinciple
     */
   /* public Double getOrigionalPrinciple() {
        return originalPrincipal;
    }

    *//**
     * Set the origionalPrinciple.
     * 
     * @param origionalPrinciple
     *     the new origionalPrinciple
     *//*
    public void setOrigionalPrinciple(Double origionalPrinciple) {
        this.originalPrincipal = origionalPrinciple;
    }*/

    /**
     * Returns the loanTerm.
     * 
     * @return
     *     loanTerm
     */
    public Long getLoanTerm() {
        return loanTerm;
    }

    /**
     * Set the loanTerm.
     * 
     * @param loanTerm
     *     the new loanTerm
     */
    public void setLoanTerm(Long loanTerm) {
        this.loanTerm = loanTerm;
    }

    /**
     * Returns the totalNumberOfPayments.
     * 
     * @return
     *     totalNumberOfPayments
     */
    public Long getTotalNumberOfPayments() {
        return totalNumberOfPayments;
    }

    /**
     * Set the totalNumberOfPayments.
     * 
     * @param totalNumberOfPayments
     *     the new totalNumberOfPayments
     */
    public void setTotalNumberOfPayments(Long totalNumberOfPayments) {
        this.totalNumberOfPayments = totalNumberOfPayments;
    }

    /**
     * Returns the paymentFrequency.
     * 
     * @return
     *     paymentFrequency
     */
    public PaymentFrequency getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Set the paymentFrequency.
     * 
     * @param paymentFrequency
     *     the new paymentFrequency
     */
    public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(parentAccountId).append(nickname).append(accountNumber).append(interestRate).append(balanceAsOf).append(principalBalance).append(originalPrincipal).append(loanTerm).append(totalNumberOfPayments).append(paymentFrequency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(parentAccountId, otherObject.parentAccountId).append(nickname, otherObject.nickname).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).append(balanceAsOf, otherObject.balanceAsOf).append(principalBalance, otherObject.principalBalance).append(originalPrincipal, otherObject.originalPrincipal).append(loanTerm, otherObject.loanTerm).append(totalNumberOfPayments, otherObject.totalNumberOfPayments).append(paymentFrequency, otherObject.paymentFrequency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("parentAccountId", parentAccountId).append("nickname", nickname).append("accountNumber", accountNumber).append("interestRate", interestRate).append("balanceAsOf", balanceAsOf).append("principalBalance", principalBalance).append("origionalPrinciple", originalPrincipal).append("loanTerm", loanTerm).append("totalNumberOfPayments", totalNumberOfPayments).append("paymentFrequency", paymentFrequency).toString();
    }

}
