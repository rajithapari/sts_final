package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.capgemini.stargate.controller.model.ExceptionResponse;

public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(value = BadRequestException.class)     
    public final ResponseEntity<ExceptionResponse> handleBadRequest(BadRequestException ex) {
	ExceptionResponse exceptionResponse = new ExceptionResponse("Invalid CustomerId", "400");
    return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
}

	@ExceptionHandler(value = CustomerNotFoundException.class)     
    public final ResponseEntity<ExceptionResponse> handleBadRequest(CustomerNotFoundException ex) {
	ExceptionResponse exceptionResponse = new ExceptionResponse("Invalid CustomerId", "404");
    return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
}
	
	@ExceptionHandler(value = MethodNotAllowedException.class)     
    public final ResponseEntity<ExceptionResponse> handleBadRequest(MethodNotAllowedException ex) {
	ExceptionResponse exceptionResponse = new ExceptionResponse("Invalid CustomerId", "404");
    return new ResponseEntity<>(exceptionResponse, HttpStatus.METHOD_NOT_ALLOWED);
}
}
