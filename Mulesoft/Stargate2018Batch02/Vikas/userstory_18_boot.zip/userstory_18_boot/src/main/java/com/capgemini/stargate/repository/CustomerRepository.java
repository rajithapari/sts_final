package com.capgemini.stargate.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.stargate.controller.model.Customer;
@Transactional
@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {
	
	 
	@Query(value=" select c.CustomerId,c.DateOfBirth, cn.First, cn.Middle, cn.Last, cn.Company, "
				 +" da.Type, da.Line1, da.Line2, da.City, da.Zip, da.Country  " 
				 +" from Customer c inner join CustomerName cn "
				 +" on c.CustomerId = cn.CustomerId "
				 +" inner join DeliveryAddress da "
				 +" on c.CustomerId = da.CustomerId and da.type='HOME' "
				 +" where c.customerId=:customerId",nativeQuery = true )	
	Customer findByCustomerId(@Param(value="customerId") String customerId );
	
	

	/* @Query(value=" select c.CustomerId,c.DateOfBirth, cn.First, cn.Middle, cn.Last, cn.Company "
	+" from Customer c inner join Customername cn " 
	 +" on c.CustomerId = cn.CustomerId " 
 +" where c.customerId=:customerId",nativeQuery = true)
	
	@Query(value="select * from customer c where c.customerId=:customerId ",nativeQuery = true)
	 Customer findByCustomerId(@Param(value="customerId") String customerId );
	 
 */
}
