package com.capgemini.stargate.service;



import org.springframework.stereotype.Component;

import com.capgemini.stargate.controller.model.Customer;



@Component
public interface CustomerService {
	
	public Customer getAllCustomer(String customerId);
	
	
}