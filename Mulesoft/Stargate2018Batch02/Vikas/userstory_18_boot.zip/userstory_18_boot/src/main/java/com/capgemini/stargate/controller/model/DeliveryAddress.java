
package com.capgemini.stargate.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.stereotype.Component;

@Entity

public class DeliveryAddress implements Serializable
{

    final static long serialVersionUID = -5948947996771479247L;
    /**
     * HOME, BUSINESS, MAILING
     * 
     */
    @Id
    private int deliveryAddressId;
    
  
    @Enumerated(EnumType.STRING)
    private Type type;
    /**
     * The delivery location�s first line
     * 
     */
  
    private String line1;
    /**
     * The delivery location�s second lines
     * 
     */
    
 
    private String line2;
    /**
     * The delivery location�s city
     * 
     */
  
    private String city;
    /**
     * The delivery location�s state
     * 
     */
    
 
    @Enumerated(EnumType.STRING)
    private Iso3166CountryCode state;
    /**
     * The delivery location�s zip code
     * 
     */

    private String zip;
    /**
     * ISO 3166 two digit country code
     * 
     */
    
    private String  country;
    
    
   //@OneToMany(fetch = FetchType.LAZY)
   // @JoinColumn(name="customerId")
    private Customer customer;

    /**
     * Creates a new DeliveryAddress.
     * 
     */
    public DeliveryAddress() {
    	super();
    }

    /**
     * Creates a new DeliveryAddress.
     * 
     */
        
    public DeliveryAddress(int deliveryAddressId, Type type, String line1, String line2, String city, Iso3166CountryCode state, String zip,
			String country, Customer customer) {
		super();
		
		this.deliveryAddressId = deliveryAddressId;
		this.type = type;
		this.line1 = line1;
		this.line2 = line2;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.country = country;
		this.customer = customer;
	}

	/**
     * Returns the type.
     * 
     * @return
     *     type
     */
    
    
    
    public Type getType() {
        return type;
    }

    public int getDeliveryAddressId() {
		return deliveryAddressId;
	}

	public void setDeliveryAddressId(int deliveryAddressId) {
		this.deliveryAddressId = deliveryAddressId;
	}

	/**
     * Set the type.
     * 
     * @param type
     *     the new type
     */
    public void setType(Type type) {
        this.type = type;
    }

    /**
     * Returns the line1.
     * 
     * @return
     *     line1
     */
    public String getLine1() {
        return line1;
    }

    /**
     * Set the line1.
     * 
     * @param line1
     *     the new line1
     */
    public void setLine1(String line1) {
        this.line1 = line1;
    }

    /**
     * Returns the line2.
     * 
     * @return
     *     line2
     */
    public String getLine2() {
        return line2;
    }

    /**
     * Set the line2.
     * 
     * @param line2
     *     the new line2
     */
    public void setLine2(String line2) {
        this.line2 = line2;
    }

    /**
     * Returns the city.
     * 
     * @return
     *     city
     */
    public String getCity() {
        return city;
    }

    /**
     * Set the city.
     * 
     * @param city
     *     the new city
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * Returns the state.
     * 
     * @return
     *     state
     */
    public Iso3166CountryCode getState() {
        return state;
    }

    /**
     * Set the state.
     * 
     * @param state
     *     the new state
     */
    public void setState(Iso3166CountryCode state) {
        this.state = state;
    }

    /**
     * Returns the zip.
     * 
     * @return
     *     zip
     */
    public String getZip() {
        return zip;
    }

    /**
     * Set the zip.
     * 
     * @param zip
     *     the new zip
     */
    public void setZip(String zip) {
        this.zip = zip;
    }

    /**
     * Returns the country.
     * 
     * @return
     *     country
     */
    public String getCountry() {
        return country;
    }

    /**
     * Set the country.
     * 
     * @param country
     *     the new country
     */
    public void setCountry(String country) {
        this.country = country;
    }
    
   public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int hashCode() {
        return new HashCodeBuilder().append(deliveryAddressId).append(type).append(line1).append(line2).append(city).append(state).append(zip).append(country).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        DeliveryAddress otherObject = ((DeliveryAddress) other);
        return new EqualsBuilder().append(deliveryAddressId, otherObject.deliveryAddressId).append(type, otherObject.type).append(line1, otherObject.line1).append(line2, otherObject.line2).append(city, otherObject.city).append(state, otherObject.state).append(zip, otherObject.zip).append(country, otherObject.country).isEquals();
    }
	
    public String toString() {
        return new ToStringBuilder(this).append("deliveryAddressId", deliveryAddressId).append("type", type).append("line1", line1).append("line2", line2).append("city", city).append("state", state).append("zip", zip).append("country", country).toString();
    }

}
