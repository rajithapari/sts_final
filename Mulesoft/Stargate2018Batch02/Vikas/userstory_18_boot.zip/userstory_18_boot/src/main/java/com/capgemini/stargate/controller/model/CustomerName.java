
package com.capgemini.stargate.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


@Entity
public class CustomerName implements Serializable
{

    final static long serialVersionUID = -5874586217660955117L;
    
    @Id
    private int customerNameId;

    /**
     * First name
     * 
     */

    private String first;
    /**
     * Middle name
     * 
     */
    private String middle;
    /**
     * Last name
     * 
     */

    private String last;
    /**
     * Company name
     * 
     */

    private String company;
    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="customerId")
    private Customer customer;
    
    
    public CustomerName() {
        super();
    }

    /**
     * Creates a new CustomerName.
     * 
     */
  
  public CustomerName(int customerNameId, String first, String middle, String last, String company, Customer customer) {
		super();
		this.customerNameId = customerNameId;
		this.first = first;
		this.middle = middle;
		this.last = last;
		this.company = company;
	}

	/**
     * Returns the first.
     * 
     * @return
     *     first
     */
    public String getFirst() {
        return first;
    }

    /**
     * Set the first.
     * 
     * @param first
     *     the new first
     */
    public void setFirst(String first) {
        this.first = first;
    }

    /**
     * Returns the middle.
     * 
     * @return
     *     middle
     */
    public String getMiddle() {
        return middle;
    }

    /**
     * Set the middle.
     * 
     * @param middle
     *     the new middle
     */
    public void setMiddle(String middle) {
        this.middle = middle;
    }

    /**
     * Returns the last.
     * 
     * @return
     *     last
     */
    public String getLast() {
        return last;
    }

    /**
     * Set the last.
     * 
     * @param last
     *     the new last
     */
    public void setLast(String last) {
        this.last = last;
    }

    /**
     * Returns the company.
     * 
     * @return
     *     company
     */
    public String getCompany() {
        return company;
    }

    /**
     * Set the company.
     * 
     * @param company
     *     the new company
     */
    public void setCompany(String company) {
        this.company = company;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(customerNameId).append(first).append(middle).append(last).append(company).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        CustomerName otherObject = ((CustomerName) other);
        return new EqualsBuilder().append(customerNameId, otherObject.customerNameId).append(first, otherObject.first).append(middle, otherObject.middle).append(last, otherObject.last).append(company, otherObject.company).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("customerNameId", customerNameId).append("first", first).append("middle", middle).append("last", last).append("company", company).toString();
    }

}
