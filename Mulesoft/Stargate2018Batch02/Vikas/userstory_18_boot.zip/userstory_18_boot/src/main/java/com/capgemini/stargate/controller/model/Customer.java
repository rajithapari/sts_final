  
package com.capgemini.stargate.controller.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name="customer")
@Component
public class Customer implements Serializable
{

    final static long serialVersionUID = -6253005037490377686L;
    /**
     * Long-term persistent identity of the customer. this identity must be unique to the owning institution
     * 
     */
    @Id
    @Column(name="CustomerId")
    private String customerId;
    
    @OneToOne(cascade = CascadeType.ALL,mappedBy="customer")
    private CustomerName name1;
    /**
     * The customer�s date of birth
     * 
     */
    @Column(name="DateOfBirth")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date dateOfBirth;
  /*  @OneToMany
    private List<DeliveryAddress> address = new ArrayList<DeliveryAddress>();
*/
    /**
     * Creates a new Customer.
     * 
     */
    public Customer() {
        super();
    }

    /**
     * Creates a new Customer.
     * 
     */
    public Customer(String customerId, CustomerName name, Date dateOfBirth, List<DeliveryAddress> address) {
        super();
        this.customerId = customerId;
        this.name1 = name;
        this.dateOfBirth = dateOfBirth;
        //this.address = address;
    }


	

    public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
     * Returns the name.
     * 
     * @return
     *     name
     */
    public CustomerName getName() {
        return name1;
    }

    /**
     * Set the name.
     * 
     * @param name
     *     the new name
     */
    public void setName(CustomerName name) {
        this.name1 = name;
    }

    /**
     * Returns the dateOfBirth.
     * 
     * @return
     *     dateOfBirth
     */
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Set the dateOfBirth.
     * 
     * @param dateOfBirth
     *     the new dateOfBirth
     */
    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Returns the address.
     * 
     * @return
     *     address
     */
    /*public List<DeliveryAddress> getAddress() {
        return address;
    }

    *//**
     * Set the address.
     * 
     * @param address
     *     the new address
     *//*
    public void setAddress(List<DeliveryAddress> address) {
        this.address = address;
    }*/

    public int hashCode() {
        return new HashCodeBuilder().append(customerId).append(name1).append(dateOfBirth)/*.append(address)*/.toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Customer otherObject = ((Customer) other);
        return new EqualsBuilder().append(customerId, otherObject.customerId).append(name1, otherObject.name1).append(dateOfBirth, otherObject.dateOfBirth)/*.append(address, otherObject.address)*/.isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("customerId", customerId).append("name", name1).append("dateOfBirth", dateOfBirth)/*.append("address", address)*/.toString();
    }

}
