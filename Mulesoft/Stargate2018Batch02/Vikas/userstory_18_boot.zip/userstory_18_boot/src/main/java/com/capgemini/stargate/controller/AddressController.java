
package com.capgemini.stargate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.stargate.controller.model.Customer;
import com.capgemini.stargate.service.CustomerService;


/**
 * No description
 * (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
//@RequestMapping(value = "/api/v1/dda", produces = "apllication/json")
public class AddressController {


    /**
     * No description
     * 
     */
	@Autowired
	CustomerService customerService;
	
	
   @RequestMapping(value = "/customers/address", method = RequestMethod.POST)
   public  Customer customerAddress(@RequestBody Customer customer ) {
    	System.out.println("Inside controller");
    	String customerId = customer.getCustomerId();
    	
    			return customerService.getAllCustomer(customerId);
    }
    
}
