package com.capgemini.stargate.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.stargate.controller.model.Customer;
import com.capgemini.stargate.repository.CustomerRepository;
import com.capgemini.stargate.service.CustomerService;

@Service

public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerRepository customerRepository;
	
    @Override
    @Transactional
	public Customer getAllCustomer(String customerId) {	
    	Customer c=customerRepository.findByCustomerId(customerId);
    	//System.out.println(c.getCustomerId()+c.getDateOfBirth());
		return c;
	}

}
