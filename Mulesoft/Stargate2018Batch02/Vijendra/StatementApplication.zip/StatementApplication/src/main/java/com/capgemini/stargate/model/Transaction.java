
package com.capgemini.stargate.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "transaction")
public class Transaction
    extends Account
    implements Serializable
{

    final static long serialVersionUID = 7376791244987192006L;
    private String transactionId;
    private String referenceTransactionId;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date transactionTimeStamp;
    @Column(name = "description", insertable = false, updatable = false)
    private String transactionDescription;
    private Double amount;
    @Column(name = "status", insertable = false, updatable = false)
    private String transactionStatus;

    /**
     * Creates a new Transaction.
     * 
     */
    public Transaction() {
        super();
    }

    /**
     * Creates a new Transaction.
     * 
     */
    public Transaction(String bankId, String name, String branchId, String ifsc, String address, String city, String state, String country, String zip, String telephone, String email, String branchName, String customerId, Date dateOfBirth, String taxId, String governmentId, String emailId, String password, String accountId, String displayName, String description, AccountStatus status, String accountDescriptorid, String accountMasterId, String parentAccountId, String nickName, String lineOfBusiness, String accountNumber, Long interestRate, String currency, Long transferIn, Long transferOut, InterestRateType interestRateType, String transactionId, String referenceTransactionId, Date transactionTimeStamp, String transactionDescription, Double amount, String transactionStatus) {
        super(bankId, name, branchId, ifsc, address, city, state, country, zip, telephone, email, branchName, customerId, dateOfBirth, taxId, governmentId, emailId, password, accountId, displayName, description, status, accountDescriptorid, accountMasterId, parentAccountId, nickName, lineOfBusiness, accountNumber, interestRate, currency, transferIn, transferOut, interestRateType);
        this.transactionId = transactionId;
        this.referenceTransactionId = referenceTransactionId;
        this.transactionTimeStamp = transactionTimeStamp;
        this.transactionDescription = transactionDescription;
        this.amount = amount;
        this.transactionStatus = transactionStatus;
    }

    /**
     * Returns the transactionId.
     * 
     * @return
     *     transactionId
     */
    public String getTransactionId() {
        return transactionId;
    }

    /**
     * Set the transactionId.
     * 
     * @param transactionId
     *     the new transactionId
     */
    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    /**
     * Returns the referenceTransactionId.
     * 
     * @return
     *     referenceTransactionId
     */
    @JsonIgnore
    public String getReferenceTransactionId() {
        return referenceTransactionId;
    }

    /**
     * Set the referenceTransactionId.
     * 
     * @param referenceTransactionId
     *     the new referenceTransactionId
     */
    public void setReferenceTransactionId(String referenceTransactionId) {
        this.referenceTransactionId = referenceTransactionId;
    }

    /**
     * Returns the transactionTimeStamp.
     * 
     * @return
     *     transactionTimeStamp
     */
    public Date getTransactionTimeStamp() {
        return transactionTimeStamp;
    }

    /**
     * Set the transactionTimeStamp.
     * 
     * @param transactionTimeStamp
     *     the new transactionTimeStamp
     */
    public void setTransactionTimeStamp(Date transactionTimeStamp) {
        this.transactionTimeStamp = transactionTimeStamp;
    }

    /**
     * Returns the transactionDescription.
     * 
     * @return
     *     transactionDescription
     */
    public String getTransactionDescription() {
        return transactionDescription;
    }

    /**
     * Set the transactionDescription.
     * 
     * @param transactionDescription
     *     the new transactionDescription
     */
    public void setTransactionDescription(String transactionDescription) {
        this.transactionDescription = transactionDescription;
    }

    /**
     * Returns the amount.
     * 
     * @return
     *     amount
     */
    public Double getAmount() {
        return amount;
    }

    /**
     * Set the amount.
     * 
     * @param amount
     *     the new amount
     */
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    /**
     * Returns the transactionStatus.
     * 
     * @return
     *     transactionStatus
     */
    public String getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Set the transactionStatus.
     * 
     * @param transactionStatus
     *     the new transactionStatus
     */
    public void setTransactionStatus(String transactionStatus) {
        this.transactionStatus = transactionStatus;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(transactionId).append(referenceTransactionId).append(transactionTimeStamp).append(transactionDescription).append(amount).append(transactionStatus).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Transaction otherObject = ((Transaction) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(transactionId, otherObject.transactionId).append(referenceTransactionId, otherObject.referenceTransactionId).append(transactionTimeStamp, otherObject.transactionTimeStamp).append(transactionDescription, otherObject.transactionDescription).append(amount, otherObject.amount).append(transactionStatus, otherObject.transactionStatus).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("transactionId", transactionId).append("referenceTransactionId", referenceTransactionId).append("transactionTimeStamp", transactionTimeStamp).append("transactionDescription", transactionDescription).append("amount", amount).append("transactionStatus", transactionStatus).toString();
    }

}
