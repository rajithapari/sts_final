package com.capgemini.stargate.service;


import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.capgemini.stargate.dao.AccountRepository;
import com.capgemini.stargate.dao.StatementRepository;
import com.capgemini.stargate.exception.InternalServerErrorException;
import com.capgemini.stargate.exception.InvalidAccountIdException;
import com.capgemini.stargate.exception.InvalidDateFormatException;
import com.capgemini.stargate.model.AccountDesc;
import com.capgemini.stargate.model.Transaction;


@Repository
public class StatementServiceImpl implements StatementService{
	
	@Autowired
	StatementRepository statementRepo;
	
	@Autowired
	AccountRepository accountRepo;
	Optional<AccountDesc> accIdList;	
	
	final Pattern pattern = Pattern.compile("\\d++");
	final Pattern datePattern = Pattern.compile("^([0-9]{4})-(1[0-2]|0[1-9])-(3[01]|[12][0-9]|0[1-9]) (2[0-3]|[01]?[0-9]):([0-5]?[0-9]):([0-5]?[0-9])$");
	@Override
	public List<Transaction> getStatementCustom(String accountId, String startDate, String endDate) {
		
		try{
			if(pattern.matcher(accountId).matches() && accountId != null)
			{
				accIdList = accountRepo.findById(accountId);
				if(accIdList.get().getAccountId() != null)
				{
					if(datePattern.matcher(startDate).matches() && datePattern.matcher(endDate).matches()){
						List<Transaction> transactions = statementRepo.getStatements(accountId, startDate, endDate);
						return transactions;
					}
					else{
						throw new InvalidDateFormatException("Doesn't match date format please enter the date in yyyy-mm-dd hh:mm:ss format..");
					}
				}
			}
			else
			{
				 throw new InvalidAccountIdException("Doesn't match accountId format or Please pass AccountId.");
			}
		}
		catch (InvalidAccountIdException ex) {
			throw new InvalidAccountIdException("");
		}
		catch (InvalidDateFormatException ex) {
			throw new InvalidDateFormatException("");
		}
		catch (NoSuchElementException ex) {
			throw new NoSuchElementException("");
		}
		catch (Exception ex){
			throw new InternalServerErrorException("");
		}
		return statementRepo.getStatements(accountId, startDate, endDate);
	}
}