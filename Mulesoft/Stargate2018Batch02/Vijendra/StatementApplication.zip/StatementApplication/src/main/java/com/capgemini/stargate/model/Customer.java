
package com.capgemini.stargate.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "customer")
public class Customer
    extends Branch
    implements Serializable
{

    final static long serialVersionUID = 7403230993634007239L;
    private String customerId;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date dateOfBirth;
    private String taxId;
    private String governmentId;
    @Column(name = "email", insertable = false, updatable = false)
    private String emailId;
    private String password;

    /**
     * Creates a new Customer.
     * 
     */
    public Customer() {
        super();
    }

    /**
     * Creates a new Customer.
     * 
     */
    public Customer(String bankId, String name, String branchId, String ifsc, String address, String city, String state, String country, String zip, String telephone, String email, String branchName, String customerId, Date dateOfBirth, String taxId, String governmentId, String emailId, String password) {
        super(bankId, name, branchId, ifsc, address, city, state, country, zip, telephone, email, branchName);
        this.customerId = customerId;
        this.dateOfBirth = dateOfBirth;
        this.taxId = taxId;
        this.governmentId = governmentId;
        this.emailId = emailId;
        this.password = password;
    }

    /**
     * Returns the customerId.
     * 
     * @return
     *     customerId
     */
    public String getCustomerId() {
        return customerId;
    }

    /**
     * Set the customerId.
     * 
     * @param customerId
     *     the new customerId
     */
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    /**
     * Returns the dateOfBirth.
     * 
     * @return
     *     dateOfBirth
     */
    @JsonIgnore
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Set the dateOfBirth.
     * 
     * @param dateOfBirth
     *     the new dateOfBirth
     */
    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Returns the taxId.
     * 
     * @return
     *     taxId
     */
    @JsonIgnore
    public String getTaxId() {
        return taxId;
    }

    /**
     * Set the taxId.
     * 
     * @param taxId
     *     the new taxId
     */
    public void setTaxId(String taxId) {
        this.taxId = taxId;
    }

    /**
     * Returns the governmentId.
     * 
     * @return
     *     governmentId
     */
    @JsonIgnore
    public String getGovernmentId() {
        return governmentId;
    }

    /**
     * Set the governmentId.
     * 
     * @param governmentId
     *     the new governmentId
     */
    public void setGovernmentId(String governmentId) {
        this.governmentId = governmentId;
    }

    /**
     * Returns the emailId.
     * 
     * @return
     *     emailId
     */
    @JsonIgnore
    public String getEmailId() {
        return emailId;
    }

    /**
     * Set the emailId.
     * 
     * @param emailId
     *     the new emailId
     */
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    /**
     * Returns the password.
     * 
     * @return
     *     password
     */
    @JsonIgnore
    public String getPassword() {
        return password;
    }

    /**
     * Set the password.
     * 
     * @param password
     *     the new password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(customerId).append(dateOfBirth).append(taxId).append(governmentId).append(emailId).append(password).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Customer otherObject = ((Customer) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(customerId, otherObject.customerId).append(dateOfBirth, otherObject.dateOfBirth).append(taxId, otherObject.taxId).append(governmentId, otherObject.governmentId).append(emailId, otherObject.emailId).append(password, otherObject.password).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("customerId", customerId).append("dateOfBirth", dateOfBirth).append("taxId", taxId).append("governmentId", governmentId).append("emailId", emailId).append("password", password).toString();
    }

}
