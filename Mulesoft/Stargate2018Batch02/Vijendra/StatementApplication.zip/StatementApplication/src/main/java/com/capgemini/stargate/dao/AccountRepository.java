package com.capgemini.stargate.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.stargate.model.AccountDesc;

public interface AccountRepository extends JpaRepository<AccountDesc, String>{

}
