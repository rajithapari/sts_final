package com.capgemini.stargate.service;

import java.util.List;

import com.capgemini.stargate.model.Transaction;




public interface StatementService {
	
	public List<Transaction> getStatementCustom(String accountId, String startDate, String endDate);
}