
package com.capgemini.stargate.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "accountdescriptor")
public class AccountDescriptor
    extends Customer
    implements Serializable
{

    final static long serialVersionUID = 7409840926500743751L;
    private String accountId;
    private String displayName;
    private String description;
    @Enumerated(EnumType.STRING)
    private AccountStatus status;
    private String accountDescriptorid;

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor() {
        super();
    }

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor(String bankId, String name, String branchId, String ifsc, String address, String city, String state, String country, String zip, String telephone, String email, String branchName, String customerId, Date dateOfBirth, String taxId, String governmentId, String emailId, String password, String accountId, String displayName, String description, AccountStatus status, String accountDescriptorid) {
        super(bankId, name, branchId, ifsc, address, city, state, country, zip, telephone, email, branchName, customerId, dateOfBirth, taxId, governmentId, emailId, password);
        this.accountId = accountId;
        this.displayName = displayName;
        this.description = description;
        this.status = status;
        this.accountDescriptorid = accountDescriptorid;
    }

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Set the displayName.
     * 
     * @param displayName
     *     the new displayName
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Returns the description.
     * 
     * @return
     *     description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the description.
     * 
     * @param description
     *     the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    public AccountStatus getStatus() {
        return status;
    }

    /**
     * Set the status.
     * 
     * @param status
     *     the new status
     */
    public void setStatus(AccountStatus status) {
        this.status = status;
    }

    /**
     * Returns the accountDescriptorid.
     * 
     * @return
     *     accountDescriptorid
     */
    public String getAccountDescriptorid() {
        return accountDescriptorid;
    }

    /**
     * Set the accountDescriptorid.
     * 
     * @param accountDescriptorid
     *     the new accountDescriptorid
     */
    public void setAccountDescriptorid(String accountDescriptorid) {
        this.accountDescriptorid = accountDescriptorid;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(accountId).append(displayName).append(description).append(status).append(accountDescriptorid).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        AccountDescriptor otherObject = ((AccountDescriptor) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(accountId, otherObject.accountId).append(displayName, otherObject.displayName).append(description, otherObject.description).append(status, otherObject.status).append(accountDescriptorid, otherObject.accountDescriptorid).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("accountId", accountId).append("displayName", displayName).append("description", description).append("status", status).append("accountDescriptorid", accountDescriptorid).toString();
    }

}
