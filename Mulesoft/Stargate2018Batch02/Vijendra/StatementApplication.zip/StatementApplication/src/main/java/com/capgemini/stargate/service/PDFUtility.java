package com.capgemini.stargate.service;

import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.List;
import org.springframework.stereotype.Service;
import com.capgemini.stargate.model.Transaction;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.VerticalPositionMark;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;


@Service
public class PDFUtility {
	
	//private static final String FILE_NAME = "d:\\Vijendra\\Response\\SpringBootStatements.pdf";
	ByteArrayOutputStream out = new ByteArrayOutputStream();
	 private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 4, Font.BOLD);
	 Transaction transaction;
	
	public ByteArrayInputStream getStatementsInPDF(List<Transaction> transactions) throws FileNotFoundException, DocumentException{
		
		Document document = new Document();
		PdfWriter.getInstance(document, out);
		document.open();
		 Paragraph preface1 = new Paragraph();
		 preface1.add("Bank ");
		 preface1.add(transactions.get(0).getName());
		 preface1.setAlignment(Element.ALIGN_CENTER);
		 preface1.setFont(FontFactory.getFont(FontFactory.TIMES, 20f));
         document.add(preface1);
         
         Chunk glue = new Chunk(new VerticalPositionMark());
         Paragraph preface2 = new Paragraph();
         addEmptyLine(preface2, 3);
         preface2.add("Account Number:  ");
         preface2.add(transactions.get(0).getAccountNumber());
         preface2.add(new Chunk(glue));
         preface2.add("Customer Id:  ");
         preface2.add(transactions.get(0).getCustomerId());
         document.add(preface2);
         
         Paragraph preface3 = new Paragraph();
         preface3.add("Currency: ");
         preface3.add(transactions.get(0).getCurrency());
         preface3.setFont(subFont);
         preface3.setAlignment(Element.ALIGN_RIGHT);
         addEmptyLine(preface3, 2);
         document.add(preface3);
		//System.out.println("Inside PDF file......"+ transactions.get(0).getAccountId());
         
         // Adding Table
         PdfPTable table = new PdfPTable(5);
         table.setWidthPercentage(100f);
         PdfPCell c1 = new PdfPCell(new Phrase("TransactionId"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("TransactionTimestamp"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("Description"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("Status"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         c1 = new PdfPCell(new Phrase("Amount"));
         c1.setHorizontalAlignment(Element.ALIGN_CENTER);
         table.addCell(c1);
         
         table.setHeaderRows(1);
		Iterator<Transaction> transactionDetails = transactions.iterator();
		while (transactionDetails.hasNext()) {
			transaction = transactionDetails.next();
			table.addCell(transaction.getTransactionId());
			table.addCell(transaction.getTransactionTimeStamp().toString());
		    table.addCell(transaction.getTransactionDescription());
		    table.addCell(transaction.getTransactionStatus());
		    table.addCell(transaction.getAmount().toString());
		}
		document.add(table);
		document.close();
		return new ByteArrayInputStream(out.toByteArray());
	}
	private static void addEmptyLine(Paragraph paragraph, int number) {
        for (int i = 0; i < number; i++) {
            paragraph.add(new Paragraph(" "));
        }
    }
}
