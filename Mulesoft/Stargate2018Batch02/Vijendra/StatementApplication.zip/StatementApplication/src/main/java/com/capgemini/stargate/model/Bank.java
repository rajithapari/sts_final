
package com.capgemini.stargate.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "bank")
public class Bank implements Serializable
{

    final static long serialVersionUID = 7332174180956851365L;
    @Id
    private String bankId;
    private String name;

    /**
     * Creates a new Bank.
     * 
     */
    public Bank() {
        super();
    }

    /**
     * Creates a new Bank.
     * 
     */
    public Bank(String bankId, String name) {
        super();
        this.bankId = bankId;
        this.name = name;
    }

    /**
     * Returns the bankId.
     * 
     * @return
     *     bankId
     */
    @JsonIgnore
    public String getBankId() {
        return bankId;
    }

    /**
     * Set the bankId.
     * 
     * @param bankId
     *     the new bankId
     */
    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    /**
     * Returns the name.
     * 
     * @return
     *     name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the name.
     * 
     * @param name
     *     the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(bankId).append(name).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Bank otherObject = ((Bank) other);
        return new EqualsBuilder().append(bankId, otherObject.bankId).append(name, otherObject.name).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("bankId", bankId).append("name", name).toString();
    }

}
