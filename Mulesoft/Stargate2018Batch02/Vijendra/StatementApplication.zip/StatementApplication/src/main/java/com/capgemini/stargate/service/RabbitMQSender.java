package com.capgemini.stargate.service;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.capgemini.stargate.model.Transaction;

@Service
public class RabbitMQSender {
	@Autowired
	private AmqpTemplate rabbitTemplate;
	
	@Value("")
	private String exchange;
	
	@Value("")
	private String routingkey;	
	
	public void send(Transaction transaction) {
		rabbitTemplate.convertAndSend(exchange, routingkey, transaction);
		System.out.println("Send msg = " + transaction);
	    
	}
}
