package com.capgemini.stargate.service;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.capgemini.stargate.dao.StatementRepository;
import com.capgemini.stargate.model.Transaction;

public class StatementServiceImplTest {

	@InjectMocks
	StatementServiceImpl statementServiceImpl;

	@Mock
	StatementRepository statementRepo;
	
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testGetStatementCustom() {
		Transaction transaction = new Transaction();
		transaction.setAccountId("121");
		transaction.setAccountNumber("2222");
		transaction.setName("Axis Bank");
		//when( statementRepo.getStatements( toString(), toString(), toString() ).);
	}

}
