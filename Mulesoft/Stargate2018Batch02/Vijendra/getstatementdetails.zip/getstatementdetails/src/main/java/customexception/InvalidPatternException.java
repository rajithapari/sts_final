package customexception;

public class InvalidPatternException extends Exception {
	private static final long serialVersionUID = 1L;
	public InvalidPatternException(String ex) {
		super(ex);
	}
}
