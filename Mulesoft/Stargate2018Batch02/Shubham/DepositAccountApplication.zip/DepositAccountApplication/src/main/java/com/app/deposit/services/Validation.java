package com.app.deposit.services;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class Validation {
	
	public Boolean validateRequest(String accountType, Date currentDate) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date newDate = sdf.parse(sdf.format(new Date()));
		if (accountType.equals("deposit") && currentDate.compareTo(newDate)==0) {
			return true;
		} else {
			return false;
		}
	}
}
