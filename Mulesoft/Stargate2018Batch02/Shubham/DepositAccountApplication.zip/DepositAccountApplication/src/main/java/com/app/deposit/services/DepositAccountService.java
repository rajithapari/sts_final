package com.app.deposit.services;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.app.deposit.SimpleRpcProducerRabbitApplication;
import com.app.deposit.customexceptions.BadRequestException;
import com.app.deposit.customexceptions.NoDataException;
import com.app.deposit.model.DepositAccount;
import com.app.deposit.repositories.IDepositAccountRepository;
import com.google.gson.Gson;

@Service
public class DepositAccountService implements IDepositAccountService {

	 private static final Logger logger = LogManager.getLogger(DepositAccountService.class);

	@Autowired
	IDepositAccountRepository depositAccountRepository;

	@Autowired
	SimpleRpcProducerRabbitApplication producer;

	@Autowired
	BankCatalogClient bankSoapClient;

	@Value("${error.NoContent}")
	String errorNoContent;

	@Value("${error.BadRequest}")
	String errorBadRequest;

	@Override
	public List<DepositAccount> getAcc(String accountType, Date currentDate) throws Exception {
			Calendar c = Calendar.getInstance();
			c.setTime(currentDate);
			c.add(Calendar.DAY_OF_MONTH, 15);
			List<DepositAccount> list = depositAccountRepository.getAccounts(currentDate, c.getTime());
			if (null==list||list.size() == 0)
				throw new NoDataException(errorNoContent);
			producer.sendMessage(list);
			Gson gson = new Gson();
			for (DepositAccount account : list) {
				logger.info(gson.toJson(bankSoapClient.getBankById(account.getCustomerId())).toString());
			}
			return list;
	}
}