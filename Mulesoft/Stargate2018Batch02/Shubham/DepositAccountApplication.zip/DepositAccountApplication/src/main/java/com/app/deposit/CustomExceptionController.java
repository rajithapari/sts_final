package com.app.deposit;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.app.deposit.customexceptions.BadRequestException;
import com.app.deposit.customexceptions.NoDataException;
import com.app.deposit.model.Error;

@RestController
@ControllerAdvice
public class CustomExceptionController extends ResponseEntityExceptionHandler {

	@ResponseStatus(HttpStatus.NO_CONTENT)
	@ExceptionHandler(value = NoDataException.class)
	public ResponseEntity<Error> noContent(NoDataException ex) {
		return new ResponseEntity<Error>(new Error("204", ex.getMessage()), HttpStatus.NO_CONTENT);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(value = BadRequestException.class)
	public ResponseEntity<Error> badRequest(BadRequestException ex) {
		System.out.println(ex.getMessage());
		return new ResponseEntity<Error>(new Error("400", ex.getMessage()), HttpStatus.BAD_REQUEST);
	}

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<Error> handleInternalError(Exception ex) {
		return new ResponseEntity<Error>(new Error("500", "Some Internal Error Occured"),
				HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	@ExceptionHandler(value = UnAuthorizedException.class)
	public ResponseEntity<Error> unAuthorized(UnAuthorizedException ex) {
		System.out.println(ex.getMessage()+"in custom");
		return new ResponseEntity<Error>(new Error("401", ex.getMessage()), HttpStatus.UNAUTHORIZED);
	}
	
	
	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		return new ResponseEntity<Object>(new Error("405","Method not supported"), HttpStatus.METHOD_NOT_ALLOWED);
	}
}
