package com.app.deposit;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.app.deposit.model.DepositAccount;

import java.util.List;

@Component
public class SimpleRpcProducerRabbitApplication {

	private final RabbitTemplate template;

	@Autowired
	public SimpleRpcProducerRabbitApplication(RabbitTemplate template) {
		this.template = template;
	}

	public void sendMessage(List<DepositAccount> depositAccounts) {
		this.template.convertAndSend("spring-boot-test", depositAccounts.toString());
	}

	@Bean
	public Queue queue() {
		return new Queue("spring-boot-test", false);
	}
}
