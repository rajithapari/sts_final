package com.app.deposit.services;

import java.util.Date;
import java.util.List;

import com.app.deposit.model.DepositAccount;

public interface IDepositAccountService {

	public List<DepositAccount> getAcc(String accountType, Date currentDate) throws Exception;

}
