package com.app.deposit;

public class UnAuthorizedException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4661265797119716547L;

	public UnAuthorizedException(String message) {
		super(message);
	}

}
