package com.app.deposit.repositories;

import org.springframework.data.repository.CrudRepository;

import com.app.deposit.model.DepositAccount;

public interface IDepositAccountRepository extends CrudRepository<DepositAccount, String>{

	

}
