
package com.app.deposit;

import java.util.Date;
import java.util.List;

import com.app.deposit.model.AccountDescriptor;
import com.app.deposit.model.DepositAccount;
import com.app.deposit.services.IDepositAccountService;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


/**
 * No description
 * (Generated with springmvc-raml-parser v.2.0.3)
 * 
 */
@RestController
@RequestMapping(value = "/api/v1/dda/accounts", produces = "application/json")
@Validated
public class AccountController {

	@Autowired
	IDepositAccountService depositAccountService;
	
    /**
     * Get All Deposit Accounts which are approching maturity date
     * 
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public ResponseEntity<List<DepositAccount>> getDepositAccounts(
        @RequestParam
        String accountType,
        @RequestParam
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        Date currentDate,
        @RequestHeader(name = "Accept", defaultValue = "application/json", required = false)
        String accept) {
    	System.out.println("in controller");
        return new ResponseEntity<List<DepositAccount>>(depositAccountService.getAcc(accountType,currentDate),HttpStatus.OK);
    }

}
