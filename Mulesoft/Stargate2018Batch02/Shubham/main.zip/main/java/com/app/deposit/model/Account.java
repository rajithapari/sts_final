
package com.app.deposit.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name="account")
public class Account
    extends AccountDescriptor
    implements Serializable
{

    final static long serialVersionUID = -1935308603475397464L;
    /**
     * The user�s moniker for the account
     * 
     */
    @Basic(optional=true)
    protected String nickname;
    /**
     * End user�s handle for account at owning institution
     * 
     */
    @Basic(optional=true)
    protected String accountNumber;
    /**
     * Interest Rate of Account
     * 
     */
    @Basic(optional=true)
    protected Double interestRate;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
   
    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    @NotNull
    @Pattern(regexp = "\\d+")
    @Size(max = 128)
    public String getAccountId() {
        return accountId;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    @NotNull
    public Status getStatus() {
        return status;
    }

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * Set the nickname.
     * 
     * @param nickname
     *     the new nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    @NotNull
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    @NotNull
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     */
    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(nickname).append(accountNumber).append(interestRate).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(nickname, otherObject.nickname).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("nickname", nickname).append("accountNumber", accountNumber).append("interestRate", interestRate).toString();
    }

}
