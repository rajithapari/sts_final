
package com.app.deposit.model;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name="depositaccount")
public class DepositAccount
    extends Account
    implements Serializable
{

    final static long serialVersionUID = -1855989374714820950L;
    /**
     * As-of date of balances
     * 
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    protected Date balanceAsOf;
    /**
     * Balance of funds in account
     * 
     */
    protected Double currentBalance;
    /**
     * Maturity date for CDs
     * 
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    protected Date maturityDate;    
    
    /**
     * Creates a new DepositAccount.
     * 
     */
    public DepositAccount() {
        super();
    }

    /**
     * Creates a new DepositAccount.
     * 
     */
    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    @NotNull
    @Pattern(regexp = "\\d+")
    @Size(max = 128)
    public String getAccountId() {
        return accountId;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    @NotNull
    public Status getStatus() {
        return status;
    }

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    @NotNull
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    @NotNull
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Returns the balanceAsOf.
     * 
     * @return
     *     balanceAsOf
     */
    @NotNull
    public Date getBalanceAsOf() {
        return balanceAsOf;
    }

    /**
     * Set the balanceAsOf.
     * 
     * @param balanceAsOf
     *     the new balanceAsOf
     */
    public void setBalanceAsOf(Date balanceAsOf) {
        this.balanceAsOf = balanceAsOf;
    }

    /**
     * Returns the currentBalance.
     * 
     * @return
     *     currentBalance
     */
    @NotNull
    public Double getCurrentBalance() {
        return currentBalance;
    }

    /**
     * Set the currentBalance.
     * 
     * @param currentBalance
     *     the new currentBalance
     */
    public void setCurrentBalance(Double currentBalance) {
        this.currentBalance = currentBalance;
    }

    /**
     * Returns the maturityDate.
     * 
     * @return
     *     maturityDate
     */
    @NotNull
    public Date getMaturityDate() {
    	Calendar c = Calendar.getInstance();
    	c.setTime(maturityDate);
    	c.add(Calendar.DAY_OF_MONTH, 1);
        return c.getTime();
    }

    /**
     * Set the maturityDate.
     * 
     * @param maturityDate
     *     the new maturityDate
     */
    public void setMaturityDate(Date maturityDate) {
    	
        this.maturityDate = maturityDate;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(balanceAsOf).append(currentBalance).append(maturityDate).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        DepositAccount otherObject = ((DepositAccount) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(balanceAsOf, otherObject.balanceAsOf).append(currentBalance, otherObject.currentBalance).append(maturityDate, otherObject.maturityDate).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("balanceAsOf", balanceAsOf).append("currentBalance", currentBalance).append("maturityDate", maturityDate).toString();
    }

}
