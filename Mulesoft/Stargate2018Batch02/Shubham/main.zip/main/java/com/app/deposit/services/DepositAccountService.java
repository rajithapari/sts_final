package com.app.deposit.services;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.app.deposit.model.DepositAccount;

@Service
public class DepositAccountService implements IDepositAccountService{
	
	@PersistenceContext
	EntityManager manager;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<DepositAccount> getAcc(String accountType, Date currentDate) {
		System.out.println("in service");		
		Calendar c = Calendar.getInstance();
    	c.setTime(currentDate);
    	c.add(Calendar.DAY_OF_MONTH, 15);
		Query query = manager.createNativeQuery("SELECT ad.AccountDescriptorId , ad.AccountId ,ad.AccountType , a.AccountNumber, a.Nickname , "
				+ "a.InterestRate,d.BalanceAsOf , d.CurrentBalance , d.MaturityDate , ad.Status FROM shubham_stargate.depositaccount d "
				+ "inner join shubham_stargate.account a inner join shubham_stargate.accountdescriptor ad "
				+ "on d.RefAccountId = a.AccountMasterId and a.AccDescriptorId = ad.AccountDescriptorId "
				+ "where d.MaturityDate between ? and ?",DepositAccount.class );
		query.setParameter(1, currentDate);
		query.setParameter(2, c.getTime());
		return query.getResultList();
	}

}