
package com.app.deposit.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="accountdescriptor")
@JsonIgnoreProperties("accountDescriptorId")
public class AccountDescriptor implements Serializable
{

    final static long serialVersionUID = -1935308603475397464L;
    /**
     * Long-term persistent identity of the account. Not an account number.This identity must be unique to the owning institution.
     * 
     */
    @Basic(optional=true)
    protected String accountId;
    /**
     * This field defines the type of Account from the list defined
     * 
     */
    @Column(name="AccountType")
    @Enumerated(EnumType.STRING)
    @Basic(optional=true)
    protected AccountType accountType;
    /**
     * This field defines the status of the account
     * 
     */
    @Enumerated(EnumType.STRING)
    @Basic(optional=true)
    protected Status status;
    /**
     * This field is the primary key for the entity and connected to the foreign key in account table with column accDescriptorId
     * 
     */
    @Id
    @Column(name="AccountDescriptorId")
    @Basic(optional=true)
    protected Integer accountDescriptorId;
    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor() {
        super();
    }

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    
    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    @NotNull
    @Pattern(regexp = "\\d+")
    @Size(max = 128)
    public String getAccountId() {
        return accountId;
    }

    /**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    @Valid
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * Set the accountType.
     * 
     * @param accountType
     *     the new accountType
     */
    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    @NotNull
    @Valid
    public Status getStatus() {
        return status;
    }

    /**
     * Set the status.
     * 
     * @param status
     *     the new status
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    public Integer getAccountDescriptorId() {
		return accountDescriptorId;
	}

	public void setAccountDescriptorId(Integer accountDescriptorId) {
		this.accountDescriptorId = accountDescriptorId;
	}

	public int hashCode() {
        return new HashCodeBuilder().append(accountId).append(accountType).append(status).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        AccountDescriptor otherObject = ((AccountDescriptor) other);
        return new EqualsBuilder().append(accountId, otherObject.accountId).append(accountType, otherObject.accountType).append(status, otherObject.status).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accountId", accountId).append("accountType", accountType).append("status", status).toString();
    }

}
