import org.mule.api.MuleEventContext;

public class PDFGenrater implements org.mule.api.lifecycle.Callable{

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


}
