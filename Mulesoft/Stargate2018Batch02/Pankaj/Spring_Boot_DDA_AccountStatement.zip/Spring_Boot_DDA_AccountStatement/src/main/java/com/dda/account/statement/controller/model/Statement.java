
package com.dda.account.statement.controller.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "statement")
public class Statement implements Serializable
{

    final static long serialVersionUID = -8714385390338981523L;
    @Id
    @Column(name="AccountId")
    private String accountId;
    @Column(name="StatementId")
    private String statementId;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @Column(name="StatementDate")
    private Date statementDate;
    @Column(name="Description")
    private String description;

    /**
     * Creates a new Statement.
     * 
     */
    public Statement() {
        super();
    }

    /**
     * Creates a new Statement.
     * 
     */
    public Statement(String accountId, String statementId, Date statementDate, String description) {
        super();
        this.accountId = accountId;
        this.statementId = statementId;
        this.statementDate = statementDate;
        this.description = description;
    }

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the statementId.
     * 
     * @return
     *     statementId
     */
    public String getStatementId() {
        return statementId;
    }

    /**
     * Set the statementId.
     * 
     * @param statementId
     *     the new statementId
     */
    public void setStatementId(String statementId) {
        this.statementId = statementId;
    }

    /**
     * Returns the statementDate.
     * 
     * @return
     *     statementDate
     */
    public Date getStatementDate() {
        return statementDate;
    }

    /**
     * Set the statementDate.
     * 
     * @param statementDate
     *     the new statementDate
     */
    public void setStatementDate(Date statementDate) {
        this.statementDate = statementDate;
    }

    /**
     * Returns the description.
     * 
     * @return
     *     description
     */
    public String getDescription() {
        return description;
    }

    /**
     * Set the description.
     * 
     * @param description
     *     the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(accountId).append(statementId).append(statementDate).append(description).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Statement otherObject = ((Statement) other);
        return new EqualsBuilder().append(accountId, otherObject.accountId).append(statementId, otherObject.statementId).append(statementDate, otherObject.statementDate).append(description, otherObject.description).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accountId", accountId).append("statementId", statementId).append("statementDate", statementDate).append("description", description).toString();
    }

}
