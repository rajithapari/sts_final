
package com.dda.account.statement.controller;

import com.dda.account.statement.controller.model.Statement;
import com.dda.account.statement.custom.exception.StatementNotFoundException;
import com.dda.account.statement.custom.exception.StatementResponseEntityExceptionHandler;
import com.dda.account.statement.custom.exception.UnsupportMediaTypeException;
import com.dda.account.statement.service.AccountSatementServiceInterface;
import com.dda.account.statement.util.StatementInPDFUtils;
import com.dda.account.statement.validator.ValidateAccountIdStatementId;

import java.io.ByteArrayInputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


/**
 * No description
 * (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
@RequestMapping(value = "/api/accounts/{accountId}/statement/{statementId}", produces = "application/json")
@Validated
public class StatementIdController {


    /**
     * To get an account statement
     * 
     */
	

	
	@Autowired
	AccountSatementServiceInterface accountSatementServiceimpl;
	
	@Autowired 
	ValidateAccountIdStatementId validator; 
	 
	@Autowired
	StatementProducerMq statementProducerMq;

	
    @RequestMapping(value = "", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<?> getStatementByAccountId(@PathVariable String accountId, @PathVariable String statementId) throws Exception {
    	System.out.println(accountId);
    	System.out.println(statementId);
    	
    	Statement	statement;
    	HttpHeaders headers = new HttpHeaders();
    	    	
    	try
    	{
    		if(validator.validateAccoIdStatId(accountId, statementId))
    		{
    		
        	statement = accountSatementServiceimpl.getAccountStatement(accountId, statementId);
        	
        	//getting customerId for Soap Call
    		String customerId = accountSatementServiceimpl.getCoustomerId(accountId);
    	 	String str = statement.toString();
        	statementProducerMq.sendMessage(str);
    		
    		ByteArrayInputStream bis = StatementInPDFUtils.statementReport(statement);
        	
    		headers.set("Content-Disposition", "inline; filename = statement.pdf");
    		
    		
    		//calling to soap service
    		accountSatementServiceimpl.soapPrint(customerId);
    		
    		//clling to AMQP
    		statementProducerMq.sendMessage(str);
    		
        	  	    	
            return ResponseEntity .ok() .headers(headers) .contentType(MediaType.APPLICATION_PDF).body(new InputStreamResource(bis));
    		}
    		else
    		{
    			throw new StatementNotFoundException("throwing bad request with accountId or statementId");
    		}
    	}
    	catch(StatementNotFoundException e)
    	{
    		return  new StatementResponseEntityExceptionHandler().handleStatementNotFoundException(e);
    	}
    	catch(UnsupportMediaTypeException e)
    	{
    		return new StatementResponseEntityExceptionHandler().handleAllUnsupoortMediaType(e);
    	}
    	
    	
    }
    
}
