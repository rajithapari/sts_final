package com.dda.account.statement.service;

import org.springframework.stereotype.Service;

import com.dda.account.statement.controller.model.Statement;

@Service
public interface AccountSatementServiceInterface {
	
	

	public Statement getAccountStatement(String accountId, String statementId);
	
	public void soapPrint(String customerId);
	
	public String getCoustomerId(String accountId);
}
