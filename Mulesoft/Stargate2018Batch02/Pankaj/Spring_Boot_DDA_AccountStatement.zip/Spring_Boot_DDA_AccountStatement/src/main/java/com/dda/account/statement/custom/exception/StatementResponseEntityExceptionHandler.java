package com.dda.account.statement.custom.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;




@ControllerAdvice
public class StatementResponseEntityExceptionHandler extends ResponseEntityExceptionHandler{
	
	@ExceptionHandler(Exception.class)
	  public final ResponseEntity<ErrorDetails> handleAllExceptions(Exception ex) {
	    ErrorDetails errorDetails = new ErrorDetails("500", "Internal Server Error");
	    return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);//500
	  }
	
	@ExceptionHandler(UnsupportMediaTypeException.class)
	  public final ResponseEntity<ErrorDetails> handleAllUnsupoortMediaType(UnsupportMediaTypeException ex) {
	    ErrorDetails errorDetails = new ErrorDetails("415","Unsupport Media type: Response should be in PDF form ");
	    return new ResponseEntity<>(errorDetails, HttpStatus.UNSUPPORTED_MEDIA_TYPE);//415
	  }

	  @ExceptionHandler(StatementNotFoundException.class)
	  public final ResponseEntity<ErrorDetails> handleStatementNotFoundException(StatementNotFoundException ex) {
	    ErrorDetails errorDetails = new ErrorDetails("404","AccountId Or StatementId Not Found");
	    return new ResponseEntity<>(errorDetails, HttpStatus.NOT_FOUND);
	  }
	  
	 @ExceptionHandler(BadRequestException.class)
	  public final ResponseEntity<ErrorDetails> handleBadRequest(BadRequestException ex) {
	    ErrorDetails errorDetails = new ErrorDetails("400","Bad Request with invalid Parameter");
	    return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	    
	  }
	 
	 /* 
	  
	  @ExceptionHandler(Exception.class)
	  public final ResponseEntity<ErrorDetails> handleUnauthorizedRequest(Exception ex, WebRequest request) {
	    ErrorDetails errorDetails = new ErrorDetails( ex.getMessage(),request.getDescription(false));
	    return new ResponseEntity<>(errorDetails, HttpStatus.UNAUTHORIZED);//401
    
	  }*/	
	  
	  
	  

}
