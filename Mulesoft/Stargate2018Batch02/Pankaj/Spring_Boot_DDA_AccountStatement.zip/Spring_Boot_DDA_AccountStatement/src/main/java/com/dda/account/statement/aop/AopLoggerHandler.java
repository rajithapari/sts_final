package com.dda.account.statement.aop;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import com.dda.account.statement.DdaAccountStatementApplication;



@Aspect
@Component
public class AopLoggerHandler {

	/*private static final Logger LOGGER = LogManager.getLogger(AopLoggerHandler.class);
	   
	@Before("execution(* com.dda.account.statement.DdaAccountStatementApplication.getStatementByAccountId())")
	public void logBefore(JoinPoint joinPoint) {
		LOGGER.info("Started:"+joinPoint);
	}

	@After("execution(* com.dda.account.statement.DdaAccountStatementApplication.getStatementByAccountId())")
	public void logAfter(JoinPoint joinPoint) {
		LOGGER.info("Completed:"+joinPoint);
	}*/
}
