package com.dda.account.statement.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dda.account.statement.controller.model.Statement;
import com.dda.account.statement.dao.AccountStatementDaoInterface;
import com.dda.account.statement.repository.AccountStatementRepository;

@Component
public class AccountStatementDaoImpl implements AccountStatementDaoInterface{

	@Autowired
	AccountStatementRepository accountStatementRepository;

	@Override
	public Statement getAccountStatement(String accountId, String statementId) {
		// TODO Auto-generated method stub
		return accountStatementRepository.getAccountStatement(accountId,statementId);
	}

	@Override
	public String getCoustomerId(String accountId) {
		// TODO Auto-generated method stub
		return accountStatementRepository.getCoustomerId(accountId);
	}
	
	
	

}
