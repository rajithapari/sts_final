package com.dda.account.statement.custom.exception;

import org.springframework.web.bind.annotation.ResponseStatus;


public class StatementNotFoundException extends RuntimeException {
	
		public StatementNotFoundException(String exception) {
	    super(exception);
	  }
}


