package com.dda.account.statement.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.dda.account.statement.controller.model.Statement;


@Repository
public interface AccountStatementRepository extends CrudRepository<Statement, String> {
	
	@Query(value= "Select * FROM Statement a WHERE a.accountId =:accountId and a.statementId =:statementId", nativeQuery=true)
	public Statement getAccountStatement(@Param("accountId") String accountId , @Param("statementId") String statementId);
	
	@Query(value= "SELECT CustomerId from accountdescriptor ad WHERE ad.accountId =:accountId",nativeQuery=true)
	public String getCoustomerId(@Param("accountId") String accountId);

}
