package com.dda.account.statement.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.dda.account.statement.controller.model.Statement;




@Component
public class StatementProducerMq {
	
	private final RabbitTemplate template;

	/*public static void main(String[] args) {
		
		SpringApplication.run(StatementProducerMq.class, args);
	}*/
	@Autowired
	public StatementProducerMq(RabbitTemplate template)
	{
		this.template = template;
	}
	

	    public void sendMessage(String s) {
	        //String timestamp = new SimpleDateFormat("HH:mm:ss").format(new Date());
	        //String message = "Hello Muleeeeee world! " + timestamp;
	        
	    	System.out.println(s);
	        template.convertAndSend("Account_Statement",s.toString());
	        
	      	    }

	    @Bean
	    public Queue queue() {
	        return new Queue("Account_Statement", false);
	    }

}
