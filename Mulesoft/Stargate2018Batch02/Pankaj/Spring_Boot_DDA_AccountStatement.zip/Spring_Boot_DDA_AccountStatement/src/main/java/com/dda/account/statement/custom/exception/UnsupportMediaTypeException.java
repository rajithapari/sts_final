package com.dda.account.statement.custom.exception;

public class UnsupportMediaTypeException extends RuntimeException{

	public UnsupportMediaTypeException(String exception) {
		super(exception);
	
	}

}
