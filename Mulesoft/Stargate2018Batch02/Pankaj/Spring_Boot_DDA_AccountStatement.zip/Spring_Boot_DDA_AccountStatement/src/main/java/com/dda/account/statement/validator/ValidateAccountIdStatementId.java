package com.dda.account.statement.validator;

import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

@Service
public class ValidateAccountIdStatementId {
	
	public boolean validateAccoIdStatId(String accountId, String statementId)
	{
        final Pattern pattern = Pattern.compile("\\d++"); 
        if (pattern.matcher(accountId).matches() && accountId != null && pattern.matcher(statementId).matches() && statementId != null)
        { 
                return true; 
        } 
        else 
        { 
                return false; 
        } 

	}

}
