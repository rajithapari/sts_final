package com.dda.account.statement.dao;



import org.springframework.stereotype.Component;

import com.dda.account.statement.controller.model.Statement;



@Component
public interface AccountStatementDaoInterface {

	public Statement getAccountStatement(String accountId, String statementId);

	public String getCoustomerId(String accountId);
	
}
