package com.dda.account.statement.service.Impl;

import java.io.FileWriter;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dda.account.statement.controller.model.Statement;
import com.dda.account.statement.dao.AccountStatementDaoInterface;
import com.dda.account.statement.service.AccountSatementServiceInterface;
import com.dda.account.statement.soapcall.BankCatalogClient;
import com.google.gson.Gson;

import bank_web_service.GetBankDetailsResponse;

@Service
public class AccountSatementServiceImpl implements AccountSatementServiceInterface{

	@Autowired
	AccountStatementDaoInterface accountStatementDaoImpl;
	
	@Autowired
	BankCatalogClient bankCatalogClient;
	@Override
	public Statement getAccountStatement(String accountId, String statementId) {
		// TODO Auto-generated method stub
		return accountStatementDaoImpl.getAccountStatement(accountId, statementId);
	}

	@Override
	public void soapPrint(String customerId) {
		
		GetBankDetailsResponse response = bankCatalogClient.getBankById(customerId);
		Gson gson = new Gson();
		System.out.println(gson.toJson(response));
		try
		{
		    String filename= "MyFile.txt";
		    FileWriter fw = new FileWriter(filename,true); 
		    fw.write(gson.toJson(response));
		    fw.close();
		}
		catch(IOException ioe)
		{
		    System.err.println("IOException: " + ioe.getMessage());
		}
		
	}

	@Override
	public String getCoustomerId(String accountId) {
		// TODO Auto-generated method stub
		return accountStatementDaoImpl.getCoustomerId(accountId);
	}

	
	

}
