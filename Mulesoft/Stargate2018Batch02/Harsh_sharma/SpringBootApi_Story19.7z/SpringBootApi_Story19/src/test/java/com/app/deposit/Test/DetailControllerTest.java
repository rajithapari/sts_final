package com.app.deposit.Test;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureWebMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.app.deposit.controller.DetailController;
import com.app.deposit.model.SingleAccountDetailsRequest;
import com.app.deposit.service.AccountService;

@SpringBootTest
@RunWith(SpringRunner.class)
@AutoConfigureWebMvc
public class DetailControllerTest {

	@InjectMocks
	private DetailController detailsController;
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private AccountService accountService;
	
	
	
	String singleAccountRequestJson = "[{\"accountId\":\"1357902469\",\"startTime\":\"2015-04-01T00:00:00.000Z\"}]";
	
	/*SingleAccountDetailsRequest Account = new SingleAccountDetailsRequest("1357902469");*/
	
	String expectedAccountsJson="{\"total\":\"null\",\"totalPages\":\"null\",\"page\":\"null\",\"accounts\":[{\"accountId\":\"1357902469\",\"displayName\":\"Loan Account\",\"description\":\"Loan Account\",\"accountType\":\"LOAN\",\"status\":\"OPEN\",\"accountDescriptorId\":\"112\",\"customerId\":\"111111102\",\"parentAccountId\":\"2468135791\",\"interestRate\":\"3\",\"nickname\":\"My Savings Account\",\"currency\":\"INR\",\"accountNumber\":\"4561237891\",\"lineOfBusiness\":\"small business\",\"transferIn\":\"1\",\"transferOut\":\"1\",\"interestRateType\":\"VARIABLE\"}]}";
	
	@Before
	public void setUp() throws Exception
	{
		mockMvc=MockMvcBuilders.standaloneSetup(detailsController).build();
	}
	
	@Test
	public void testDetailController() throws Exception
	{
		RequestBuilder requestBuilder=MockMvcRequestBuilders.post("/api/v1/accounts/details").accept(org.springframework.http.MediaType.APPLICATION_JSON).content(singleAccountRequestJson).contentType(org.springframework.http.MediaType.APPLICATION_JSON);

        MvcResult result=(MvcResult) mockMvc.perform(requestBuilder).andReturn();
		System.out.println(result.getResponse());
		
		
		MockHttpServletResponse response = result.getResponse();
		JSONAssert.assertEquals(expectedAccountsJson, result.getResponse()
				.getContentAsString(), false);
		
	}
	
	
	
	
	
}
