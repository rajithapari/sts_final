package com.app.deposit.exception;



public class AccountNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -3332292346834265371L;

	public AccountNotFoundException(){
		super();
	}

	public AccountNotFoundException(final String message) {
		super(message);
	}
}
