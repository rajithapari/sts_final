 package com.app.deposit.service;


import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import com.app.deposit.model.Account;
import com.app.deposit.model.Accounts;
import com.app.deposit.SimpleRpcProducerRabbitApplication;
import com.app.deposit.exception.AccountNotFoundException;
import com.app.deposit.exception.BadRequestException;
import com.app.deposit.exception.InternalServerException;
import com.app.deposit.model.SingleAccountDetailsRequest;

import com.app.deposit.repository.IAccountRepository;


@Service("accountServiceImpl")
public class AccountService implements IAccountService {
	
	@Autowired
	Accounts accounts;

	@Autowired
	SimpleRpcProducerRabbitApplication rpcProducerRabbitApplication;
	
	
    @Autowired
	@Qualifier("accountRepositoryImpl")
	IAccountRepository iAccountRepository;

	public Accounts getallAccountDetails(List<SingleAccountDetailsRequest> singleAccountDetailsRequest)
			throws AccountNotFoundException, InternalServerException {
		try {
			 List<Account> account = new ArrayList<Account>();
			account.clear();

			for (SingleAccountDetailsRequest SingleAccount : singleAccountDetailsRequest) {

				if ((!(SingleAccount.getAccountId().matches("\\d+")))
						|| SingleAccount.getAccountId().matches("[!@#$%&*()_+=|<>?{}\\\\[\\\\]~-]")) {
					throw new BadRequestException();
				} else {

					List<Account> singleAccount = (List<Account>) iAccountRepository
							.GetAccountDetailsById(SingleAccount.getAccountId());
					
					if (singleAccount.isEmpty()) {
						throw new AccountNotFoundException();
					}
					account.addAll(singleAccount);
				}

			}
			accounts.setAccounts(account);
			rpcProducerRabbitApplication.sendMessage(accounts);
			return accounts;
		} 
		catch (AccountNotFoundException e) {
			throw new AccountNotFoundException("Account not found");
		} 
		catch (BadRequestException e) {
			throw new BadRequestException("Invalid account id");
		}
		catch (Exception ex) {
			throw new InternalServerException("Internal Server Error");
		}

	}
	

}
