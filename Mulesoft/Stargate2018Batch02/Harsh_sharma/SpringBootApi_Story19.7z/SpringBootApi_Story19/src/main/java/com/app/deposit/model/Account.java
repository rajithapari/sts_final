
package com.app.deposit.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "account")
@JsonIgnoreProperties({ "accountMasterId", "accDescriptorId"})
public class Account extends AccountDescriptor implements Serializable {

	final static long serialVersionUID = 1898355260222214503L;
	/**
	 * parent account id of account.
	 * 
	 */

	@Column
	private String accountMasterId;

	@Column
	private String parentAccountId;
	/**
	 * rate of interest of particularaccount.
	 * 
	 */
	@Column
	private Double interestRate;
	/**
	 * The user�s moniker for the account.
	 * 
	 */
	@Column
	private String nickname;
	/**
	 * Currency Aggregate.
	 * 
	 */
	@Column
	@Enumerated(EnumType.STRING)
	private Iso4217Code currency;
	/**
	 * End user�s handle for account at owning institution.
	 * 
	 */
	@Column
	private String accountNumber;
	/**
	 * Date of account�s interest rate.
	 * 
	 */
	@Column
	private String lineOfBusiness;

	@Column
    private int accDescriptorId;

	@Column
	private int transferIn;
	
	@Column
	private Date lastActivityDate;

	@Column
	private int transferOut;

	@Column
	@Enumerated(EnumType.STRING)
	private InterestRateType interestRateType;

	/**
	 * Creates a new Account.
	 * 
	 */
	public Account() {
		super();
	}

	/**
	 * Creates a new Account.
	 * 
	 */

	/**
	 * Returns the parentAccountId.
	 * 
	 * @return parentAccountId
	 */
	public String getParentAccountId() {
		return parentAccountId;
	}

	public String getAccountMasterId() {
		return accountMasterId;
	}

	public void setAccountMasterId(String accountMasterId) {
		this.accountMasterId = accountMasterId;
	}

	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	public int getAccDescriptorId() {
		return accDescriptorId;
	}

	public void setAccDescriptorId(int accDescriptorId) {
		this.accDescriptorId = accDescriptorId;
	}

	public int getTransferIn() {
		return transferIn;
	}

	public void setTransferIn(int transferIn) {
		this.transferIn = transferIn;
	}

	public int getTransferOut() {
		return transferOut;
	}

	public void setTransferOut(int transferOut) {
		this.transferOut = transferOut;
	}

	public Account(String accountMasterId, String parentAccountId, Double interestRate, String nickname,
			Iso4217Code currency, String accountNumber, String lineOfBusiness, int accDescriptorId, int transferIn,
			int transferOut, InterestRateType interestRateType) {
		super();
		this.accountMasterId = accountMasterId;
		this.parentAccountId = parentAccountId;
		this.interestRate = interestRate;
		this.nickname = nickname;
		this.currency = currency;
		this.accountNumber = accountNumber;
		this.lineOfBusiness = lineOfBusiness;
		this.accDescriptorId = accDescriptorId;
		this.transferIn = transferIn;
		this.transferOut = transferOut;
		this.interestRateType = interestRateType;
	}

	/**
	 * Set the parentAccountId.
	 * 
	 * @param parentAccountId the new parentAccountId
	 */
	public void setParentAccountId(String parentAccountId) {
		this.parentAccountId = parentAccountId;
	}

	/**
	 * Returns the interestRate.
	 * 
	 * @return interestRate
	 */
	public Double getInterestRate() {
		return interestRate;
	}

	/**
	 * Set the interestRate.
	 * 
	 * @param interestRate the new interestRate
	 */
	public void setInterestRate(Double interestRate) {
		this.interestRate = interestRate;
	}

	/**
	 * Returns the nickname.
	 * 
	 * @return nickname
	 */
	public String getNickname() {
		return nickname;
	}

	/**
	 * Set the nickname.
	 * 
	 * @param nickname the new nickname
	 */
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	/**
	 * Returns the currency.
	 * 
	 * @return currency
	 */
	public Iso4217Code getCurrency() {
		return currency;
	}

	/**
	 * Set the currency.
	 * 
	 * @param currency the new currency
	 */
	public void setCurrency(Iso4217Code currency) {
		this.currency = currency;
	}

	/**
	 * Returns the accountNumber.
	 * 
	 * @return accountNumber
	 */
	public String getAccountNumber() {
		return accountNumber;
	}

	/**
	 * Set the accountNumber.
	 * 
	 * @param accountNumber the new accountNumber
	 */
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	/**
	 * Returns the interestRateType.
	 * 
	 * @return interestRateType
	 */
	public InterestRateType getInterestRateType() {
		return interestRateType;
	}

	/**
	 * Set the interestRateType.
	 * 
	 * @param interestRateType the new interestRateType
	 */
	public void setInterestRateType(InterestRateType interestRateType) {
		this.interestRateType = interestRateType;
	}

	public int hashCode() {
		return new HashCodeBuilder().appendSuper(super.hashCode()).append(parentAccountId).append(interestRate)
				.append(nickname).append(currency).append(accountNumber).append(interestRateType)
				.append(accDescriptorId).append(transferIn).append(transferOut).append(accountMasterId)
				.append(lineOfBusiness).toHashCode();
	}

	public boolean equals(Object other) {
		if (other == null) {
			return false;
		}
		if (other == this) {
			return true;
		}
		if (this.getClass() != other.getClass()) {
			return false;
		}
		Account otherObject = ((Account) other);
		return new EqualsBuilder().appendSuper(super.equals(otherObject))
				.append(parentAccountId, otherObject.parentAccountId).append(interestRate, otherObject.interestRate)
				.append(nickname, otherObject.nickname).append(currency, otherObject.currency)
				.append(accountNumber, otherObject.accountNumber).append(interestRateType, otherObject.interestRateType)
				.append(transferOut, otherObject.transferOut).append(transferIn, otherObject.transferIn)
				.append(accDescriptorId, otherObject.accDescriptorId)
				.append(accountMasterId, otherObject.accountMasterId).append(lineOfBusiness, otherObject.lineOfBusiness)
				.isEquals();
	}

	@Override
	public String toString() {
		return "Account [accountMasterId=" + accountMasterId + ", parentAccountId=" + parentAccountId
				+ ", interestRate=" + interestRate + ", nickname=" + nickname + ", currency=" + currency
				+ ", accountNumber=" + accountNumber + ", lineOfBusiness=" + lineOfBusiness + ", accDescriptorId="
				+ accDescriptorId + ", transferIn=" + transferIn + ", transferOut=" + transferOut
				+ ", interestRateType=" + interestRateType + "]";
	}

}
