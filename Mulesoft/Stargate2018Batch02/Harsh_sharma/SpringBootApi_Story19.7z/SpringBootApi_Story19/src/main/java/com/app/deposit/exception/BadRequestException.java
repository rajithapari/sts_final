package com.app.deposit.exception;



public class BadRequestException extends RuntimeException {

	private static final long serialVersionUID = -3332292346834265371L;

	public BadRequestException(){
		super();
	}

	public BadRequestException(final String message) {
		super(message);
	}
}
