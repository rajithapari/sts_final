package com.app.deposit.service;

import java.io.BufferedWriter;
import java.io.FileWriter;

import com.google.gson.Gson;

import bank_web_service.GetBankDetailsResponse;

public class WriteToFile {

	public static void writeToFile(GetBankDetailsResponse response) {
		try {
			FileWriter fstream = new FileWriter("D:\\SoapResponseAsJson.txt");
			BufferedWriter out = new BufferedWriter(fstream);
			Gson gson = new Gson();
			out.write(gson.toJson(response).toString());
			out.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}

}
