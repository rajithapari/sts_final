package com.app.deposit.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import com.app.deposit.model.Error;

import com.app.deposit.exception.AccountNotFoundException;
import com.app.deposit.exception.BadRequestException;
import com.app.deposit.exception.InternalServerException;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

	
	@ExceptionHandler(value=BadRequestException.class)
	@ResponseStatus(value=HttpStatus.BAD_REQUEST)
	public final ResponseEntity<Error> BadRequestException(BadRequestException ex){
		return new ResponseEntity<>(new Error("400",ex.getMessage()),HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(value=AccountNotFoundException.class)
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	public final ResponseEntity<Error> AccountNotFoundException(AccountNotFoundException ex){
		return new ResponseEntity<>(new Error("404",ex.getMessage()),HttpStatus.NOT_FOUND);
	}
	 
	
	@ExceptionHandler(value=InternalServerException.class)
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	public final ResponseEntity<Error> handleInternalException(Exception ex) {
		return new ResponseEntity<>(new Error("500","Internal Error Occured"),HttpStatus.INTERNAL_SERVER_ERROR);
	} 
	
	
}
