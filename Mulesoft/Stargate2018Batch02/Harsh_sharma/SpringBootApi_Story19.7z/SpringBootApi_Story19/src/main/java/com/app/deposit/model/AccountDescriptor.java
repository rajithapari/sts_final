
package com.app.deposit.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "accountdescriptor")
@JsonIgnoreProperties({"accountDescriptorId"})
public class AccountDescriptor implements Serializable {

	final static long serialVersionUID = 1900007743438898631L;
	/**
	 * account id of account.
	 * 
	 */
	@Column
	private String accountId;
	/**
	 * displayname of account.
	 * 	
	 */
	@Column
	private String displayName;
	/**
	 * description of account.
	 * 
	 */
	@Column
	private String description;
	/**
	 * Define type of account.
	 * 
	 */
	@Column
	@Enumerated(EnumType.STRING)
	private AccountType accountType;
	/**
	 * Defines types of account status.
	 * 
	 */
	@Column
	@Enumerated(EnumType.STRING)
	private Status status;

	@Id
	@Column
	@JsonIgnore
	private int accountDescriptorId;

	@Column
    private String customerId;

	public int getAccountDescriptorId() {
		return accountDescriptorId;
	}

	public void setAccountDescriptorId(int accountDescriptorId) {
		this.accountDescriptorId = accountDescriptorId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Creates a new AccountDescriptor.
	 * 
	 */
	public AccountDescriptor() {
		super();
	}

	/**
	 * Creates a new AccountDescriptor.
	 * 
	 */

	public AccountDescriptor(String accountId, String displayName, String description, AccountType accountType,
			Status status, int accountDescriptorId, String customerId) {
		super();
		this.accountId = accountId;
		this.displayName = displayName;
		this.description = description;
		this.accountType = accountType;
		this.status = status;
		this.accountDescriptorId = accountDescriptorId;
		this.customerId = customerId;
	}

	/**
	 * Returns the accountId.
	 * 
	 * @return accountId
	 */
	public String getAccountId() {
		return accountId;
	}

	/**
	 * Set the accountId.
	 * 
	 * @param accountId the new accountId
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	/**
	 * Returns the displayName.
	 * 
	 * @return displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * Set the displayName.
	 * 
	 * @param displayName the new displayName
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * Returns the description.
	 * 
	 * @return description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Set the description.
	 * 
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * Returns the accountType.
	 * 
	 * @return accountType
	 */
	public AccountType getAccountType() {
		return accountType;
	}

	/**
	 * Set the accountType.
	 * 
	 * @param accountType the new accountType
	 */
	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	/**
	 * Returns the status.
	 * 
	 * @return status
	 */
	public Status getStatus() {
		return status;
	}

	/**
	 * Set the status.
	 * 
	 * @param status the new status
	 */
	public void setStatus(Status status) {
		this.status = status;
	}

	public int hashCode() {
		return new HashCodeBuilder().append(accountId).append(displayName).append(description).append(accountType)
				.append(status).append(accountType).append(accountDescriptorId).append(customerId).toHashCode();
	}

	public boolean equals(Object other) {
		if (other == null) {
			return false;
		}
		if (other == this) {
			return true;
		}
		if (this.getClass() != other.getClass()) {
			return false;
		}
		AccountDescriptor otherObject = ((AccountDescriptor) other);
		return new EqualsBuilder().append(accountId, otherObject.accountId).append(displayName, otherObject.displayName)
				.append(description, otherObject.description).append(accountType, otherObject.accountType)
				.append(status, otherObject.status).append(accountDescriptorId, otherObject.accountDescriptorId)
				.append(customerId, otherObject.customerId).isEquals();
	}

	@Override
	public String toString() {
		return "AccountDescriptor [accountId=" + accountId + ", displayName=" + displayName + ", description="
				+ description + ", accountType=" + accountType + ", status=" + status + ", accountDescriptorId="
				+ accountDescriptorId + ", customerId=" + customerId + "]";
	}

}
