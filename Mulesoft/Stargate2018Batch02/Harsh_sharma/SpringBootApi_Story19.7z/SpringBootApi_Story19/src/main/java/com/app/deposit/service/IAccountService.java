package com.app.deposit.service;

import java.util.List;
import com.app.deposit.exception.AccountNotFoundException;
import com.app.deposit.exception.InternalServerException;
import com.app.deposit.model.Accounts;
import com.app.deposit.model.SingleAccountDetailsRequest;

public interface IAccountService {

	public Accounts getallAccountDetails(List<SingleAccountDetailsRequest> singleAccountDetailsRequest) throws AccountNotFoundException, InternalServerException;
}
