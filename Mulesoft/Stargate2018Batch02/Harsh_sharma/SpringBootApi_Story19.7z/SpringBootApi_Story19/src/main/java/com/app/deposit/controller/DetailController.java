
package com.app.deposit.controller;

import com.app.deposit.exception.AccountNotFoundException;
import com.app.deposit.exception.BadRequestException;
import com.app.deposit.model.Accounts;
import com.app.deposit.model.SingleAccountDetailsRequest;
import com.app.deposit.rest.BankCatalogClient;
import com.app.deposit.service.IAccountService;
import com.app.deposit.service.WriteToFile;
import com.google.gson.Gson;

import bank_web_service.GetBankDetailsResponse;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

/**
 * No description (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
@RequestMapping(value = "/api/v1/accounts", produces = "application/json")
@Validated
public class DetailController {

	/**
	 * Get all information for account or set of account
	 * 
	 */
	@Autowired
	Accounts accounts;
	
	@Autowired
	BankCatalogClient bankCatalogClient;
	
	@Autowired
	@Qualifier("accountServiceImpl")
	IAccountService iAccountService;

	 @RequestMapping(value = "/details", method = RequestMethod.POST, consumes = "application/json") 
	  public ResponseEntity<?>createDetails(@RequestHeader(name = "access_token") String accessToken,
	   @RequestHeader(name = "Content-Type") String contentType,@RequestBody List<SingleAccountDetailsRequest> SingleAccountDetailsRequest)
      {
	
		  try {
			 Accounts accounts=iAccountService.getallAccountDetails(SingleAccountDetailsRequest);
			 String CustomerId=accounts.getAccounts().get(0).getCustomerId();
			 GetBankDetailsResponse response = bankCatalogClient.getBankById(CustomerId);
			 WriteToFile.writeToFile(response);
		return new ResponseEntity<>(accounts,HttpStatus.OK);
		 }
		 catch(AccountNotFoundException ex)
		 {
			 return new GlobalExceptionHandler().AccountNotFoundException(ex);
		 }
		 catch(BadRequestException ex)
		 {
			 return new GlobalExceptionHandler().BadRequestException(ex);
		 }
		 catch(Exception ex)
		 {
			 return new GlobalExceptionHandler().handleInternalException(ex);
		 }
		
		}
	 
	
	 
}
