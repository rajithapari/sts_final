package com.app.deposit.model;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Component
@XmlRootElement
@JsonIgnoreProperties({ "endTime", "page" })
public class SingleAccountDetailsRequest {
	
	private String accountId;
	
	private Date startTime;
	
	@JsonIgnore
	private Date endTime;
	@JsonIgnore
	private  double page;
	
	public String getAccountId() {
		return accountId;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public double getPage() {
		return page;
	}
	public void setPage(double page) {
		this.page = page;
	}
	
	
	
	

}
