package com.app.deposit.repository;



import com.app.deposit.model.Account;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;


@SuppressWarnings("hiding")
@NoRepositoryBean
public interface IAccountRepository extends CrudRepository<Account,String> {

	List<Account> GetAccountDetailsById(String accountId);
	
	
	
	


}
