
package com.capgemini.stargate.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.stargate.amqp.SimpleRpcProducerRabbitApplication;
import com.capgemini.stargate.controller.model.Transfer;
import com.capgemini.stargate.exception.BadRequestException;
import com.capgemini.stargate.exception.CustomerIdNotFoundException;
import com.capgemini.stargate.exception.GlobalExceptionHandler;
import com.capgemini.stargate.service.TransferService;

@RestController
@RequestMapping(value = "/api/accounts/transfer", produces = "application/json")
@Validated
@EnableJpaRepositories("com.capgemini.stargate.repository")
@EntityScan("com.capgemini.stargate.controller.model")
public class TransferController 
{
	@Autowired  
    private TransferService transferService;
	@Autowired
	private SimpleRpcProducerRabbitApplication simpleRpcProducerRabbitApplication;
	
    @RequestMapping(value = "", method = RequestMethod.GET)
    
    public ResponseEntity<?> getAllTransfer(@RequestParam String status, @RequestParam String customerId)
    {	
	    	//simpleRpcProducerRabbitApplication.sendMessage();
			simpleRpcProducerRabbitApplication.sendMessage(transferService.getAllTransfer(status, customerId));
	        //return transferService.getAllTransfer(status,customerId);
	        
	        
	        int checkId= transferService.isCustomerIdExists(customerId);
	        
	        String special = "[!@#$%&*()_+=|<>?{}\\[\\]~-]";
	        try
			{
				if ((!(customerId.matches("[0-9]{10}"))) || customerId.matches(special)) 
					throw new BadRequestException("Invalid Customer ID");

				else if(checkId==0)
					throw new CustomerIdNotFoundException("Customer Not Found");

				else if(!(status.equalsIgnoreCase("FAILURE")))
			
					throw new BadRequestException("Please Check Your Status..(Status Should be Failure)");

				
				//else
	 
					/*//calling to database
					transactionDetails=transactionService.fetchList1(accountId, status);
				
					//calling to soap service
					transactionService.soapPrint(transactionDetails.get(0).getCustomerId());
				
					//clling to AMQP
					rmpq.sendMessage(transactionDetails);*/
					
					//return ResponseEntity.ok(transferService.fetchList1(customerId, status));
					 //return transferService.getAllTransfer(status,customerId);
				//return  new ResponseEntity<?>(listTransfer, HttpStatus.OK);
				return null;

			}
			catch (BadRequestException bd) 
			{

				return new GlobalExceptionHandler().handleBadRequest(bd);

			}
    	
    } 
    
    
   
}
