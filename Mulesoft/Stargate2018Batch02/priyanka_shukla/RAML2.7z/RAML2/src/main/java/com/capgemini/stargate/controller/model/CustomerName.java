
package com.capgemini.stargate.controller.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class CustomerName implements Serializable
{

    final static long serialVersionUID = 2705957643727196285L;

    /**
     * Creates a new CustomerName.
     * 
     */
    public CustomerName() {
        super();
    }

    public int hashCode() {
        return new HashCodeBuilder().toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        CustomerName otherObject = ((CustomerName) other);
        return new EqualsBuilder().isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).toString();
    }

}
