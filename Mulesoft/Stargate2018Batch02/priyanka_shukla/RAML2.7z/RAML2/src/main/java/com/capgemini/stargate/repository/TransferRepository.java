package com.capgemini.stargate.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.stargate.controller.model.Transfer;
import com.capgemini.stargate.controller.model.TransferStatus;

@Repository
public interface TransferRepository extends CrudRepository<Transfer, Long> 
{
	
	@Query(value="select t.TransferId, t.FromAccountId, t.ToAccountId, t.Amount, t.Memo, ts.Status,  d.CustomerId"
				+" from transfer t"
				+" inner join accountdescriptor d"
				+" on t.FromAccountId= d.AccountId"
				+" inner join transferstatus ts"
				+" on ts.TransferId = t.TransferId"
				+" where d.CustomerId = :customerId"
				+" and ts.Status= :status" , nativeQuery=true)
	public List<Transfer> getAllTransfer(@Param("status") String status, @Param("customerId") String customerId);
	
	   //Transaction findByCustomerId(String accountId);
	
			@Query(value = "SELECT EXISTS(SELECT * from accountdescriptor d"
					+ " where "
					+ "d.CustomerId=:customerId)", nativeQuery = true)
			int isAccountIdExists(@Param("customerId") String accountId);
	
	
	
	
}