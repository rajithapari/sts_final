
package com.capgemini.stargate.controller.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonProperty;

public enum TransferStatusStatus {

    @JsonProperty("SUCCESS")
    SUCCESS("SUCCESS"),
    @JsonProperty("NOFUNDS")
    NOFUNDS("NOFUNDS"),
    @JsonProperty("PENDING")
    PENDING("PENDING"),
    @JsonProperty("FAILURE")
    FAILURE("FAILURE");
    private final String value;
    private final static Map<String, TransferStatusStatus> VALUE_CACHE = new HashMap<String, TransferStatusStatus>();

    static {
        for (TransferStatusStatus c: values()) {
            VALUE_CACHE.put(c.value, c);
        }
    }

    private TransferStatusStatus(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static TransferStatusStatus fromValue(String value) {
        return VALUE_CACHE.get(value);
    }

    @Override
    public String toString() {
        return this.value;
    }

}
