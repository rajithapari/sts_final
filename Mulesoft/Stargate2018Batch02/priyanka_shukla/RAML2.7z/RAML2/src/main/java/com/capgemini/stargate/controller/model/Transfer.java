
package com.capgemini.stargate.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name= "transfer")
public class Transfer implements Serializable
{

    final static long serialVersionUID = 5500162471941375844L;
    
    @Id
    @Column(name="TransferId")
    private String transferid;
    
    @Column(name="FromAccountId")
    private String fromaccountid;
    
    @Column(name="ToAccountId")
    private String toaccountid;
    
    @Column(name="Amount")
     private Double amount;
    
    
    
    @Column(name="Memo")
    private String memo;
   
    @Enumerated(EnumType.STRING)
    @Column(name="Status")
    private TransferStatusStatus status;

    

	public TransferStatusStatus getStatus() {
		return status;
	}

	public void setStatus(TransferStatusStatus status) {
		this.status = status;
	}

	public Transfer() {
        super();
    }
    
    public Transfer(String transferid, String fromaccountid, String toaccountid, Double amount, String memo) {
        super();
        this.transferid = transferid;
        this.fromaccountid = fromaccountid;
        this.toaccountid = toaccountid;
        this.amount = amount;
        this.memo = memo;
        /*this.accountId = accountId;
        this.customerId = customerId;*/
        this.status = status;
    }

    
    public String gettransferid() {
        return transferid;
    }

    
    public void settransferid(String transferid) {
        this.transferid = transferid;
    }

    
    public String getfromaccountid() {
        return fromaccountid;
    }

   
    public void setfromaccountid(String fromaccountid) {
        this.fromaccountid = fromaccountid;
    }

    
    public String gettoaccountid() {
        return toaccountid;
    }

    
    public void settoaccountId(String toaccountid) {
        this.toaccountid = toaccountid;
    }

   
    public Double getAmount() {
        return amount;
    }

   
    public void setAmount(Double amount) {
        this.amount = amount;
    }

    
    public String getMemo() {
        return memo;
    }

    
    public void setMemo(String memo) {
        this.memo = memo;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((amount == null) ? 0 : amount.hashCode());
		result = prime * result + ((fromaccountid == null) ? 0 : fromaccountid.hashCode());
		result = prime * result + ((memo == null) ? 0 : memo.hashCode());
		result = prime * result + ((toaccountid == null) ? 0 : toaccountid.hashCode());
		result = prime * result + ((transferid == null) ? 0 : transferid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transfer other = (Transfer) obj;
		if (amount == null) {
			if (other.amount != null)
				return false;
		} else if (!amount.equals(other.amount))
			return false;
		if (fromaccountid == null) {
			if (other.fromaccountid != null)
				return false;
		} else if (!fromaccountid.equals(other.fromaccountid))
			return false;
		if (memo == null) {
			if (other.memo != null)
				return false;
		} else if (!memo.equals(other.memo))
			return false;
		if (toaccountid == null) {
			if (other.toaccountid != null)
				return false;
		} else if (!toaccountid.equals(other.toaccountid))
			return false;
		if (transferid == null) {
			if (other.transferid != null)
				return false;
		} else if (!transferid.equals(other.transferid))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Transfer [transferid=" + transferid + ", fromaccountid=" + fromaccountid + ", toaccountid="
				+ toaccountid + ", amount=" + amount + ", memo=" + memo + ", status=" + status + "]";
	}

}
