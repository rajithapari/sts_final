package com.capgemini.stargate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.stargate.amqp.SimpleRpcProducerRabbitApplication;
import com.capgemini.stargate.controller.model.Transfer;
import com.capgemini.stargate.repository.TransferRepository;


@Service
public class TransferServiceImpl implements TransferService 
{
	@Autowired
	private TransferRepository transferRepository;
	
	@Autowired
	private SimpleRpcProducerRabbitApplication simpleRpcProducerRabbitApplication; 
	
	@Override
	public List<Transfer> getAllTransfer(String status, String customerId)
	{
		simpleRpcProducerRabbitApplication.sendMessage(transferRepository.getAllTransfer(status, customerId));
		//simpleRpcProducerRabbitApplication.sendMessage(null);
		
		return transferRepository.getAllTransfer(status, customerId);
	}
	
	

}
