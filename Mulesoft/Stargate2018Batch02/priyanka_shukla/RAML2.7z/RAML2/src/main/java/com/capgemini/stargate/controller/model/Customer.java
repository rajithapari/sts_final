
package com.capgemini.stargate.controller.model;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Customer implements Serializable
{

    final static long serialVersionUID = 2705957643727196285L;
    /**
     * customers identification
     * 
     */
    private String customerId;
    private String name;
    private CustomerName type;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date dateOfBirth;
    private String email;

    /**
     * Creates a new Customer.
     * 
     */
    public Customer() {
        super();
    }

    /**
     * Creates a new Customer.
     * 
     */
    public Customer(String customerId, String name, CustomerName type, Date dateOfBirth, String email) {
        super();
        this.customerId = customerId;
        this.name = name;
        this.type = type;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
    }

    /**
     * Returns the customerId.
     * 
     * @return
     *     customerId
     */
    public String getCustomerId() {
        return customerId;
    }

    /**
     * Set the customerId.
     * 
     * @param customerId
     *     the new customerId
     */
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    /**
     * Returns the name.
     * 
     * @return
     *     name
     */
    public String getName() {
        return name;
    }

    /**
     * Set the name.
     * 
     * @param name
     *     the new name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Returns the type.
     * 
     * @return
     *     type
     */
    public CustomerName getType() {
        return type;
    }

    /**
     * Set the type.
     * 
     * @param type
     *     the new type
     */
    public void setType(CustomerName type) {
        this.type = type;
    }

    /**
     * Returns the dateOfBirth.
     * 
     * @return
     *     dateOfBirth
     */
    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Set the dateOfBirth.
     * 
     * @param dateOfBirth
     *     the new dateOfBirth
     */
    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Returns the email.
     * 
     * @return
     *     email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the email.
     * 
     * @param email
     *     the new email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(customerId).append(name).append(type).append(dateOfBirth).append(email).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Customer otherObject = ((Customer) other);
        return new EqualsBuilder().append(customerId, otherObject.customerId).append(name, otherObject.name).append(type, otherObject.type).append(dateOfBirth, otherObject.dateOfBirth).append(email, otherObject.email).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("customerId", customerId).append("name", name).append("type", type).append("dateOfBirth", dateOfBirth).append("email", email).toString();
    }

}
