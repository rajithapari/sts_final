
package com.capgemini.stargate.controller.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
public class TransferStatus  implements Serializable {

	final static long serialVersionUID = 5508424892319763780L;

	@Id
	@Column(name = "TransferId")
	private String transferid;

	@Enumerated(EnumType.STRING)
	@Column(name="Status")
	private TransferStatusStatus status;

	@Column(name="ReferenceId")
	private String referenceid;

	@Column(name="TransferDate")
	private Date transferdate;

	
	
	public String getTransferid() {
		return transferid;
	}

	public void setTransferid(String transferid) {
		this.transferid = transferid;
	}

	public TransferStatusStatus getStatus() {
		return status;
	}

	public void setStatus(TransferStatusStatus status) {
		this.status = status;
	}

	

	public String getReferenceid() {
		return referenceid;
	}

	public void setReferenceid(String referenceid) {
		this.referenceid = referenceid;
	}

	public Date getTransferdate() {
		return transferdate;
	}

	public void setTransferdate(Date transferdate) {
		this.transferdate = transferdate;
	}

	public TransferStatus() {
		super();
	}

	public int hashCode() {
		return new HashCodeBuilder().appendSuper(super.hashCode()).toHashCode();
	}

	public boolean equals(Object other) {
		if (other == null) {
			return false;
		}
		if (other == this) {
			return true;
		}
		if (this.getClass() != other.getClass()) {
			return false;
		}
		TransferStatus otherObject = ((TransferStatus) other);
		return new EqualsBuilder().appendSuper(super.equals(otherObject)).isEquals();
	}

	public String toString() {
		return new ToStringBuilder(this).appendSuper(super.toString()).toString();
	}

}
