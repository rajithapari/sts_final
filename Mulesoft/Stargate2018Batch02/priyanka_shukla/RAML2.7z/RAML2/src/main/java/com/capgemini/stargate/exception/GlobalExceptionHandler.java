package com.capgemini.stargate.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.capgemini.stargate.controller.model.ErrorDetails;



@ControllerAdvice
@RestController
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler
{
	
	    @ExceptionHandler(value = BadRequestException.class)	    
        public final ResponseEntity<ErrorDetails> handleBadRequest(BadRequestException ex) {
        ErrorDetails exceptionResponse = new ErrorDetails("Invalid CustomerId", "400");
        return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
	    }

	    @ExceptionHandler(value = ResourceNotFound.class)
        public final ResponseEntity<ErrorDetails> handleBadRequest(ResourceNotFound ex) {
        ErrorDetails exceptionResponse = new ErrorDetails("Resource Not Found", "404");
        return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	    }
	    
	    @ExceptionHandler(value = InternalServer.class)
        public final ResponseEntity<ErrorDetails> handleBadRequest(InternalServer ex) {
        ErrorDetails exceptionResponse = new ErrorDetails("Internal server error", "500");
        return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR );
	    }
		
	}
	

