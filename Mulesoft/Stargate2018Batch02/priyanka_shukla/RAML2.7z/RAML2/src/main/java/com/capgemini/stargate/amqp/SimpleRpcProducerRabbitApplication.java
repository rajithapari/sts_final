package com.capgemini.stargate.amqp;


import java.util.List;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.capgemini.stargate.controller.model.Transfer;

@EnableScheduling
@Component
public class SimpleRpcProducerRabbitApplication 
{
	
	private final RabbitTemplate template;

	   
    @Autowired
    public SimpleRpcProducerRabbitApplication(RabbitTemplate template) {
        this.template = template;
    }

    public void sendMessage(List<Transfer> getAllTransfer) {
        //String timestamp = new SimpleDateFormat("HH:mm:ss").format(new Date());	        
        this.template.convertAndSend("spring-boot-stargate", getAllTransfer.toString());
    }
    
   


    @Bean
    public Queue queue() 
    {
        return new Queue("spring-boot-stargate", false);
    }

	
}
