package com.capgemini.stargate.exception;

public class InternalServer  extends RuntimeException
{
	private static final long serialVersionUID = 1L;

	public InternalServer(){
		super();
	}

	public InternalServer(final String message) {
		super(message);
	}

}
