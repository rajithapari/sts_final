package com.capgemini.stargate.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.stargate.controller.model.Transfer;
import com.capgemini.stargate.repository.TransferRepository;


@Service
public class TransferServiceImpl implements TransferService 
{
	@Autowired
	private TransferRepository transferRepository;

	@Override
	public List<Transfer> getAllTransfer(String status, String customerId)
	{
		return transferRepository.getAllTransfer(status, customerId);
	}
	
	

}
