package com.capgemini.stargate.service;

import java.util.List;

import com.capgemini.stargate.controller.model.Transfer;

public interface TransferService {

	List<Transfer> getAllTransfer(String status, String customerId);

}
