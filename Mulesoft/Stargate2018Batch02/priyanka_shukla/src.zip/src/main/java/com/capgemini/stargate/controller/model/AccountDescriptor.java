
package com.capgemini.stargate.controller.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class AccountDescriptor implements Serializable
{

    final static long serialVersionUID = 2200200282358375645L;
    /**
     * account identification
     * 
     */
    private String accountId;
    /**
     * account identity to display customer
     * 
     */
    private String displayName;
    /**
     * gives account current status
     * 
     */
    private Accountstatus status;

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor() {
        super();
    }

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor(String accountId, String displayName, Accountstatus status) {
        super();
        this.accountId = accountId;
        this.displayName = displayName;
        this.status = status;
    }

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Set the displayName.
     * 
     * @param displayName
     *     the new displayName
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    public Accountstatus getStatus() {
        return status;
    }

    /**
     * Set the status.
     * 
     * @param status
     *     the new status
     */
    public void setStatus(Accountstatus status) {
        this.status = status;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(accountId).append(displayName).append(status).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        AccountDescriptor otherObject = ((AccountDescriptor) other);
        return new EqualsBuilder().append(accountId, otherObject.accountId).append(displayName, otherObject.displayName).append(status, otherObject.status).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accountId", accountId).append("displayName", displayName).append("status", status).toString();
    }

}
