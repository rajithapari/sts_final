package com.capgemini.stargate.repository;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.stargate.controller.model.Transfer;

@Repository
public interface TransferRepository extends CrudRepository<Transfer, Long> 
{
	
	@Query(value="select d.AccountId, d.CustomerId, t.TransferId, t.FromAccountId, t.ToAccountId, t.Amount, t.Memo, t.TransferId, ts.TransferId, ts.Status"
				+" from transfer t"
				+" inner join accountdescriptor d"
				+" join transferstatus ts"
				+" on t.Transferid= d.AccountId"
				+" and ts.Transferid = t.Transferid"
				+" where d.CustomerId = :customerId"
				+" and ts.Status= :status" , nativeQuery=true)
	public List<Transfer> getAllTransfer(@Param("status") String status, @Param("customerId") String customerId);
	
	
	
	
}