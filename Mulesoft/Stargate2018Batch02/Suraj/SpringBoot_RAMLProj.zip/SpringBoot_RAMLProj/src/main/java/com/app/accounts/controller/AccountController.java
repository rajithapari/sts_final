
package com.app.accounts.controller;

import com.app.accounts.model.AccountDescriptor;
import com.app.accounts.model.AccountDescriptorList;
import com.app.accounts.repository.AccountRepository;
import com.app.accounts.service.AccountsService;


import java.util.List;
import java.util.Optional;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


/**
 * No description
 * (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
@RequestMapping(value = "/api/v1", produces = "application/json")
@Validated
public class AccountController {
	@Autowired
	private AccountsService accountService;

//    @Autowired
//    private AccountRepository accountRepo;
    /**
     * Get a lightweight list of accounts
     * 
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public AccountDescriptorList getAccountDescriptorList() {
        return null; 
    }
    
      
    @RequestMapping(value = "/accounts")
    public ResponseEntity<List<AccountDescriptorList>> getAccountDetails(){
    	System.out.println("Inside controller");
    	
    	List<AccountDescriptorList> list = accountService.getAccounts();
    	return new ResponseEntity<>(list, HttpStatus.OK);
    	
    }
    	    	 
    	    } 
    	 



