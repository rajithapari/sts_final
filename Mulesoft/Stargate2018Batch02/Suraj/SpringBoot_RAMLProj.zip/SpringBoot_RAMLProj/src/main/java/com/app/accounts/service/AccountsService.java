package com.app.accounts.service;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.app.accounts.model.AccountDescriptor;
import com.app.accounts.model.AccountDescriptorList;
import com.app.accounts.repository.AccountRepository;

@Service
public class AccountsService   {
	@PersistenceContext
	EntityManager entityManager;
	
	
	public List<AccountDescriptorList>  getAccounts(){
	
	StringBuffer stringBuffer = new StringBuffer();  
	stringBuffer.append(" select * from accountdescriptor ");
	Query query1 = entityManager.createNativeQuery(stringBuffer.toString(), AccountDescriptor.class);
	
		List<AccountDescriptorList> accountDescriptor = query1.getResultList();
		return accountDescriptor;
	}

}
