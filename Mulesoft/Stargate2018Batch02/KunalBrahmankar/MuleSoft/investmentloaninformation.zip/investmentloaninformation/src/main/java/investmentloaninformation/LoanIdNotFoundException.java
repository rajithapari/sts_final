package investmentloaninformation;

public class LoanIdNotFoundException extends Exception {

	public LoanIdNotFoundException()
	{
		
	}
	

}
