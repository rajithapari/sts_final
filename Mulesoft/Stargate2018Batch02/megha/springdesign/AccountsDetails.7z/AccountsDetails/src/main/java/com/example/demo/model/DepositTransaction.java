
package com.example.demo.model;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class DepositTransaction
    extends Transaction
    implements Serializable
{

    final static long serialVersionUID = 8105802149458753967L;
    private TransactionType transactionType;
    private String payee;
    private Long checkNumber;

    /**
     * Creates a new DepositTransaction.
     * 
     */
    public DepositTransaction() {
        super();
    }

    /**
     * Creates a new DepositTransaction.
     * 
     */
    public DepositTransaction(String accountId, AccountType accountType, String displayName, Status status, String transactionId, String referenceTransactionId, Date transactionTimestamp, Double amount, TransactionType transactionType, String payee, Long checkNumber) {
        super(accountId, accountType, displayName, status, transactionId, referenceTransactionId, transactionTimestamp, amount);
        this.transactionType = transactionType;
        this.payee = payee;
        this.checkNumber = checkNumber;
    }

    /**
     * Returns the transactionType.
     * 
     * @return
     *     transactionType
     */
    public TransactionType getTransactionType() {
        return transactionType;
    }

    /**
     * Set the transactionType.
     * 
     * @param transactionType
     *     the new transactionType
     */
    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    /**
     * Returns the payee.
     * 
     * @return
     *     payee
     */
    public String getPayee() {
        return payee;
    }

    /**
     * Set the payee.
     * 
     * @param payee
     *     the new payee
     */
    public void setPayee(String payee) {
        this.payee = payee;
    }

    /**
     * Returns the checkNumber.
     * 
     * @return
     *     checkNumber
     */
    public Long getCheckNumber() {
        return checkNumber;
    }

    /**
     * Set the checkNumber.
     * 
     * @param checkNumber
     *     the new checkNumber
     */
    public void setCheckNumber(Long checkNumber) {
        this.checkNumber = checkNumber;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(transactionType).append(payee).append(checkNumber).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        DepositTransaction otherObject = ((DepositTransaction) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(transactionType, otherObject.transactionType).append(payee, otherObject.payee).append(checkNumber, otherObject.checkNumber).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("transactionType", transactionType).append("payee", payee).append("checkNumber", checkNumber).toString();
    }

}
