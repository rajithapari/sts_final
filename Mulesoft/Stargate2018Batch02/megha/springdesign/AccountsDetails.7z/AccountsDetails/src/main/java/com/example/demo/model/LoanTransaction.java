
package com.example.demo.model;

import java.io.Serializable;
import java.util.Date;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class LoanTransaction
    extends Transaction
    implements Serializable
{

    final static long serialVersionUID = -645101703784628728L;
    private TransactionType transactionType;

    /**
     * Creates a new LoanTransaction.
     * 
     */
    public LoanTransaction() {
        super();
    }

    /**
     * Creates a new LoanTransaction.
     * 
     */
    public LoanTransaction(String accountId, AccountType accountType, String displayName, Status status, String transactionId, String referenceTransactionId, Date transactionTimestamp, Double amount, TransactionType transactionType) {
        super(accountId, accountType, displayName, status, transactionId, referenceTransactionId, transactionTimestamp, amount);
        this.transactionType = transactionType;
    }

    /**
     * Returns the transactionType.
     * 
     * @return
     *     transactionType
     */
    public TransactionType getTransactionType() {
        return transactionType;
    }

    /**
     * Set the transactionType.
     * 
     * @param transactionType
     *     the new transactionType
     */
    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(transactionType).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        LoanTransaction otherObject = ((LoanTransaction) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(transactionType, otherObject.transactionType).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("transactionType", transactionType).toString();
    }

}
