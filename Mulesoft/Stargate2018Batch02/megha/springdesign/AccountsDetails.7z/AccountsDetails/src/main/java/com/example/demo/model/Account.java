
package com.example.demo.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class Account
    extends AccountDescriptor
    implements Serializable
{

    final static long serialVersionUID = -1083575910313347476L;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).toString();
    }

}
