
package com.example.demo.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class typeunion implements Serializable
{

    final static long serialVersionUID = -8778761483864357438L;
    private Accounts accounts;
    private AccountDescriptor accountDescriptor;
    private AccountDescriptor transaction;

    /**
     * Creates a new typeunion.
     * 
     */
    public typeunion() {
        super();
    }

    /**
     * Creates a new typeunion.
     * 
     */
    public typeunion(Accounts accounts, AccountDescriptor accountDescriptor, AccountDescriptor transaction) {
        super();
        this.accounts = accounts;
        this.accountDescriptor = accountDescriptor;
        this.transaction = transaction;
    }

    /**
     * Returns the accounts.
     * 
     * @return
     *     accounts
     */
    public Accounts getAccounts() {
        return accounts;
    }

    /**
     * Set the accounts.
     * 
     * @param accounts
     *     the new accounts
     */
    public void setAccounts(Accounts accounts) {
        this.accounts = accounts;
    }

    /**
     * Returns the accountDescriptor.
     * 
     * @return
     *     accountDescriptor
     */
    public AccountDescriptor getAccountDescriptor() {
        return accountDescriptor;
    }

    /**
     * Set the accountDescriptor.
     * 
     * @param accountDescriptor
     *     the new accountDescriptor
     */
    public void setAccountDescriptor(AccountDescriptor accountDescriptor) {
        this.accountDescriptor = accountDescriptor;
    }

    /**
     * Returns the transaction.
     * 
     * @return
     *     transaction
     */
    public AccountDescriptor getTransaction() {
        return transaction;
    }

    /**
     * Set the transaction.
     * 
     * @param transaction
     *     the new transaction
     */
    public void setTransaction(AccountDescriptor transaction) {
        this.transaction = transaction;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(accounts).append(accountDescriptor).append(transaction).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        typeunion otherObject = ((typeunion) other);
        return new EqualsBuilder().append(accounts, otherObject.accounts).append(accountDescriptor, otherObject.accountDescriptor).append(transaction, otherObject.transaction).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accounts", accounts).append("accountDescriptor", accountDescriptor).append("transaction", transaction).toString();
    }

}
