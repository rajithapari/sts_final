
package com.example.demo.model;

import java.io.Serializable;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class AccountDescriptor implements Serializable
{

    final static long serialVersionUID = -1017476555876178579L;
    private String accountId;
    private Double AccountDescriptorId;
    private AccountType accountType;
    private String displayName;
    private Status status;
    private String parentAccountId;
    private String nickname;
    private String accountNumber;
    private Double interestRate;
    private String currency;

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor() {
        super();
    }

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor(String accountId, Double AccountDescriptorId, AccountType accountType, String displayName, Status status, String parentAccountId, String nickname, String accountNumber, Double interestRate, String currency) {
        super();
        this.accountId = accountId;
        this.AccountDescriptorId = AccountDescriptorId;
        this.accountType = accountType;
        this.displayName = displayName;
        this.status = status;
        this.parentAccountId = parentAccountId;
        this.nickname = nickname;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.currency = currency;
    }

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the AccountDescriptorId.
     * 
     * @return
     *     AccountDescriptorId
     */
    public Double getAccountDescriptorId() {
        return AccountDescriptorId;
    }

    /**
     * Set the AccountDescriptorId.
     * 
     * @param AccountDescriptorId
     *     the new AccountDescriptorId
     */
    public void setAccountDescriptorId(Double AccountDescriptorId) {
        this.AccountDescriptorId = AccountDescriptorId;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * Set the accountType.
     * 
     * @param accountType
     *     the new accountType
     */
    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Set the displayName.
     * 
     * @param displayName
     *     the new displayName
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Set the status.
     * 
     * @param status
     *     the new status
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * Returns the parentAccountId.
     * 
     * @return
     *     parentAccountId
     */
    public String getParentAccountId() {
        return parentAccountId;
    }

    /**
     * Set the parentAccountId.
     * 
     * @param parentAccountId
     *     the new parentAccountId
     */
    public void setParentAccountId(String parentAccountId) {
        this.parentAccountId = parentAccountId;
    }

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * Set the nickname.
     * 
     * @param nickname
     *     the new nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     */
    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    /**
     * Returns the currency.
     * 
     * @return
     *     currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Set the currency.
     * 
     * @param currency
     *     the new currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(accountId).append(AccountDescriptorId).append(accountType).append(displayName).append(status).append(parentAccountId).append(nickname).append(accountNumber).append(interestRate).append(currency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        AccountDescriptor otherObject = ((AccountDescriptor) other);
        return new EqualsBuilder().append(accountId, otherObject.accountId).append(AccountDescriptorId, otherObject.AccountDescriptorId).append(accountType, otherObject.accountType).append(displayName, otherObject.displayName).append(status, otherObject.status).append(parentAccountId, otherObject.parentAccountId).append(nickname, otherObject.nickname).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).append(currency, otherObject.currency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accountId", accountId).append("AccountDescriptorId", AccountDescriptorId).append("accountType", accountType).append("displayName", displayName).append("status", status).append("parentAccountId", parentAccountId).append("nickname", nickname).append("accountNumber", accountNumber).append("interestRate", interestRate).append("currency", currency).toString();
    }

}
