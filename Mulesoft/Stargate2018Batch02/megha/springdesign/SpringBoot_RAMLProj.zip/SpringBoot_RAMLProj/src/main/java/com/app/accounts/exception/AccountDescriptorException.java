package com.app.accounts.exception;

public class AccountDescriptorException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3050483774717218064L;

	public AccountDescriptorException(String message) {
        super(message);
    }

   

}
