package com.example.demo.exceptionhandler;

import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

public class CustomizedExceptionHandler  {

	
}
