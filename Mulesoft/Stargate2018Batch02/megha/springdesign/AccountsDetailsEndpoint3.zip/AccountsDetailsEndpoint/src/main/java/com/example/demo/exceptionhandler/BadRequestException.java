/*package com.example.demo.exceptionhandler;

public class BadRequestException {

}
*/