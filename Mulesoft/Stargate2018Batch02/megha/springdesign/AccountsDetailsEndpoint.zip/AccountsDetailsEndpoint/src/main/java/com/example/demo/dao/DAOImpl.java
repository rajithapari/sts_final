package com.example.demo.dao;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Account;
import com.example.demo.model.Transaction;

public class DAOImpl implements AccountRepository {

	@SuppressWarnings("unused")
	@Autowired
	private AccountRepository accountRepository;

	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(Account arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll(Iterable<? extends Account> arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteById(String arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean existsById(String arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<Account> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Account> findAllById(Iterable<String> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Account> findById(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Account> S save(S arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Account> Iterable<S> saveAll(Iterable<S> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unchecked")
	//@Override
	public List<Transaction> getAccounts(String customerId, Date startDate, Date endDate) {
		// TODO Auto-generated method stub

		// transactionLogger.info("Starts the getAccountByCustomerID method of :
		// "+ this.getClass().getName());

		System.out.println("Inside controller");

		// transactionLogger.info("Starts the getAccounts method of : "+
		// this.getClass().getName());

		Query query = entitymanager.createNativeQuery ("SELECT *  from  Account acc,accountdescriptor asd where acc.AccDescriptorId = asd.AccountDescriptorId and asd.CustomerId='111111101'"

				,Transaction.class);
				
		

		// System.out.println(" Result ::: " + query.getResultList());

		// transactionLogger.info("Ends the getAccounts method of : "+
		// this.getClass().getName());

		return query.getResultList();

		
	}

	@Override
	public List<Account> getAccounts(Integer customerId) {
		// TODO Auto-generated method stub
		return null;
	}

}
