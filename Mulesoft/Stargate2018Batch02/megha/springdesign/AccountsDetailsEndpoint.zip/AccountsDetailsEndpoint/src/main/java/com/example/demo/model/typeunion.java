
package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;


public class typeunion implements Serializable
{

    final static long serialVersionUID = -8778761483864357438L;
    
    private Account account;
    private AccountDescriptor accountDescriptor;
    private Transaction transaction;

    /**
     * Creates a new typeunion.
     * 
     */
    public typeunion() {
        super();
    }

    /**
     * Creates a new typeunion.
     * 
     */
    public typeunion(Account account, AccountDescriptor accountDescriptor, Transaction transaction) {
        super();
        this.account = account;
        this.accountDescriptor = accountDescriptor;
        this.transaction = transaction;
    }

    /**
     * Returns the accounts.
     * 
     * @return
     *     accounts
     */
   // @Id
   // @Column(name="Account")
    public Account getAccount() {
        return account;
    }

    /**
     * Set the accounts.
     * 
     * @param accounts
     *     the new accounts
     */
    public void setAccounts(Account account) {
        this.account = account;
    }

    /**
     * Returns the accountDescriptor.
     * 
     * @return
     *     accountDescriptor
     */
    //@Column(name="AccountDescriptor")
    public AccountDescriptor getAccountDescriptor() {
        return accountDescriptor;
    }

    /**
     * Set the accountDescriptor.
     * 
     * @param accountDescriptor
     *     the new accountDescriptor
     */
    public void setAccountDescriptor(AccountDescriptor accountDescriptor) {
        this.accountDescriptor = accountDescriptor;
    }

    /**
     * Returns the transaction.
     * 
     * @return
     *     transaction
     */
 
  

    /**
     * Set the transaction.
     * 
     * @param transaction
     *     the new transaction
     */
  

    public int hashCode() {
        return new HashCodeBuilder().append(account).append(accountDescriptor).append(transaction).toHashCode();
    }
  //  @Column(name="Transaction")
    public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}

	public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        typeunion otherObject = ((typeunion) other);
        return new EqualsBuilder().append(account, otherObject.account).append(accountDescriptor, otherObject.accountDescriptor).append(transaction, otherObject.transaction).isEquals();
    }

	@Override
	public String toString() {
		return "typeunion [account=" + account + ", accountDescriptor=" + accountDescriptor + ", transaction="
				+ transaction + "]";
	}

  
}
