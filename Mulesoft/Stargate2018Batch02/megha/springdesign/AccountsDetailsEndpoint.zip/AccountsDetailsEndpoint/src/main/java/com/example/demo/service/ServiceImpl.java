package com.example.demo.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.example.demo.dao.AccountRepository;
import com.example.demo.model.Account;

@Service
@Component
public class ServiceImpl implements ServiceInterface
{
	



		@Autowired
		private AccountRepository accountRepository;

		@Override
		public List<Account> getAccountsCustom(String customerId, Date startDate, Date endDate) {
			
			if(null!=accountRepository)
				
				//return accountRepository.getAccounts(customerId, startDate, endDate);
			return accountRepository.getAccounts(Integer.valueOf(customerId));
			
			
			return null;
			
			
		}

		
		/*@Override
		public List<Account> getAccounts(String customerId, Date startDate, Date endDate) {
			
			//transactionLogger.info("Starts the getAccountByCustomerID method of : "+ this.getClass().getName());
	    	
	    	System.out.println("Inside controller");
	    	
	    	List<Account> listOfAccount=accountRepository.getAccounts(customerId, startDate, endDate);
	    	//List<typeunion> typeunion =accountRepository.getAccounts(customerId, startDate, endDate);
	    	
	    	//transactionLogger.info("Ends the getAccountByCustomerID method of : "+ this.getClass().getName());
	    	System.out.println(listOfAccount);
	    	
	    	//return typeunion;
	    	return listOfAccount;		
	    	}*/
		
}

		
	
		
		

		
		
		




