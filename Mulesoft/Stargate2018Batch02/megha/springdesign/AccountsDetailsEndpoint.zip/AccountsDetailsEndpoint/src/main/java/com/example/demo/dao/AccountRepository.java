package com.example.demo.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Account;
import com.example.demo.model.Transaction;


//public interface AccountRepository extends CrudRepository<typeunion, String> {

@Repository
public interface AccountRepository extends CrudRepository<Account, String> {

	/*//@Query(value = "SELECT *  from  Account acc,accountdescriptor asd where acc.AccDescriptorId = asd.AccountDescriptorId and accountdescriptor = :accountdescriptor and ", nativeQuery = true)
	@Query(value ="SELECT *  from  Account acc,accountdescriptor asd where acc.AccDescriptorId = asd.AccountDescriptorId and asd.CustomerId= :customertId")
	public List<Account> getAccounts(@Param("customertId") String customerId, @Param("startDate") Date startDate, @Param("endDate") Date endDate);
	*/
	//@Query(value ="SELECT *  from  Account acc,accountdescriptor asd where acc.AccDescriptorId = asd.AccountDescriptorId and asd.CustomerId= :customertId")
	
	/*@Query(value = "SELECT * " + " from Account acc, accountdescriptor asd, transaction tra"
			+ " where acc.AccDescriptorId=asd.AccountDescriptorId and "
			+ "asd.CustomerId= :customertId and "
			+ "tra.TransactionTimestamp between :startDate AND :endDate", nativeQuery = true)*/
	/*@Query(value="select tra.*, acc.*, adc.AccountId account_id" +
			  " from transaction tra, account acc, accountdescriptor adc " +
			  "where acc.AccDescriptorId = adc.AccountDescriptorId and "
			  + " tra.AccountId = adc.AccountId and "
			  + "adc.CustomerId = :customerId and tra.TransactionTimestamp between :startDate AND :endDate"
			  ,nativeQuery=true) 
	
	public List<Transaction> getAccounts(@Param("customerId") String customerId, @Param("startDate") Date startDate, @Param("endDate") Date endDate);
	*/
	
	/*@Query(value = "SELECT * " + " from Account acc, accountdescriptor asd"
			+ " where acc.AccDescriptorId=asd.AccountDescriptorId and "
			+ "asd.CustomerId= :customertId ", nativeQuery = true)*/
	@Query(value =" SELECT * "
			+ "from  account acc,accountdescriptor asd "
					+ "where acc.AccDescriptorId = asd.AccountDescriptorId "
			+"and asd.CustomerId= :customerId",nativeQuery = true)
	public List<Account> getAccounts(@Param("customerId") Integer customerId);
	
	
}
