package com.example.demo.service;

import java.util.Date;
import java.util.List;

import com.example.demo.model.Account;

public interface ServiceInterface {
	
	public List<Account> getAccountsCustom(String customerId, Date startDate, Date endDate);

}
