package com.example.demo.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.springframework.data.repository.CrudRepository;


import com.example.demo.model.Account;

public interface AccountRepository extends CrudRepository<Account, String> {
	public List<Account> getAccounts(String customertId, Date startDate, Date endDate);
	
	
	

}
