package com.example.demo.model;





import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Table;

//@Entity
//@Table(name="depositaccount")
public class DepositAccount 
    extends Account
    implements Serializable
{

    final static long serialVersionUID = -1855989374714820950L;
    
   /* @Column(name="RefAccountId")
    protected Integer refAccountId;*/
    
    
    /**
     * Balance of funds in account
     * 
     */
    private Double currentBalance;
    private Double availableBalance;
	public DepositAccount(Double currentBalance, Double availableBalance) {
		super();
		this.currentBalance = currentBalance;
		this.availableBalance = availableBalance;
	}
	public DepositAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DepositAccount(String parentAccountId, String nickname, String accountNumber, Double interestRate,
			String currency) {
		super(parentAccountId, nickname, accountNumber, interestRate, currency);
		// TODO Auto-generated constructor stub
	}
	public Double getCurrentBalance() {
		return currentBalance;
	}
	public void setCurrentBalance(Double currentBalance) {
		this.currentBalance = currentBalance;
	}
	public Double getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(Double availableBalance) {
		this.availableBalance = availableBalance;
	}
	@Override
	public String toString() {
		return "DepositAccount [currentBalance=" + currentBalance + ", availableBalance=" + availableBalance + "]";
	}
   
   
     
   
    }

  

   
  


    
   
  

 

   



