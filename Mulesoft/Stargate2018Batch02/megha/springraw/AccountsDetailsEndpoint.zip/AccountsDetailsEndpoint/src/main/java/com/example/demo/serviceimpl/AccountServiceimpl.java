package com.example.demo.serviceimpl;


import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.dao.AccountRepository;
import com.example.demo.model.Account;
import com.example.demo.model.Transaction;

@SuppressWarnings("rawtypes")
@Repository
@Transactional
public class AccountServiceimpl implements AccountRepository {
	
	@PersistenceContext
    EntityManager entityManager;

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void delete(Account arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable<? extends Account> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteById(String arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean existsById(String arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable<Account> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Account> findAllById(Iterable<String> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Account> findById(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Account> S save(S arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <S extends Account> Iterable<S> saveAll(Iterable<S> arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Account> getAccounts(String customertId, Date startDate, Date endDate)
	{
		/*Query query = entityManager.createNativeQuery("SELECT * "
				+ "FROM transaction  , accountdescriptor "
				+ "WHERE  transaction.AccountId = accountdescriptor.AccountId "
				+ "AND accountdescriptor.CustomerId='111111101',AND transaction.TransactionTimestamp BETWEEN '2018-07-12' AND '2018-08-18'", Account.class);
		*/
		Query query = entityManager.createNativeQuery("SELECT * FROM account  , accountdescriptor WHERE  accountdescriptor.CustomerId='111111101'",Account.class);
		System.out.println(" Result ::: " + query.getResultList());	
		return query.getResultList();
		
		/*select * from transaction t,accountdescriptor a where t.AccountId=a.AccountId and a.CustomerId="111111101"; */

}
}
