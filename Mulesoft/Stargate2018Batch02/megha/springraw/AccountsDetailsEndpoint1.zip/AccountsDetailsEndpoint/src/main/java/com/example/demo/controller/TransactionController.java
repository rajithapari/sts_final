
package com.example.demo.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.AccountRepository;
import com.example.demo.model.Account;


/**
 * No description
 * (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
@RequestMapping(value = "/api/v1/accounts/transactions", produces = "application/json")
@Validated
public class TransactionController {
	
	@Autowired
	private AccountRepository accountrepo;
	

    /**
     * get all account details for specific customerid
     * 
     */
	
    @SuppressWarnings({ "unchecked", "unchecked", "unchecked" })
	@RequestMapping(value = "", method = RequestMethod.GET)
    public List<Account> getAccountBy(
        @RequestParam
        String customerId,
        @RequestParam
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        Date startDate,
        @RequestParam
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        Date endDate) {
       //
    	System.out.println("Inside controller");
    	List<Account> acc=accountrepo.getAccounts(customerId, startDate, endDate);
    	return acc;
    	//return (List<Account>) accountrepo.findAll();
	
	/*@RequestMapping(value = "", method = RequestMethod.GET)
	public  List<Account> getAll(){
		System.out.println("Inside controller");
		return (List<Account>) accountrepo.findAll();
	}*/
}
}
    
