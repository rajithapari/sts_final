
package com.example.demo.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
/*@Entity
@Table(name="loantransaction")*/
public class LoanTransaction
    extends Transaction
    implements Serializable
{

    final static long serialVersionUID = -645101703784628728L;
    @Column(name="TransactionType")
    private TransactionType transactionType;
  

    /**
     * Creates a new LoanTransaction.
     * 
     */
    public LoanTransaction() {
        super();
    }

    /**
     * Creates a new LoanTransaction.
     * 
     */
    

    /**
     * Returns the transactionType.
     * 
     * @return
     *     transactionType
     */
    
    
    public TransactionType getTransactionType() {
        return transactionType;
    }

    public LoanTransaction(TransactionType transactionType) {
		super();
		this.transactionType = transactionType;
	}

	

	/**
     * Set the transactionType.
     * 
     * @param transactionType
     *     the new transactionType
     */
    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(transactionType).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        LoanTransaction otherObject = ((LoanTransaction) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(transactionType, otherObject.transactionType).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("transactionType", transactionType).toString();
    }
    /*@Id
    @Column(name="transactionId")
	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(TransactionType transactionId) {
		this.transactionId = transactionId;
	}
*/
}
