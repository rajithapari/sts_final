
package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;
@Entity
@Table(name="AccountDescriptor")
public class AccountDescriptor implements Serializable
{
   
    final static long serialVersionUID = -1017476555876178579L;
    @Column(name="AccountId")
    private String accountId;
    @Id
    @Column(name="AccountDescriptorId")
    private Integer AccountDescriptorId;
    
    @Column(name="AccountType")
    private AccountType accountType;
    
    @Column(name="DisplayName")
    private String displayName;
    
    @Column(name="Status")
    private Status status;
    
    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor() {
        super();
    }

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    
   
    public String getAccountId() {
        return accountId;
    }

    public AccountDescriptor(String accountId, Integer accountDescriptorId, AccountType accountType, String displayName,
			Status status) {
		super();
		this.accountId = accountId;
		AccountDescriptorId = accountDescriptorId;
		this.accountType = accountType;
		this.displayName = displayName;
		this.status = status;
	}

	/**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the AccountDescriptorId.
     * 
     * @return
     *     AccountDescriptorId
     */
    
    
    public Integer getAccountDescriptorId() {
        return AccountDescriptorId;
    }

    /**
     * Set the AccountDescriptorId.
     * 
     * @param AccountDescriptorId
     *     the new AccountDescriptorId
     */
    public void setAccountDescriptorId(Integer AccountDescriptorId) {
        this.AccountDescriptorId = AccountDescriptorId;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * Set the accountType.
     * 
     * @param accountType
     *     the new accountType
     */
    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
   
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Set the displayName.
     * 
     * @param displayName
     *     the new displayName
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
   
    public Status getStatus() {
        return status;
    }

    /**
     * Set the status.
     * 
     * @param status
     *     the new status
     */
    public void setStatus(Status status) {
        this.status = status;
    }

    /**
     * Returns the parentAccountId.
     * 
     * @return
     *     parentAccountId
     */
   

   

	@Override
	public String toString() {
		return "AccountDescriptor [accountId=" + accountId + ", AccountDescriptorId=" + AccountDescriptorId
				+ ", accountType=" + accountType + ", displayName=" + displayName + ", status=" + status + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((AccountDescriptorId == null) ? 0 : AccountDescriptorId.hashCode());
		result = prime * result + ((accountId == null) ? 0 : accountId.hashCode());
		result = prime * result + ((accountType == null) ? 0 : accountType.hashCode());
		result = prime * result + ((displayName == null) ? 0 : displayName.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountDescriptor other = (AccountDescriptor) obj;
		if (AccountDescriptorId == null) {
			if (other.AccountDescriptorId != null)
				return false;
		} else if (!AccountDescriptorId.equals(other.AccountDescriptorId))
			return false;
		if (accountId == null) {
			if (other.accountId != null)
				return false;
		} else if (!accountId.equals(other.accountId))
			return false;
		if (accountType != other.accountType)
			return false;
		if (displayName == null) {
			if (other.displayName != null)
				return false;
		} else if (!displayName.equals(other.displayName))
			return false;
		if (status != other.status)
			return false;
		return true;
	}

    
}
