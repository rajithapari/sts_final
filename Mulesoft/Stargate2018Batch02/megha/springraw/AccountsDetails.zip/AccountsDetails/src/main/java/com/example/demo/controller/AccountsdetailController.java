
package com.example.demo.controller;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.websocket.server.PathParam;

import com.example.demo.dao.AccountRepository;
import com.example.demo.model.AccountDescriptor;
import com.example.demo.model.typeunion;
import com.example.demo.service.AccountDetailsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


/**
 * No description
 * (Generated with springmvc-raml-parser v.2.0.0)
 * 
 */
@RestController
@RequestMapping(value = "/api/v1/accountsdetails", produces = "application/json")
@Validated
public class AccountsdetailController {
	/*
	@Autowired
	 private AccountRepository accrepo;*/
	@Autowired
	private AccountDetailsService acs;


    
	
		
	
	
  /* @RequestMapping(value = "", method = RequestMethod.GET)
    public  ResponseEntity<typeunion> getTypeunionBy(
    	
        @RequestParam
        String customerId,
        @RequestParam
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        Date startDate,
        @RequestParam
        @DateTimeFormat(pattern = "yyyy-MM-dd")
        Date endDate) {
       
        
        System.out.println("accounts");
       
        return new  ResponseEntity<>(new typeunion(),HttpStatus.OK);
   } */
    @RequestMapping(value = "/accounts")
    public ResponseEntity<List<AccountDescriptor>> getAccountDetails(){
    	System.out.println("Inside controller");
    	
    	List<AccountDescriptor> list = acs.getAccounts();
    	return new ResponseEntity<>(list, HttpStatus.OK);
    	
    } 
}


/*@GetMapping(value="/accounts/transactions/{customerId}")
public ResponseEntity<typeunion>  getLoanPaymentDetails( @PathVariable("customerId") String accountId){
	System.out.println("in controller accountId"+accountId);
	return new ResponseEntity<typeunion>( paymentDetailsService.getPaymentDetails(accountId),HttpStatus.OK);
    */
 

 

