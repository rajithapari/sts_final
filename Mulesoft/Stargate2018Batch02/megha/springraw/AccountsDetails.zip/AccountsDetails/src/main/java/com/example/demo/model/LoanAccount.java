package com.example.demo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/*@Entity
@Table(name="loanaccount")*/
public class LoanAccount  extends Account implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Column(name="LoanAccountId")
	private String LoanAccountId;
	@Column(name="BalanceAsOf")
	private String BalanceAsOf;
	public LoanAccount(String loanAccountId, String balanceAsOf) {
		super();
		LoanAccountId = loanAccountId;
		BalanceAsOf = balanceAsOf;
	}
	public LoanAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String getLoanAccountId() {
		return LoanAccountId;
	}
	public void setLoanAccountId(String loanAccountId) {
		LoanAccountId = loanAccountId;
	}
	
	public String getBalanceAsOf() {
		return BalanceAsOf;
	}
	public void setBalanceAsOf(String balanceAsOf) {
		BalanceAsOf = balanceAsOf;
	}
	@Override
	public String toString() {
		return "LoanAccount [LoanAccountId=" + LoanAccountId + ", BalanceAsOf=" + BalanceAsOf + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((BalanceAsOf == null) ? 0 : BalanceAsOf.hashCode());
		result = prime * result + ((LoanAccountId == null) ? 0 : LoanAccountId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoanAccount other = (LoanAccount) obj;
		if (BalanceAsOf == null) {
			if (other.BalanceAsOf != null)
				return false;
		} else if (!BalanceAsOf.equals(other.BalanceAsOf))
			return false;
		if (LoanAccountId == null) {
			if (other.LoanAccountId != null)
				return false;
		} else if (!LoanAccountId.equals(other.LoanAccountId))
			return false;
		return true;
	}
	
	
	
}
