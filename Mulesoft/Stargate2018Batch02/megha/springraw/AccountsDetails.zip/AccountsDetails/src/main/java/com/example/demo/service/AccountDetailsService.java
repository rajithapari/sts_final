package com.example.demo.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;

import com.example.demo.model.Account;
import com.example.demo.model.AccountDescriptor;
import com.example.demo.model.typeunion;

@Service
public class AccountDetailsService {


	
	
	@PersistenceContext
	EntityManager entityManager;
	
	public List<AccountDescriptor>  getAccounts(){
		
		StringBuffer stringBuffer = new StringBuffer();  
		stringBuffer.append(" select * from accountdescriptor ");
		Query query1 = entityManager.createNativeQuery(stringBuffer.toString(), AccountDescriptor.class);
		
			List<AccountDescriptor> accountDescriptor = query1.getResultList();
			return accountDescriptor;
		} 
		
		/*System.out.println("in  Accounts details"); 
	
		StringBuffer stringBuffer = new StringBuffer(); 
		stringBuffer.append(" select *  from accountdescriptor ");
		stringBuffer.append("from transaction tra");
		stringBuffer.append("account acc");
		stringBuffer.append("accountdescriptor");
		stringBuffer.append("loanaccount la");
		stringBuffer.append("where acc.AccDescriptorId= adc.AccountDescriptorId and adc.AccountId = tra.AccountId");
		stringBuffer.append("adc.CustomerId='111111101'");
		System.out.println("Query ----> "+stringBuffer.toString());
	
		Query query1 = entityManager.createNativeQuery(stringBuffer.toString());
		System.out.println(query1.getResultList());
		
	 
	return null;
*/
	
}
