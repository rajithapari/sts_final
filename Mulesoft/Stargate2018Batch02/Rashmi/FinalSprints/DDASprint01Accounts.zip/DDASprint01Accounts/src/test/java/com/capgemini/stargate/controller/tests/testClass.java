package com.capgemini.stargate.controller.tests;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.capgemini.stargate.service.AccountService;

public class testClass {

AccountService accountService;
public boolean isValidAccountId(String accountId)
{
	boolean result = false;
	if(accountId.length() == 0 || accountId == null)
	{
		result = true;
	}
	else if(accountId.length() > 128 || !accountId.matches("\\d++"))
    {
		result = true;
	}
	return result;
}

@Test
public void isNullTest(){
	testClass tests = new testClass();
    assertTrue(tests.isValidAccountId(""));
}

@Test
public void isNotIntegerTest(){
	testClass tests = new testClass();
    assertTrue(tests.isValidAccountId("135dasrf68A"));
}

@Test
public void isValidAccountIdTest(){
	testClass tests = new testClass();
    assertFalse(tests.isValidAccountId("1357902469"));
}

@Test
public void isTooLongTest(){
	testClass tests = new testClass();
    assertTrue(tests.isValidAccountId("10000000000000000676868945634523542350000000t67668779456345654656000000004546465675756865856222245654675222222222222222222222222227902468135"));
}
}
