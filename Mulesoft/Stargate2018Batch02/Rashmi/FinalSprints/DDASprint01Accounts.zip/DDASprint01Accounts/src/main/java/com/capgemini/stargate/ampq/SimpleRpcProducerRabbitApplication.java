package com.capgemini.stargate.ampq;


import java.util.List;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.capgemini.stargate.model.LoanAccount;

import org.springframework.amqp.core.Queue;


@EnableScheduling
@SpringBootApplication
public class SimpleRpcProducerRabbitApplication {
  private final RabbitTemplate template;

  		@Autowired
	    public SimpleRpcProducerRabbitApplication(RabbitTemplate template) {
	        this.template = template;
	    }

	    public void sendMessage(List<LoanAccount> loanAccount) {  
	        this.template.convertAndSend("springaccountsmq", loanAccount.toString());
	    }

	    @Bean
	    public Queue queue() {
	        return new Queue("springaccountsmq", false);
	    }
}