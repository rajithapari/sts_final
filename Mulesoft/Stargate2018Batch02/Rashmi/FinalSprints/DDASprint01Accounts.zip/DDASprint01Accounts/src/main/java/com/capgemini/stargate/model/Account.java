
package com.capgemini.stargate.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "account")
public class Account
    extends AccountDescriptor
    implements Serializable
{

    final static long serialVersionUID = 8720697266554009445L;
    private Long accountMasterId;
    private String parentAccountId;
    private String nickname;
    private String lineOfBusiness;
    private Long accDescriptorId;
    /**
     * Currency codes
     * 
     */
    private String currency;
    private String accountNumber;
    private Double interestRate;
    @Enumerated(EnumType.STRING)
    private InterestRateType interestRateType;
    private Long transferIn;
    private Long transferOut;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
    public Account(String accountId, AccountType accountType, String displayName, Status status, String description, Long accountDescriptorId, String customerId, Long accountMasterId, String parentAccountId, String nickname, String lineOfBusiness, Long accDescriptorId, String currency, String accountNumber, Double interestRate, InterestRateType interestRateType, Long transferIn, Long transferOut) {
        super(accountId, accountType, displayName, status, description, accountDescriptorId, customerId);
        this.accountMasterId = accountMasterId;
        this.parentAccountId = parentAccountId;
        this.nickname = nickname;
        this.lineOfBusiness = lineOfBusiness;
        this.accDescriptorId = accDescriptorId;
        this.currency = currency;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
        this.interestRateType = interestRateType;
        this.transferIn = transferIn;
        this.transferOut = transferOut;
    }

    /**
     * Returns the accountMasterId.
     * 
     * @return
     *     accountMasterId
     */
    @JsonIgnore
    public Long getAccountMasterId() {
        return accountMasterId;
    }

    /**
     * Set the accountMasterId.
     * 
     * @param accountMasterId
     *     the new accountMasterId
     */
    public void setAccountMasterId(Long accountMasterId) {
        this.accountMasterId = accountMasterId;
    }

    /**
     * Returns the parentAccountId.
     * 
     * @return
     *     parentAccountId
     */
    @JsonIgnore
    public String getParentAccountId() {
        return parentAccountId;
    }

    /**
     * Set the parentAccountId.
     * 
     * @param parentAccountId
     *     the new parentAccountId
     */
    public void setParentAccountId(String parentAccountId) {
        this.parentAccountId = parentAccountId;
    }

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * Set the nickname.
     * 
     * @param nickname
     *     the new nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    /**
     * Returns the lineOfBusiness.
     * 
     * @return
     *     lineOfBusiness
     */
    public String getLineOfBusiness() {
        return lineOfBusiness;
    }

    /**
     * Set the lineOfBusiness.
     * 
     * @param lineOfBusiness
     *     the new lineOfBusiness
     */
    public void setLineOfBusiness(String lineOfBusiness) {
        this.lineOfBusiness = lineOfBusiness;
    }

    /**
     * Returns the accDescriptorId.
     * 
     * @return
     *     accDescriptorId
     */
    @JsonIgnore
    public Long getAccDescriptorId() {
        return accDescriptorId;
    }

    /**
     * Set the accDescriptorId.
     * 
     * @param accDescriptorId
     *     the new accDescriptorId
     */
    public void setAccDescriptorId(Long accDescriptorId) {
        this.accDescriptorId = accDescriptorId;
    }

    /**
     * Returns the currency.
     * 
     * @return
     *     currency
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Set the currency.
     * 
     * @param currency
     *     the new currency
     */
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     */
    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    /**
     * Returns the interestRateType.
     * 
     * @return
     *     interestRateType
     */
    public InterestRateType getInterestRateType() {
        return interestRateType;
    }

    /**
     * Set the interestRateType.
     * 
     * @param interestRateType
     *     the new interestRateType
     */
    public void setInterestRateType(InterestRateType interestRateType) {
        this.interestRateType = interestRateType;
    }

    /**
     * Returns the transferIn.
     * 
     * @return
     *     transferIn
     */
    @JsonIgnore
    public Long getTransferIn() {
        return transferIn;
    }

    /**
     * Set the transferIn.
     * 
     * @param transferIn
     *     the new transferIn
     */
    public void setTransferIn(Long transferIn) {
        this.transferIn = transferIn;
    }

    /**
     * Returns the transferOut.
     * 
     * @return
     *     transferOut
     */
    @JsonIgnore
    public Long getTransferOut() {
        return transferOut;
    }

    /**
     * Set the transferOut.
     * 
     * @param transferOut
     *     the new transferOut
     */
    public void setTransferOut(Long transferOut) {
        this.transferOut = transferOut;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(accountMasterId).append(parentAccountId).append(nickname).append(lineOfBusiness).append(accDescriptorId).append(currency).append(accountNumber).append(interestRate).append(interestRateType).append(transferIn).append(transferOut).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(accountMasterId, otherObject.accountMasterId).append(parentAccountId, otherObject.parentAccountId).append(nickname, otherObject.nickname).append(lineOfBusiness, otherObject.lineOfBusiness).append(accDescriptorId, otherObject.accDescriptorId).append(currency, otherObject.currency).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).append(interestRateType, otherObject.interestRateType).append(transferIn, otherObject.transferIn).append(transferOut, otherObject.transferOut).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("accountMasterId", accountMasterId).append("parentAccountId", parentAccountId).append("nickname", nickname).append("lineOfBusiness", lineOfBusiness).append("accDescriptorId", accDescriptorId).append("currency", currency).append("accountNumber", accountNumber).append("interestRate", interestRate).append("interestRateType", interestRateType).append("transferIn", transferIn).append("transferOut", transferOut).toString();
    }

}
