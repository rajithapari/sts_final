
package com.capgemini.stargate.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@Entity
@Table(name = "loanaccount")
public class LoanAccount
    extends Account
    implements Serializable
{

    final static long serialVersionUID = 8732264657660732934L;    
    private Long loanAccountId;
    @Column(name = "accountid", insertable = false, updatable = false)
    private Long accountIdLoan;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date balanceAsOf;
    private Long principalBalance;
    private Long originalPrincipal;
    private Long loanTerm;
    private Long totalNumberOfPayments;
    private Double nextPaymentAmount;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private Date nextPaymentDate;
    private Double lastPaymentAmount;
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date lastPaymentDate;
    @Enumerated(EnumType.STRING)
    private PaymentFrequency paymentFrequency;

    /**
     * Creates a new LoanAccount.
     * 
     */
    public LoanAccount() {
        super();
    }

    /**
     * Creates a new LoanAccount.
     * 
     */
    public LoanAccount(String accountId, AccountType accountType, String displayName, Status status, String description, Long accountDescriptorId, String customerId, Long accountMasterId, String parentAccountId, String nickname, String lineOfBusiness, Long accDescriptorId, String currency, String accountNumber, Double interestRate, InterestRateType interestRateType, Long transferIn, Long transferOut, Long loanAccountId, Long accountIdLoan, Date balanceAsOf, Long principalBalance, Long originalPrincipal, Long loanTerm, Long totalNumberOfPayments, Double nextPaymentAmount, Date nextPaymentDate, Double lastPaymentAmount, Date lastPaymentDate, PaymentFrequency paymentFrequency) {
        super(accountId, accountType, displayName, status, description, accountDescriptorId, customerId, accountMasterId, parentAccountId, nickname, lineOfBusiness, accDescriptorId, currency, accountNumber, interestRate, interestRateType, transferIn, transferOut);
        this.loanAccountId = loanAccountId;
        this.accountIdLoan = accountIdLoan;
        this.balanceAsOf = balanceAsOf;
        this.principalBalance = principalBalance;
        this.originalPrincipal = originalPrincipal;
        this.loanTerm = loanTerm;
        this.totalNumberOfPayments = totalNumberOfPayments;
        this.nextPaymentAmount = nextPaymentAmount;
        this.nextPaymentDate = nextPaymentDate;
        this.lastPaymentAmount = lastPaymentAmount;
        this.lastPaymentDate = lastPaymentDate;
        this.paymentFrequency = paymentFrequency;
    }

    /**
     * Returns the loanAccountId.
     * 
     * @return
     *     loanAccountId
     */
    public Long getLoanAccountId() {
        return loanAccountId;
    }

    /**
     * Set the loanAccountId.
     * 
     * @param loanAccountId
     *     the new loanAccountId
     */
    public void setLoanAccountId(Long loanAccountId) {
        this.loanAccountId = loanAccountId;
    }

    /**
     * Returns the accountIdLoan.
     * 
     * @return
     *     accountIdLoan
     */
    @JsonIgnore
    public Long getAccountIdLoan() {
        return accountIdLoan;
    }

    /**
     * Set the accountIdLoan.
     * 
     * @param accountIdLoan
     *     the new accountIdLoan
     */
    public void setAccountIdLoan(Long accountIdLoan) {
        this.accountIdLoan = accountIdLoan;
    }

    /**
     * Returns the balanceAsOf.
     * 
     * @return
     *     balanceAsOf
     */
    public Date getBalanceAsOf() {
        return balanceAsOf;
    }

    /**
     * Set the balanceAsOf.
     * 
     * @param balanceAsOf
     *     the new balanceAsOf
     */
    public void setBalanceAsOf(Date balanceAsOf) {
        this.balanceAsOf = balanceAsOf;
    }

    /**
     * Returns the principalBalance.
     * 
     * @return
     *     principalBalance
     */
    public Long getPrincipalBalance() {
        return principalBalance;
    }

    /**
     * Set the principalBalance.
     * 
     * @param principalBalance
     *     the new principalBalance
     */
    public void setPrincipalBalance(Long principalBalance) {
        this.principalBalance = principalBalance;
    }

    /**
     * Returns the originalPrincipal.
     * 
     * @return
     *     originalPrincipal
     */
    @JsonIgnore
    public Long getOriginalPrincipal() {
        return originalPrincipal;
    }

    /**
     * Set the originalPrincipal.
     * 
     * @param originalPrincipal
     *     the new originalPrincipal
     */
    public void setOriginalPrincipal(Long originalPrincipal) {
        this.originalPrincipal = originalPrincipal;
    }

    /**
     * Returns the loanTerm.
     * 
     * @return
     *     loanTerm
     */
    public Long getLoanTerm() {
        return loanTerm;
    }

    /**
     * Set the loanTerm.
     * 
     * @param loanTerm
     *     the new loanTerm
     */
    public void setLoanTerm(Long loanTerm) {
        this.loanTerm = loanTerm;
    }

    /**
     * Returns the totalNumberOfPayments.
     * 
     * @return
     *     totalNumberOfPayments
     */
    public Long getTotalNumberOfPayments() {
        return totalNumberOfPayments;
    }

    /**
     * Set the totalNumberOfPayments.
     * 
     * @param totalNumberOfPayments
     *     the new totalNumberOfPayments
     */
    public void setTotalNumberOfPayments(Long totalNumberOfPayments) {
        this.totalNumberOfPayments = totalNumberOfPayments;
    }

    /**
     * Returns the nextPaymentAmount.
     * 
     * @return
     *     nextPaymentAmount
     */
    public Double getNextPaymentAmount() {
        return nextPaymentAmount;
    }

    /**
     * Set the nextPaymentAmount.
     * 
     * @param nextPaymentAmount
     *     the new nextPaymentAmount
     */
    public void setNextPaymentAmount(Double nextPaymentAmount) {
        this.nextPaymentAmount = nextPaymentAmount;
    }

    /**
     * Returns the nextPaymentDate.
     * 
     * @return
     *     nextPaymentDate
     */
    public Date getNextPaymentDate() {
        return nextPaymentDate;
    }

    /**
     * Set the nextPaymentDate.
     * 
     * @param nextPaymentDate
     *     the new nextPaymentDate
     */
    public void setNextPaymentDate(Date nextPaymentDate) {
        this.nextPaymentDate = nextPaymentDate;
    }

    /**
     * Returns the lastPaymentAmount.
     * 
     * @return
     *     lastPaymentAmount
     */
    public Double getLastPaymentAmount() {
        return lastPaymentAmount;
    }

    /**
     * Set the lastPaymentAmount.
     * 
     * @param lastPaymentAmount
     *     the new lastPaymentAmount
     */
    public void setLastPaymentAmount(Double lastPaymentAmount) {
        this.lastPaymentAmount = lastPaymentAmount;
    }

    /**
     * Returns the lastPaymentDate.
     * 
     * @return
     *     lastPaymentDate
     */
    public Date getLastPaymentDate() {
        return lastPaymentDate;
    }

    /**
     * Set the lastPaymentDate.
     * 
     * @param lastPaymentDate
     *     the new lastPaymentDate
     */
    public void setLastPaymentDate(Date lastPaymentDate) {
        this.lastPaymentDate = lastPaymentDate;
    }

    /**
     * Returns the paymentFrequency.
     * 
     * @return
     *     paymentFrequency
     */
    public PaymentFrequency getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Set the paymentFrequency.
     * 
     * @param paymentFrequency
     *     the new paymentFrequency
     */
    public void setPaymentFrequency(PaymentFrequency paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(loanAccountId).append(accountIdLoan).append(balanceAsOf).append(principalBalance).append(originalPrincipal).append(loanTerm).append(totalNumberOfPayments).append(nextPaymentAmount).append(nextPaymentDate).append(lastPaymentAmount).append(lastPaymentDate).append(paymentFrequency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        LoanAccount otherObject = ((LoanAccount) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(loanAccountId, otherObject.loanAccountId).append(accountIdLoan, otherObject.accountIdLoan).append(balanceAsOf, otherObject.balanceAsOf).append(principalBalance, otherObject.principalBalance).append(originalPrincipal, otherObject.originalPrincipal).append(loanTerm, otherObject.loanTerm).append(totalNumberOfPayments, otherObject.totalNumberOfPayments).append(nextPaymentAmount, otherObject.nextPaymentAmount).append(nextPaymentDate, otherObject.nextPaymentDate).append(lastPaymentAmount, otherObject.lastPaymentAmount).append(lastPaymentDate, otherObject.lastPaymentDate).append(paymentFrequency, otherObject.paymentFrequency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("loanAccountId", loanAccountId).append("accountIdLoan", accountIdLoan).append("balanceAsOf", balanceAsOf).append("principalBalance", principalBalance).append("originalPrincipal", originalPrincipal).append("loanTerm", loanTerm).append("totalNumberOfPayments", totalNumberOfPayments).append("nextPaymentAmount", nextPaymentAmount).append("nextPaymentDate", nextPaymentDate).append("lastPaymentAmount", lastPaymentAmount).append("lastPaymentDate", lastPaymentDate).append("paymentFrequency", paymentFrequency).toString();
    }

}
