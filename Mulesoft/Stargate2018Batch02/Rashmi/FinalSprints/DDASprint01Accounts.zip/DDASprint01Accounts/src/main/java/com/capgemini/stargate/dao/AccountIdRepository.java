package com.capgemini.stargate.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.capgemini.stargate.model.AccountDesc;

@Repository
public interface AccountIdRepository extends JpaRepository<AccountDesc, String> {
}
