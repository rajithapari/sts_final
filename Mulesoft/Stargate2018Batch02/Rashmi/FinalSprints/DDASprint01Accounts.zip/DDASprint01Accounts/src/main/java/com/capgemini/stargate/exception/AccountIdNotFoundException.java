package com.capgemini.stargate.exception;



public class AccountIdNotFoundException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public AccountIdNotFoundException(String ex) 
	 {
		super(ex);
	 }
}


