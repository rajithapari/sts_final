package com.capgemini.stargate.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.capgemini.stargate.model.LoanAccount;

@Repository
public interface AccountRepository extends JpaRepository<LoanAccount, String>
{   
    @Query (value = "select * from accountdescriptor a, account acc , loanaccount loanacc " +
		   "where a.accountdescriptorid = acc.accdescriptorid " +
		   "and acc.accountmasterid = loanacc.accountid " +
		   "and a.accountid = :accountId", nativeQuery = true)
    public List<LoanAccount> getByAccountId(@Param("accountId") String accountId); 
}