package com.capgemini.stargate.exception;

public class InvalidAccountIdException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public InvalidAccountIdException(String ex) {
		super(ex);
	}
}
