package com.capgemini.stargate.controller;



import com.capgemini.stargate.ampq.SimpleRpcProducerRabbitApplication;
import com.capgemini.stargate.exception.InternalServerErrorException;
import com.capgemini.stargate.exception.InvalidAccountIdException;
import com.capgemini.stargate.model.LoanAccount;
import com.capgemini.stargate.service.AccountService;
import com.capgemini.stargate.service.BankCatalogClient;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import net.sf.json.JSONObject;
import net.sf.json.JSONSerializer;

import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;
import javax.persistence.EntityListeners;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@EnableAspectJAutoProxy(proxyTargetClass = true)
@RequestMapping(value = "api/v1/", produces = "application/json")
@EntityListeners(AuditingEntityListener.class)
@JsonIgnoreProperties(value = {"createdAt", "updatedAt"},
        allowGetters = true)
public class MainController
{
	@Autowired
	AccountService accountService;
	
	@Autowired
	SimpleRpcProducerRabbitApplication simpleRpcProducerRabbitApplication;
	
	@Autowired
	BankCatalogClient bankCatalogClient;
	
   
    @RequestMapping(value ="/accounts/account" ,method = RequestMethod.POST,consumes="application/json")
	public ResponseEntity<?> getAccountById(@RequestBody String accountId) throws IOException
	{
    	try{
    		  /* Get convert request in JSON format from the body of POST request */ 
    		  JSONObject json = (JSONObject) JSONSerializer.toJSON(accountId);
    		  /* Get the accountId in String format from json */ 
    		  String st = json.getString("accountId");
    		  List<LoanAccount> acc = accountService.getAccountById(st);
    	      simpleRpcProducerRabbitApplication.sendMessage(accountService.getAccountById(st));
    		  bankCatalogClient.getBankById(acc.get(0).getCustomerId());
    		  return ResponseEntity.ok().body(acc); 
    		}
    		catch(InvalidAccountIdException ex){
    			return new CustomExceptionHandlerController().handleInvalidAccountId(ex);}
    		catch(NoSuchElementException ex){
    			return new CustomExceptionHandlerController().handleAccountIdNotFound(ex);}
    		catch(InternalServerErrorException ex){
    			return new CustomExceptionHandlerController().handleInternalServerError(ex);}   
	}
}