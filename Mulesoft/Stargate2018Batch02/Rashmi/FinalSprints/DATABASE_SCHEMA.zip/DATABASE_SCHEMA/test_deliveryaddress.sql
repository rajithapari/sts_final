-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `deliveryaddress`
--

DROP TABLE IF EXISTS `deliveryaddress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `deliveryaddress` (
  `DeliveryAddressId` int(11) NOT NULL,
  `Type` enum('HOME','BUSINESS','MAILING') DEFAULT NULL,
  `Line1` varchar(45) DEFAULT NULL,
  `Line2` varchar(45) DEFAULT NULL,
  `City` varchar(45) DEFAULT NULL,
  `State` varchar(45) DEFAULT NULL,
  `Zip` varchar(45) DEFAULT NULL,
  `Country` varchar(45) DEFAULT NULL,
  `CustomerId` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`DeliveryAddressId`),
  KEY `customerid_fk` (`CustomerId`),
  CONSTRAINT `deliveryaddress_ibfk_1` FOREIGN KEY (`CustomerId`) REFERENCES `customer` (`customerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deliveryaddress`
--

LOCK TABLES `deliveryaddress` WRITE;
/*!40000 ALTER TABLE `deliveryaddress` DISABLE KEYS */;
INSERT INTO `deliveryaddress` VALUES (201,'HOME','963 Lovelace Road','Tampa Bay','California','US','90001','United states','111111101'),(202,'BUSINESS','964 Lovelace Road','Tampa1 Bay','California','US','90001','United states','111111101'),(203,'MAILING','965 Lovelace Road','Tampa2 Bay','California','US','90001','United states','111111101'),(204,'HOME','964 Lovelace Road','Tampa Bay','California','US','90001','United states','111111102'),(205,'BUSINESS','178 Lovelace Road','Tampa Bay','California','US','90001','United states','111111102'),(206,'MAILING','963 Lovelace Road','Tampa Bay','California','US','90001','United states','111111102'),(207,'HOME','964 Lovelace Road','Tampa Bay','California','US','90001','United states','111111103'),(208,'BUSINESS','963 Lovelace Road','Tampa Bay','California','US','90001','United states','111111103'),(209,'MAILING','963 Lovelace Road','Tampa Bay','California','US','90001','United states','111111103'),(210,'HOME','964 Lovelace Road','Tampa Bay','California','US','90001','United states','111111104'),(211,'BUSINESS','963 Lovelace Road','Tampa Bay','California','US','90001','United states','111111104'),(212,'MAILING','963 Lovelace Road','Tampa Bay','California','US','90001','United states','111111104');
/*!40000 ALTER TABLE `deliveryaddress` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-24 17:14:59
