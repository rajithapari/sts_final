-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `loanaccount`
--

DROP TABLE IF EXISTS `loanaccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `loanaccount` (
  `LoanAccountId` int(11) NOT NULL AUTO_INCREMENT,
  `AccountId` int(11) DEFAULT NULL,
  `BalanceAsOf` date DEFAULT NULL,
  `PrincipalBalance` int(11) DEFAULT NULL,
  `OriginalPrincipal` int(11) DEFAULT NULL,
  `LoanTerm` int(11) DEFAULT NULL,
  `TotalNumberOfPayments` int(11) DEFAULT NULL,
  `NextPaymentAmount` double DEFAULT NULL,
  `NextPaymentDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `LastPaymentAmount` double DEFAULT NULL,
  `LastPaymentDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `PaymentFrequency` enum('DAILY','WEEKLY','BIWEEKLY','SEMIMONTHLY','MONTHLY','SEMIANNUALLY','ANNUALLY') DEFAULT NULL,
  PRIMARY KEY (`LoanAccountId`),
  KEY `FK_ACCOUNT_LOCA` (`AccountId`),
  CONSTRAINT `FK_ACCOUNT_LOCA` FOREIGN KEY (`AccountId`) REFERENCES `account` (`accountmasterid`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1 COMMENT='LoanAccountId';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loanaccount`
--

LOCK TABLES `loanaccount` WRITE;
/*!40000 ALTER TABLE `loanaccount` DISABLE KEYS */;
INSERT INTO `loanaccount` VALUES (101,201,'2018-08-15',200000,300000,5,12,10000,'2018-09-14 18:30:00',10000,'2018-08-14 18:30:00','MONTHLY'),(102,203,'2018-08-15',400000,500000,6,12,5000,'2018-09-14 18:30:00',5000,'2018-08-14 18:30:00','WEEKLY');
/*!40000 ALTER TABLE `loanaccount` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-24 17:15:11
