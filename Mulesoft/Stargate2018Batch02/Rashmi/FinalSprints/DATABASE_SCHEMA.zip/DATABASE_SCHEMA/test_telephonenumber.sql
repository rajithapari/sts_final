-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `telephonenumber`
--

DROP TABLE IF EXISTS `telephonenumber`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `telephonenumber` (
  `TelephoneNumberId` int(11) NOT NULL,
  `Type` enum('HOME','BUSINESS','CELL','FAX') DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `Number` varchar(10) DEFAULT NULL,
  `CustomerId_FK` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`TelephoneNumberId`),
  KEY `customerid_fk` (`CustomerId_FK`),
  CONSTRAINT `telephonenumber_ibfk_1` FOREIGN KEY (`CustomerId_FK`) REFERENCES `customer` (`customerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telephonenumber`
--

LOCK TABLES `telephonenumber` WRITE;
/*!40000 ALTER TABLE `telephonenumber` DISABLE KEYS */;
INSERT INTO `telephonenumber` VALUES (401,'HOME','916','8004771477','111111101'),(402,'CELL','916','8004777477','111111102'),(403,'HOME','916','8004771477','111111102'),(404,'CELL','916','8004777477','111111102'),(405,'HOME','916','8004771477','111111102'),(406,'BUSINESS','916','8004771477','111111103'),(407,'HOME','916','8004771477','111111103'),(408,'BUSINESS','916','8004071477','111111104'),(409,'HOME','916','8004671477','111111104'),(410,'BUSINESS','916','8008771477','111111105'),(411,'HOME','916','8006771477','111111105');
/*!40000 ALTER TABLE `telephonenumber` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-24 17:14:51
