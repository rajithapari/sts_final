
package com.capgemini.stargate.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonProperty;

public enum InterestRateType {

    @JsonProperty("FIXED")
    FIXED("FIXED"),
    @JsonProperty("VARIABLE")
    VARIABLE("VARIABLE");
    private final String value;
    private final static Map<String, InterestRateType> VALUE_CACHE = new HashMap<String, InterestRateType>();

    static {
        for (InterestRateType c: values()) {
            VALUE_CACHE.put(c.value, c);
        }
    }

    private InterestRateType(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static InterestRateType fromValue(String value) {
        return VALUE_CACHE.get(value);
    }

    @Override
    public String toString() {
        return this.value;
    }

}
