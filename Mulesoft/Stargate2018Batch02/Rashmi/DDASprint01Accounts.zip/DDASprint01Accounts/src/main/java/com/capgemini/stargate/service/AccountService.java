package com.capgemini.stargate.service;

import java.util.List;
import com.capgemini.stargate.model.LoanAccount;

public interface AccountService 
{
	 public List<LoanAccount> getAccountById(String accountId);
}
