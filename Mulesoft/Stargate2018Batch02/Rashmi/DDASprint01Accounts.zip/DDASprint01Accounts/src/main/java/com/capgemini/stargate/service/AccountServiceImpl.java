package com.capgemini.stargate.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.stargate.dao.AccountIdRepository;
import com.capgemini.stargate.dao.AccountRepository;
import com.capgemini.stargate.exception.AccountIdNotFoundException;
import com.capgemini.stargate.exception.InternalServerErrorException;
import com.capgemini.stargate.exception.InvalidAccountIdException;
import com.capgemini.stargate.model.AccountDesc;
import com.capgemini.stargate.model.LoanAccount;


@Service
public class AccountServiceImpl implements AccountService
{
	@Autowired
	AccountRepository accountRepo;
	
	@Autowired
	AccountIdRepository repo;
	Optional<AccountDesc> accIdList; 
	
	@Override
	public List<LoanAccount> getAccountById(String accountId) throws InvalidAccountIdException,AccountIdNotFoundException
	{
		
		final Pattern pattern = Pattern.compile("\\d++");
		
		try{
			
			if (pattern.matcher(accountId).matches() && accountId != null) 
			{
				accIdList = repo.findById(accountId); //throws NoSuchElementException internally
				if(accIdList.get().getAccountId() != null)
				{
					return accountRepo.getByAccountId(accountId);		
				}
			}
			else
			{
				throw new InvalidAccountIdException("InvalidAccountIdException") ;
			}
	
		}
		catch (InvalidAccountIdException ex) {
			throw new InvalidAccountIdException("");}
		catch (NoSuchElementException ex) {
			throw new NoSuchElementException("");}
		catch (Exception ex){
			throw new InternalServerErrorException("");}
	return accountRepo.getByAccountId(accountId);
	}
}