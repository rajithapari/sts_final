
package com.capgemini.stargate.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonProperty;

public enum PaymentFrequency {

    @JsonProperty("ANNUALLY")
    ANNUALLY("ANNUALLY"),
    @JsonProperty("BIWEEKLY")
    BIWEEKLY("BIWEEKLY"),
    @JsonProperty("DAILY")
    DAILY("DAILY"),
    @JsonProperty("MONTHLY")
    MONTHLY("MONTHLY"),
    @JsonProperty("SEMIANNUALLY")
    SEMIANNUALLY("SEMIANNUALLY"),
    @JsonProperty("SEMIMONTHLY")
    SEMIMONTHLY("SEMIMONTHLY"),
    @JsonProperty("WEEKLY")
    WEEKLY("WEEKLY");
    private final String value;
    private final static Map<String, PaymentFrequency> VALUE_CACHE = new HashMap<String, PaymentFrequency>();

    static {
        for (PaymentFrequency c: values()) {
            VALUE_CACHE.put(c.value, c);
        }
    }

    private PaymentFrequency(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static PaymentFrequency fromValue(String value) {
        return VALUE_CACHE.get(value);
    }

    @Override
    public String toString() {
        return this.value;
    }

}
