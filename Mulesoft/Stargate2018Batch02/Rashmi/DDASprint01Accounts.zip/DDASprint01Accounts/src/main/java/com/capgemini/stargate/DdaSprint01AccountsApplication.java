package com.capgemini.stargate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DdaSprint01AccountsApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(DdaSprint01AccountsApplication.class, args);
	
	}
}
