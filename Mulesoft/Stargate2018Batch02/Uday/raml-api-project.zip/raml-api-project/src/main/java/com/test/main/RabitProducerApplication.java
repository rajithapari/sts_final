package com.test.main;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.stargate.controller.model.Account;


@Component
public class RabitProducerApplication {
	
	 private final RabbitTemplate template;


	    @Autowired
	    public RabitProducerApplication(RabbitTemplate template) {
	        this.template = template;
	    }

	    public void sendMessage(Account accounts) {

	        this.template.convertAndSend("spring-boot-queue", accounts.toString());
	    }

	    @Bean
	    public Queue queue() {
	        return new Queue("spring-boot-queue", false);
	    }
}

/*
 * rpcProducerRabbitApplication.sendMessage(accounts); 
 */
