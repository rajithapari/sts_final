
package com.stargate.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


/***
create table currency(
currencyId integer,
currencyRate integer,
currecyCode varchar(3),
originalCurrencyCode varchar(3)
);
 * @author UJJWALA-SHIVANSH
 *
 */

@Entity
@Table(name="currency")
public class Currency implements Serializable {

	final static long serialVersionUID = 4953274553215978241L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long currencyID;
	@Column (name="currencyRate")
	private long currencyRate;
	@Column (name="currencyCode")
	private String currencyCode;
	@Column (name="originalCurrencyCode")
	private String originalCurrencyCode;

	/**
	 * Creates a new Currency.
	 * 
	 */
	public Currency() {
	}

	public Currency(long currencyRate, String currencyCode, String originalCurrencyCode) {
		this.currencyRate = currencyRate;
		this.currencyCode = currencyCode;
		this.originalCurrencyCode = originalCurrencyCode;
	}		

	public int hashCode() {
		return new HashCodeBuilder().toHashCode();
	}

	public boolean equals(Object other) {
		if (other == null) {
			return false;
		}
		if (other == this) {
			return true;
		}
		if (this.getClass() != other.getClass()) {
			return false;
		}
		Currency otherObject = ((Currency) other);
		return new EqualsBuilder().isEquals();
	}

	public String toString() {
		return new ToStringBuilder(this).toString();
	}

	public long getCurrencyID() {
		return currencyID;
	}

	public void setCurrencyID(long currencyID) {
		this.currencyID = currencyID;
	}

	public long getCurrencyRate() {
		return currencyRate;
	}

	public void setCurrencyRate(long currencyRate) {
		this.currencyRate = currencyRate;
	}



	public String getOriginalCurrencyCode() {
		return originalCurrencyCode;
	}

	public void setOriginalCurrencyCode(String originalCurrencyCode) {
		this.originalCurrencyCode = originalCurrencyCode;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
}
