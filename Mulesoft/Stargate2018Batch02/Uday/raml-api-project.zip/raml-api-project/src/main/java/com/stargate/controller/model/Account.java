
package com.stargate.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


@Entity
public class Account
    extends AccountDescriptor
    implements Serializable
{

    final static long serialVersionUID = 5918325172666304025L;
    protected String nickname;
    protected String accountNumber;
    protected Double interestRate;

    /**
     * Creates a new Account.
     * 
     */
    public Account() {
        super();
    }

    /**
     * Creates a new Account.
     * 
     */
    public Account(String accountId, AccountStatus status, String displayName, String description, AccountType accountType, String nickname, String accountNumber, Double interestRate) {
        super(accountId, status, displayName, description, accountType);
        this.nickname = nickname;
        this.accountNumber = accountNumber;
        this.interestRate = interestRate;
    }

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    @NotNull
    @Pattern(regexp = "\\d+")
    @Size(max = 128)
    public String getAccountId() {
        return accountId;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    @NotNull
    public AccountStatus getStatus() {
        return status;
    }

    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
    @NotNull
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Returns the description.
     * 
     * @return
     *     description
     */
    @NotNull
    public String getDescription() {
        return description;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    @NotNull
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
    @NotNull
    public String getNickname() {
        return nickname;
    }

    /**
     * Set the nickname.
     * 
     * @param nickname
     *     the new nickname
     */
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    @NotNull
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Set the accountNumber.
     * 
     * @param accountNumber
     *     the new accountNumber
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    @NotNull
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Set the interestRate.
     * 
     * @param interestRate
     *     the new interestRate
     */
    public void setInterestRate(Double interestRate) {
        this.interestRate = interestRate;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(nickname).append(accountNumber).append(interestRate).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        Account otherObject = ((Account) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(nickname, otherObject.nickname).append(accountNumber, otherObject.accountNumber).append(interestRate, otherObject.interestRate).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("nickname", nickname).append("accountNumber", accountNumber).append("interestRate", interestRate).toString();
    }

}
