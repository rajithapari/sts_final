
package com.stargate.controller.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;


@Entity
public class AccountDescriptor implements Serializable
{

    final static long serialVersionUID = 5845615881067431319L;
    
    @Id
    @Column(name="AccountId")
    protected String accountId;
    @Enumerated(EnumType.STRING)
    protected AccountStatus status;
    protected String displayName;
    protected String description;
    @Enumerated(EnumType.STRING) 
    protected AccountType accountType;

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor() {
        super();
    }

    /**
     * Creates a new AccountDescriptor.
     * 
     */
    public AccountDescriptor(String accountId, AccountStatus status, String displayName, String description, AccountType accountType) {
        super();
        this.accountId = accountId;
        this.status = status;
        this.displayName = displayName;
        this.description = description;
        this.accountType = accountType;
    }

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    @NotNull
    @Pattern(regexp = "\\d+")
    @Size(max = 128)
    public String getAccountId() {
        return accountId;
    }

    /**
     * Set the accountId.
     * 
     * @param accountId
     *     the new accountId
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    @NotNull
    @Valid
    public AccountStatus getStatus() {
        return status;
    }

    /**
     * Set the status.
     * 
     * @param status
     *     the new status
     */
    public void setStatus(AccountStatus status) {
        this.status = status;
    }

    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
    @NotNull
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Set the displayName.
     * 
     * @param displayName
     *     the new displayName
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Returns the description.
     * 
     * @return
     *     description
     */
    @NotNull
    public String getDescription() {
        return description;
    }

    /**
     * Set the description.
     * 
     * @param description
     *     the new description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    @NotNull
    @Valid
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * Set the accountType.
     * 
     * @param accountType
     *     the new accountType
     */
    public void setAccountType(AccountType accountType) {
        this.accountType = accountType;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(accountId).append(status).append(displayName).append(description).append(accountType).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        AccountDescriptor otherObject = ((AccountDescriptor) other);
        return new EqualsBuilder().append(accountId, otherObject.accountId).append(status, otherObject.status).append(displayName, otherObject.displayName).append(description, otherObject.description).append(accountType, otherObject.accountType).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("accountId", accountId).append("status", status).append("displayName", displayName).append("description", description).append("accountType", accountType).toString();
    }

}
