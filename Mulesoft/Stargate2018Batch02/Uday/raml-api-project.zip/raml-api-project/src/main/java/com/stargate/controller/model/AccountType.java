
package com.stargate.controller.model;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;



public enum AccountType {

    @JsonProperty("INVESTMENT_ACCOUNT")
    INVESTMENT_ACCOUNT("INVESTMENT_ACCOUNT"),
    @JsonProperty("LOAN_ACCOUNT")
    LOAN_ACCOUNT("LOAN_ACCOUNT"),
    @JsonProperty("DEPOSIT_ACCOUNT")
    DEPOSIT_ACCOUNT("DEPOSIT_ACCOUNT"),
    @JsonProperty("COMMERCIALLOAN")
    COMMERCIALLOAN("COMMERCIALLOAN"),
    @JsonProperty("OPEN")
    OPEN("OPEN"),
    @JsonProperty("SAVINGS")
    SAVINGS("SAVINGS");
    private final String value;
    private final static Map<String, AccountType> VALUE_CACHE = new HashMap<String, AccountType>();

    static {
        for (AccountType c: values()) {
            VALUE_CACHE.put(c.value, c);
        }
    }

    private AccountType(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static AccountType fromValue(String value) {
        return VALUE_CACHE.get(value);
    }

    @Override
    public String toString() {
        return this.value;
    }

}
