
package com.stargate.controller.model;

import java.io.Serializable;
import java.util.Date;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class InvestmentBalance implements Serializable
{

    final static long serialVersionUID = 4573203245874904248L;
    protected String balanceName;
    protected String balanceDescription;
    protected BalanceType balanceType;
    protected Double balanceValue;
    @JsonFormat(pattern = "yyyy-MM-dd")
    protected Date balanceDate;
    protected Currency currency;

    /**
     * Creates a new InvestmentBalance.
     * 
     */
    public InvestmentBalance() {
        super();
    }

    /**
     * Creates a new InvestmentBalance.
     * 
     */
    public InvestmentBalance(String balanceName, String balanceDescription, BalanceType balanceType, Double balanceValue, Date balanceDate, Currency currency) {
        super();
        this.balanceName = balanceName;
        this.balanceDescription = balanceDescription;
        this.balanceType = balanceType;
        this.balanceValue = balanceValue;
        this.balanceDate = balanceDate;
        this.currency = currency;
    }

    /**
     * Returns the balanceName.
     * 
     * @return
     *     balanceName
     */
    @NotNull
    public String getBalanceName() {
        return balanceName;
    }

    /**
     * Set the balanceName.
     * 
     * @param balanceName
     *     the new balanceName
     */
    public void setBalanceName(String balanceName) {
        this.balanceName = balanceName;
    }

    /**
     * Returns the balanceDescription.
     * 
     * @return
     *     balanceDescription
     */
    @NotNull
    public String getBalanceDescription() {
        return balanceDescription;
    }

    /**
     * Set the balanceDescription.
     * 
     * @param balanceDescription
     *     the new balanceDescription
     */
    public void setBalanceDescription(String balanceDescription) {
        this.balanceDescription = balanceDescription;
    }

    /**
     * Returns the balanceType.
     * 
     * @return
     *     balanceType
     */
    @NotNull
    @Valid
    public BalanceType getBalanceType() {
        return balanceType;
    }

    /**
     * Set the balanceType.
     * 
     * @param balanceType
     *     the new balanceType
     */
    public void setBalanceType(BalanceType balanceType) {
        this.balanceType = balanceType;
    }

    /**
     * Returns the balanceValue.
     * 
     * @return
     *     balanceValue
     */
    @NotNull
    public Double getBalanceValue() {
        return balanceValue;
    }

    /**
     * Set the balanceValue.
     * 
     * @param balanceValue
     *     the new balanceValue
     */
    public void setBalanceValue(Double balanceValue) {
        this.balanceValue = balanceValue;
    }

    /**
     * Returns the balanceDate.
     * 
     * @return
     *     balanceDate
     */
    @NotNull
    public Date getBalanceDate() {
        return balanceDate;
    }

    /**
     * Set the balanceDate.
     * 
     * @param balanceDate
     *     the new balanceDate
     */
    public void setBalanceDate(Date balanceDate) {
        this.balanceDate = balanceDate;
    }

    /**
     * Returns the currency.
     * 
     * @return
     *     currency
     */
    @NotNull
    @Valid
    public Currency getCurrency() {
        return currency;
    }

    /**
     * Set the currency.
     * 
     * @param currency
     *     the new currency
     */
    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public int hashCode() {
        return new HashCodeBuilder().append(balanceName).append(balanceDescription).append(balanceType).append(balanceValue).append(balanceDate).append(currency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        InvestmentBalance otherObject = ((InvestmentBalance) other);
        return new EqualsBuilder().append(balanceName, otherObject.balanceName).append(balanceDescription, otherObject.balanceDescription).append(balanceType, otherObject.balanceType).append(balanceValue, otherObject.balanceValue).append(balanceDate, otherObject.balanceDate).append(currency, otherObject.currency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).append("balanceName", balanceName).append("balanceDescription", balanceDescription).append("balanceType", balanceType).append("balanceValue", balanceValue).append("balanceDate", balanceDate).append("currency", currency).toString();
    }

}
