package com.stargate.soap.services;

import java.io.FileWriter;
import java.io.IOException;

import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

//import bank_web_service.GetBankDetailsRequest;
//import bank_web_service.GetBankDetailsResponse;

public class BankCatalogClient extends WebServiceGatewaySupport {/*

	public GetBankDetailsResponse getBankById(String id) {
		GetBankDetailsRequest request = new GetBankDetailsRequest();
		request.setCustomerId(id);
		GetBankDetailsResponse response = (GetBankDetailsResponse) getWebServiceTemplate()
				.marshalSendAndReceive(request, new SoapActionCallback("http://34.236.109.151:8000/ws/"));

		Gson gson = new Gson();
		System.out.println("Write to SOAP Response to Console:: " + gson.toJson(response).toString());

		try {
			FileWriter file = new FileWriter("D:\\test.txt");
			file.write(gson.toJson(response).toString());
			file.close();
			System.out.println("Write to SOAP Response to file location D:\\test.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}

		return response;
	}
*/}