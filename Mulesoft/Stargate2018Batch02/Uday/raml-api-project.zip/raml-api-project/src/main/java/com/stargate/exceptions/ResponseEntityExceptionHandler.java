package com.stargate.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;


// This class handle differ types of exception.


@ControllerAdvice
@RestController
public class ResponseEntityExceptionHandler  {
	

	@ExceptionHandler(value = BadRequestException.class)
	public final ResponseEntity<ExceptionResponse> forBadRequest(BadRequestException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Bad request, Account ID cannot be empty or null", "400");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(value = UnauthorisedRequestException.class)
	public final ResponseEntity<ExceptionResponse> Anauthorised(BadRequestException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Anauthorised request", "401");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.UNAUTHORIZED);
	}
	
	@ExceptionHandler(value = SourceNotFoundException.class)
	public final ResponseEntity<ExceptionResponse> handleStatementNotFoundException(SourceNotFoundException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("source not found", "404");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = MethodNotAllowedException.class)
	public final ResponseEntity<ExceptionResponse> handleMethodNotAcceptableException(MethodNotAllowedException ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Method Not Allowd", "405");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.NOT_ACCEPTABLE);
	}


	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ExceptionResponse> handleAllExceptions(Exception ex) {
		ExceptionResponse exceptionResponse = new ExceptionResponse("Internal Server Error, Pls check server status", "500");
		return new ResponseEntity<>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
