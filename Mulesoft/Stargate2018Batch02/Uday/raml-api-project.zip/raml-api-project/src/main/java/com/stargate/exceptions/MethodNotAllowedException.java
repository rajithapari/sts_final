package com.stargate.exceptions;

public class MethodNotAllowedException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public MethodNotAllowedException(String exception) {
		super(exception);
	}
}