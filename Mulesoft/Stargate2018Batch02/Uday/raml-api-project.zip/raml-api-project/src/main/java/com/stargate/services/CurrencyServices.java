package com.stargate.services;

import java.util.List;

//import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.stargate.controller.model.AccountDescriptor;
import com.stargate.controller.model.Currency;

@Repository
@Transactional
//@Service
public class CurrencyServices {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public long insert(Currency curency) {
		entityManager.persist(curency);
		return curency.getCurrencyID();
	}
	
	@SuppressWarnings("unchecked")
	public List<AccountDescriptor> getInvetAccount(String accountId){
		
		Query query = entityManager.createNativeQuery("select ad.AccountId, ad.AccountType,ad.DisplayName,ad.Description, a.AccountNumber from account a"
				+"join accountdescriptor ad  on a.AccountNumber=ad.AccountId where a.AccountNumber=?",	AccountDescriptor.class); //1357902470
				return (List<AccountDescriptor>) query.getResultList();
	}
	
/* 
		@SuppressWarnings("unchecked")
			public List<Account> GetAccountDetailsById(String ids) {
				Query query = entityManager.createNativeQuery(
						"select * from accountdescriptor acd ,  account acc where acd.AccountDescriptorId = acc.AccDescriptorId and acd.AccountId=?",
						Account.class);
				query.setParameter(1, ids);
				return (List<Account>) query.getResultList();
			} 
*/		 


}
