package com.stargate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.stargate.controller.model.Welcome;
import com.stargate.services.AccountServiceImpl;


@Controller
public class WelcomeController {
	private static final String welcomemsg = "Welcome Mr. %s!";

	@Autowired
	AccountServiceImpl accountServiceImpl;

	@GetMapping("/welcome/user")
	@ResponseBody
	public Welcome welcomeUser(@RequestParam(name = "name", required = false, defaultValue = "Java Fan") String name) {

		/*Optional<Currency> c = accountServiceImpl.getInvestAccount(1l);
		Currency cc = c.get();

		System.out.println(cc.getCurrencyID());
		System.out.println(cc.getOriginalCurrencyCode());*/

		// System.out.println(DatabaseOperations.getAccount());
		return new Welcome(String.format(welcomemsg, name));
	}
}