package com.startgate.dao;


import com.stargate.controller.model.Account;

public interface AccountServices {
		
	public Account getInvestAccountDetail2(String accountId);
	
	
}
