package com.stargate.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stargate.controller.model.Account;
import com.startgate.dao.Queries;


@Repository
public interface AccountRepository extends CrudRepository<Account, Long> {

	@Query(value = Queries.query_ac_desc + Queries.whareClause + " ad.accountid= :accountId", nativeQuery=true)
	public Account getInvestAccountDetail2(@Param("accountId") String accountId);
	 
}
