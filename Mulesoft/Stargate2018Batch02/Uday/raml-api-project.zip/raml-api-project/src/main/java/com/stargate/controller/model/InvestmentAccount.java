
package com.stargate.controller.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

public class InvestmentAccount
    extends Account
    implements Serializable
{

    final static long serialVersionUID = 5905105302637863705L;
    protected Boolean allowedCheckWriting;
    protected Boolean allowedOptionTrade;
    protected Double currentValue;
    protected Double availableCashBalance;
    protected Boolean margin;
    protected Boolean marginBalance;
    protected Double shortBalance;
    protected String brokerId;
    protected String planId;
    protected Double rolloverAmount;
    protected String employerName;
    protected List<InvestmentBalance> balanceList = new ArrayList<InvestmentBalance>();
    protected Currency currency;

    /**
     * Creates a new InvestmentAccount.
     * 
     */
    public InvestmentAccount() {
        super();
    }

    /**
     * Creates a new InvestmentAccount.
     * 
     */
    public InvestmentAccount(String accountId, AccountStatus status, String displayName, String description, AccountType accountType, String nickname, String accountNumber, Double interestRate, Boolean allowedCheckWriting, Boolean allowedOptionTrade, Double currentValue, Double availableCashBalance, Boolean margin, Boolean marginBalance, Double shortBalance, String brokerId, String planId, Double rolloverAmount, String employerName, List<InvestmentBalance> balanceList, Currency currency) {
        super(accountId, status, displayName, description, accountType, nickname, accountNumber, interestRate);
        this.allowedCheckWriting = allowedCheckWriting;
        this.allowedOptionTrade = allowedOptionTrade;
        this.currentValue = currentValue;
        this.availableCashBalance = availableCashBalance;
        this.margin = margin;
        this.marginBalance = marginBalance;
        this.shortBalance = shortBalance;
        this.brokerId = brokerId;
        this.planId = planId;
        this.rolloverAmount = rolloverAmount;
        this.employerName = employerName;
        this.balanceList = balanceList;
        this.currency = currency;
    }

    /**
     * Returns the accountId.
     * 
     * @return
     *     accountId
     */
    @NotNull
    @Pattern(regexp = "\\d+")
    @Size(max = 128)
    public String getAccountId() {
        return accountId;
    }

    /**
     * Returns the status.
     * 
     * @return
     *     status
     */
    @NotNull
    public AccountStatus getStatus() {
        return status;
    }

    /**
     * Returns the displayName.
     * 
     * @return
     *     displayName
     */
    @NotNull
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Returns the description.
     * 
     * @return
     *     description
     */
    @NotNull
    public String getDescription() {
        return description;
    }

    /**
     * Returns the accountType.
     * 
     * @return
     *     accountType
     */
    @NotNull
    public AccountType getAccountType() {
        return accountType;
    }

    /**
     * Returns the nickname.
     * 
     * @return
     *     nickname
     */
    @NotNull
    public String getNickname() {
        return nickname;
    }

    /**
     * Returns the accountNumber.
     * 
     * @return
     *     accountNumber
     */
    @NotNull
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Returns the interestRate.
     * 
     * @return
     *     interestRate
     */
    @NotNull
    public Double getInterestRate() {
        return interestRate;
    }

    /**
     * Returns the allowedCheckWriting.
     * 
     * @return
     *     allowedCheckWriting
     */
    @NotNull
    public Boolean getAllowedCheckWriting() {
        return allowedCheckWriting;
    }

    /**
     * Set the allowedCheckWriting.
     * 
     * @param allowedCheckWriting
     *     the new allowedCheckWriting
     */
    public void setAllowedCheckWriting(Boolean allowedCheckWriting) {
        this.allowedCheckWriting = allowedCheckWriting;
    }

    /**
     * Returns the allowedOptionTrade.
     * 
     * @return
     *     allowedOptionTrade
     */
    @NotNull
    public Boolean getAllowedOptionTrade() {
        return allowedOptionTrade;
    }

    /**
     * Set the allowedOptionTrade.
     * 
     * @param allowedOptionTrade
     *     the new allowedOptionTrade
     */
    public void setAllowedOptionTrade(Boolean allowedOptionTrade) {
        this.allowedOptionTrade = allowedOptionTrade;
    }

    /**
     * Returns the currentValue.
     * 
     * @return
     *     currentValue
     */
    @NotNull
    public Double getCurrentValue() {
        return currentValue;
    }

    /**
     * Set the currentValue.
     * 
     * @param currentValue
     *     the new currentValue
     */
    public void setCurrentValue(Double currentValue) {
        this.currentValue = currentValue;
    }

    /**
     * Returns the availableCashBalance.
     * 
     * @return
     *     availableCashBalance
     */
    @NotNull
    public Double getAvailableCashBalance() {
        return availableCashBalance;
    }

    /**
     * Set the availableCashBalance.
     * 
     * @param availableCashBalance
     *     the new availableCashBalance
     */
    public void setAvailableCashBalance(Double availableCashBalance) {
        this.availableCashBalance = availableCashBalance;
    }

    /**
     * Returns the margin.
     * 
     * @return
     *     margin
     */
    @NotNull
    public Boolean getMargin() {
        return margin;
    }

    /**
     * Set the margin.
     * 
     * @param margin
     *     the new margin
     */
    public void setMargin(Boolean margin) {
        this.margin = margin;
    }

    /**
     * Returns the marginBalance.
     * 
     * @return
     *     marginBalance
     */
    @NotNull
    public Boolean getMarginBalance() {
        return marginBalance;
    }

    /**
     * Set the marginBalance.
     * 
     * @param marginBalance
     *     the new marginBalance
     */
    public void setMarginBalance(Boolean marginBalance) {
        this.marginBalance = marginBalance;
    }

    /**
     * Returns the shortBalance.
     * 
     * @return
     *     shortBalance
     */
    @NotNull
    public Double getShortBalance() {
        return shortBalance;
    }

    /**
     * Set the shortBalance.
     * 
     * @param shortBalance
     *     the new shortBalance
     */
    public void setShortBalance(Double shortBalance) {
        this.shortBalance = shortBalance;
    }

    /**
     * Returns the brokerId.
     * 
     * @return
     *     brokerId
     */
    @NotNull
    public String getBrokerId() {
        return brokerId;
    }

    /**
     * Set the brokerId.
     * 
     * @param brokerId
     *     the new brokerId
     */
    public void setBrokerId(String brokerId) {
        this.brokerId = brokerId;
    }

    /**
     * Returns the planId.
     * 
     * @return
     *     planId
     */
    @NotNull
    public String getPlanId() {
        return planId;
    }

    /**
     * Set the planId.
     * 
     * @param planId
     *     the new planId
     */
    public void setPlanId(String planId) {
        this.planId = planId;
    }

    /**
     * Returns the rolloverAmount.
     * 
     * @return
     *     rolloverAmount
     */
    @NotNull
    public Double getRolloverAmount() {
        return rolloverAmount;
    }

    /**
     * Set the rolloverAmount.
     * 
     * @param rolloverAmount
     *     the new rolloverAmount
     */
    public void setRolloverAmount(Double rolloverAmount) {
        this.rolloverAmount = rolloverAmount;
    }

    /**
     * Returns the employerName.
     * 
     * @return
     *     employerName
     */
    @NotNull
    public String getEmployerName() {
        return employerName;
    }

    /**
     * Set the employerName.
     * 
     * @param employerName
     *     the new employerName
     */
    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    /**
     * Returns the balanceList.
     * 
     * @return
     *     balanceList
     */
    @NotNull
    @Valid
    public List<InvestmentBalance> getBalanceList() {
        return balanceList;
    }

    /**
     * Set the balanceList.
     * 
     * @param balanceList
     *     the new balanceList
     */
    public void setBalanceList(List<InvestmentBalance> balanceList) {
        this.balanceList = balanceList;
    }

    /**
     * Returns the currency.
     * 
     * @return
     *     currency
     */
    @NotNull
    @Valid
    public Currency getCurrency() {
        return currency;
    }

    /**
     * Set the currency.
     * 
     * @param currency
     *     the new currency
     */
    public void setCurrency(Currency currency) {
        this.currency = currency;
    }

    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).append(allowedCheckWriting).append(allowedOptionTrade).append(currentValue).append(availableCashBalance).append(margin).append(marginBalance).append(shortBalance).append(brokerId).append(planId).append(rolloverAmount).append(employerName).append(balanceList).append(currency).toHashCode();
    }

    public boolean equals(Object other) {
        if (other == null) {
            return false;
        }
        if (other == this) {
            return true;
        }
        if (this.getClass()!= other.getClass()) {
            return false;
        }
        InvestmentAccount otherObject = ((InvestmentAccount) other);
        return new EqualsBuilder().appendSuper(super.equals(otherObject)).append(allowedCheckWriting, otherObject.allowedCheckWriting).append(allowedOptionTrade, otherObject.allowedOptionTrade).append(currentValue, otherObject.currentValue).append(availableCashBalance, otherObject.availableCashBalance).append(margin, otherObject.margin).append(marginBalance, otherObject.marginBalance).append(shortBalance, otherObject.shortBalance).append(brokerId, otherObject.brokerId).append(planId, otherObject.planId).append(rolloverAmount, otherObject.rolloverAmount).append(employerName, otherObject.employerName).append(balanceList, otherObject.balanceList).append(currency, otherObject.currency).isEquals();
    }

    public String toString() {
        return new ToStringBuilder(this).appendSuper(super.toString()).append("allowedCheckWriting", allowedCheckWriting).append("allowedOptionTrade", allowedOptionTrade).append("currentValue", currentValue).append("availableCashBalance", availableCashBalance).append("margin", margin).append("marginBalance", marginBalance).append("shortBalance", shortBalance).append("brokerId", brokerId).append("planId", planId).append("rolloverAmount", rolloverAmount).append("employerName", employerName).append("balanceList", balanceList).append("currency", currency).toString();
    }

}
