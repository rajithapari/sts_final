package com.stargate.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stargate.controller.model.Account;
import com.stargate.repository.AccountRepository;
import com.startgate.dao.AccountServices;


@Service
public class AccountServiceImpl implements AccountServices{
	
	@Autowired
    private AccountRepository accountRepository;
    
   /* @Transactional
    public Optional<Currency> getInvestAccount(long currencyId) {
    	System.out.println("hi.....");
        return accountRepository.findById(currencyId);
        	
    }*/

	
	/*@Override
	public InvestmentAccount getInvestAccountDetail(String accountId) {
		
		InvestmentAccount accountDesc = (InvestmentAccount)accountRepository.getInvestAccountDetail(accountId);
		return accountDesc;
	}
	*/
	@Override
	public Account getInvestAccountDetail2(String accountId) {
		
		return accountRepository.getInvestAccountDetail2(accountId);
		
	}
    

}
