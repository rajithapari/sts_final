package com.test.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.stargate.services.AccountServiceImpl;

@SpringBootApplication
@ComponentScan("com")
@EntityScan("com")
@EnableJpaRepositories("com")
public class MainApps extends SpringBootServletInitializer {

	private static final Logger log = LoggerFactory.getLogger(MainApps.class);
	


	public static void main(String[] args) {
		SpringApplication.run(MainApps.class, args);
	}

	
	
	
	/*@Override
	public void run(String... args) throws Exception {
		log.info("-------------------------------");
		log.info("Adding Tom as Admin");
		log.info("-------------------------------");
		Currency currency = new Currency(10, "EUR", "EUR");
		userService.insert(currency);
		log.info("Inserted Tom" + currency);

		log.info("-------------------------------");
		log.info("Finding user with id 1");
		log.info("-------------------------------");

		
	}*/
}