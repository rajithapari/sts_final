
package com.stargate.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stargate.controller.model.Account;
import com.stargate.exceptions.MethodNotAllowedException;
import com.stargate.exceptions.ResponseEntityExceptionHandler;
import com.stargate.exceptions.SourceNotFoundException;
import com.startgate.dao.AccountServices;
import com.test.main.RabitProducerApplication;

/**
 * No description (Generated with springmvc-raml-parser v.2.0.3)
 * 
 */

@RestController
@RequestMapping("/api/v1/accounts")
public class AccountIDController {

	@Autowired
	AccountServices accountService;
	@Autowired
	RabitProducerApplication rpcProducerRabbitApplication;

	/**
	 * Return investment account balance information on basis of accountID
	 * 
	 */

	@RequestMapping("/investmentAccount/{accountId}")
	public ResponseEntity<?> getInvestAccountDetail(@PathVariable(value = "accountId") String id) {

		try {
			
			Account accountDetail = (Account) accountService.getInvestAccountDetail2(id);
			rpcProducerRabbitApplication.sendMessage(accountDetail);
			return new ResponseEntity<>(accountDetail, HttpStatus.OK);
			
		} // catches 404 type exception
		catch (SourceNotFoundException sourceNotFound) {
			return new ResponseEntityExceptionHandler().handleAllExceptions(sourceNotFound);
		} // catches 405 type exception
		catch (MethodNotAllowedException methodNotAllow) {
			return new ResponseEntityExceptionHandler().handleMethodNotAcceptableException(methodNotAllow);
		} // catches 500 type exception
		catch (Exception excp) {
			return new ResponseEntityExceptionHandler().handleAllExceptions(excp);
		}
	}

}

// @RestController
// @RequestMapping(value = "/api/accountID", produces = "application/json")
// @Validated
// @RequestMapping("/api/v1/accounts")

// @RequestMapping(value = "/{accountId}")//, method = RequestMethod.POST)
// @RequestMapping("/hello/{accountId}")
/*
 * public InvestmentAccount updateAccountID(@PathVariable String accountId){
 * //@RequestHeader(name = "Accept", //defaultValue = "application/json",
 * required = false) //String accept){
 * 
 * System.out.println("hi......");
 * 
 * return null; }
 */

// http://localhost/api/v1/accounts/investmentAccount/101?param1=10&param2=20
/*
 * @RequestMapping("/investmentAccount/{accountId}") public String
 * getDetails(@PathVariable(value="accountId") String id){
 * //@RequestParam(value="param1", required=true) String param1,
 * //@RequestParam(value="param2", required=false) String param2
 * 
 * System.out.println("this is my request "); InvestmentAccountDao dbOperation =
 * new InvestmentAccountDao();
 * 
 * if(dbOperation.getInvestAccount(id)!=null) return "no record";
 * 
 * return "hello..."; }
 */

// http://localhost/home/personId?personId=5
// http://localhost:8080/api/v1/accounts/personId?personId=5
/*
 * @RequestMapping(value = "/personId") String getId(@RequestParam String
 * personId){ System.out.println("ID is "+personId); return
 * "Get ID from query string of URL without value element"; }
 */
// http://localhost/api/v1/accounts//investAccount/111?param1=8&param2=4
/*
 * @RequestMapping("/investAccount/{accountId}") public String
 * getDetailsQueryParam(
 * 
 * @RequestParam(value="param1", required=true) String param1,
 * 
 * @RequestParam(value="param2", required=false) String param2){
 * 
 * return "Query pram"; }
 */
/**
 * @RequestMapping(value = "/details", method = RequestMethod.POST, consumes =
 *                       "application/json") public ResponseEntity
 *                       <?>createDetails(@RequestHeader(name = "access_token")
 *                       String accessToken,
 * @RequestHeader(name = "Content-Type") String contentType,@RequestBody List
 *                     <SingleAccountDetailsRequest>
 *                     SingleAccountDetailsRequest) throws JsonParseException,
 *                     JsonMappingException, IOException {
 * 
 */
