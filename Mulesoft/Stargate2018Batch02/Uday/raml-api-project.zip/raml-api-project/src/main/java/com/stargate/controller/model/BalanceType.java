
package com.stargate.controller.model;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;

import com.fasterxml.jackson.annotation.JsonProperty;


public enum BalanceType {

    @JsonProperty("AMOUNT")
    AMOUNT("AMOUNT"),
    @JsonProperty("PERCENTAGE")
    PERCENTAGE("PERCENTAGE");
    private final String value;
    private final static Map<String, BalanceType> VALUE_CACHE = new HashMap<String, BalanceType>();

    static {
        for (BalanceType c: values()) {
            VALUE_CACHE.put(c.value, c);
        }
    }

    private BalanceType(String value) {
        this.value = value;
    }

    public String value() {
        return this.value;
    }

    public static BalanceType fromValue(String value) {
        return VALUE_CACHE.get(value);
    }

    @Override
    public String toString() {
        return this.value;
    }

}
