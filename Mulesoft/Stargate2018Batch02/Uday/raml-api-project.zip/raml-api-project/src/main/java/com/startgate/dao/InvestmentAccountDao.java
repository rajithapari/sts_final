package com.startgate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.stargate.controller.model.AccountDescriptor;

public class InvestmentAccountDao {

	/*@PersistenceContext
	private EntityManager entityManager;*/

	@SuppressWarnings("unchecked")
	public List<AccountDescriptor> getInvestAccount(String accountId) {
		
		/*Query query = 
				entityManager.createNativeQuery(Queries.query +" where a.AccountNumber=?"); //, AccountDescriptor.class);
				// 1357902470
		
		System.out.println("------------"+query);
		
		query.setParameter(1, accountId);
		
		System.out.println(query);
		
		if(query.getResultList()!=null)
			return (List<AccountDescriptor>)query.getResultList();
		else*/
			return null;
	}
	
	
	

}
