package com.startgate.dao;

public class Queries {

	public final static String query_ac_desc = "select ad.AccountId, ac.nickname, ac.AccountNumber, ac.InterestRate, ad.status, ad.displayName, ad.description, ad.accounttype from account ac join accountdescriptor ad on ac.accountnumber=ad.accountid ";
	
	public final static String query = "select ad.AccountId, ad.AccountType,ad.DisplayName,ad.Description, a.AccountNumber from account a"
			+ " join accountdescriptor ad  on a.AccountNumber=ad.AccountId";

	public final static String whareClause = " where ";
	
	
	/*@Query(value = Queries.query_ac_desc + Queries.whareClause + " ad.accountid= :accountId", nativeQuery=true)
	public List<Account> getInvestAccountDetail2(@Param("accountId") String accountId);*/
	
	 /*@Query( value ="select ad.accountid, ad.accounttype, ad.displayname, ad.description, ad.status, a.nickname, a.accountnumber, a.interestrate, ia.allowedcheckwriting, ia.allowedoptiontrade, ia.currentvalue, ia.availablecashbalance, ia.margin, ia.marginbalance, ia.shortbalance, ia.planid, ia.rolloveramount, ia.employername from account a join accountdescriptor ad join investmentaccount ia on a.accountnumber=ad.accountid and ia.RefIAccountId=a.AccountMasterId  where ad.accountId= :accountId", nativeQuery=true)
	 public InvestmentAccount getInvestAccountDetail(@Param("accountId") String accountId);*/
	 //@Query(value ="select ad.AccountId, ac.nickname, ac.AccountNumber,ac.InterestRate,ad.status,ad.displayName, ad.description, ad.accounttype from account ac join accountdescriptor ad on ac.accountnumber=ad.accountid where ad.accountid= :accountId", nativeQuery=true)
	
	 
	/* @Query(value = "SELECT * FROM currency where currencyId = :currencyId", nativeQuery=true )
	 public Optional<Currency> findById(@Param("currencyId") String currencyId);*/
	 

}
